# INTEGRASI MIDTRANS - PAYMENT GATEWAY

## Overview

Midtrans adalah payment gateway terpopuler di Indonesia yang mendukung berbagai metode pembayaran:
- Kartu Kredit
- Transfer Bank
- E-Wallet (GCash, Grabpay, OVO, Dana, LinkAja, etc.)
- Cicilan

## Setup Guide

### 1. Registrasi Midtrans

1. Buka https://midtrans.com
2. Klik "Daftar" / "Sign Up"
3. Isi form registrasi dengan data merchant
4. Verifikasi email
5. Login ke Midtrans Dashboard

### 2. Ambil Credentials

Di Midtrans Dashboard:
1. Pergi ke Settings → Access Keys / API Keys
2. Copy:
   - **Server Key** (gunakan di backend)
   - **Client Key** (gunakan di frontend)
3. Ada 2 environment: SANDBOX (testing) dan PRODUCTION

### 3. Setup .env

Edit file `.env` di root project:

```env
# Midtrans Configuration
MIDTRANS_SERVER_KEY = SB-Mid-server-xxxxxxxxxxxxx
MIDTRANS_CLIENT_KEY = SB-Mid-client-xxxxxxxxxxxxx
MIDTRANS_ENV = SANDBOX

# Development/Testing
PAYMENT_SIMULATION = true
```

### 4. Install SDK

```bash
composer require midtrans/midtrans-php
```

Untuk PDF generation (laporan & bukti pemesanan):

```bash
composer require dompdf/dompdf
```

### 5. Testing Mode vs Production

#### Sandbox (Testing)
- Gunakan saat development
- Bayaran tidak riil
- Test dengan kartu kredit test:
  - No: 4811111111111114
  - Exp: 12/25
  - CVV: 123

#### Production
- Untuk live application
- Bayaran riil
- Perlu setup billing & verification
- Ganti MIDTRANS_ENV ke PRODUCTION

---

## Payment Flow

### Step 1: Generate Snap Token

Ketika customer membuat pesanan dan ke halaman pembayaran:

```php
// Di Controller Customer
public function paymentPage($orderId)
{
    $order = $this->orderModel->getOrderDetail($orderId);
    
    // Generate Snap Token
    helper('payment');
    $snapResult = generateSnapToken($order);
    
    if ($snapResult['success']) {
        $data['snap_token'] = $snapResult['snap_token'];
        $data['client_key'] = getenv('MIDTRANS_CLIENT_KEY');
    }
    
    return view('customer/order/payment', $data);
}
```

### Step 2: Display Payment Page dengan Midtrans JS

```html
<!-- app/Views/customer/order/payment.php -->
<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Halaman Pembayaran</div>
                <div class="card-body">
                    
                    <div class="alert alert-info">
                        <strong>Total Pembayaran DP (30%):</strong> 
                        Rp <?= number_format($order['dp_amount'], 0, ',', '.') ?>
                    </div>
                    
                    <!-- Midtrans Snap Button -->
                    <button id="pay-button" class="btn btn-success btn-lg">
                        Bayar Sekarang
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Midtrans SDK -->
<script src="https://app.midtrans.com/snap/snap.js" 
    data-client-key="<?= $client_key ?>"></script>

<script>
document.getElementById('pay-button').addEventListener('click', function () {
    snap.pay('<?= $snap_token ?>', {
        onSuccess: function(result) {
            // Pembayaran berhasil
            window.location.href = '<?= base_url('customer/order/' . $order['id'] . '/payment-success') ?>';
        },
        onPending: function(result) {
            // Pembayaran pending
            console.log(result);
        },
        onError: function(result) {
            // Pembayaran gagal
            alert('Pembayaran gagal');
        },
        onClose: function() {
            alert('Anda menutup popover tanpa menyelesaikan pembayaran');
        }
    });
});
</script>

<?= $this->endSection() ?>
```

### Step 3: Handle Webhook dari Midtrans

Buat webhook controller untuk handle notifikasi dari Midtrans:

```php
// app/Controllers/Webhooks.php

namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\PaymentLogModel;
use Midtrans\Notification;

class Webhooks extends BaseController
{
    protected $orderModel;
    protected $paymentLogModel;

    public function __construct()
    {
        $this->orderModel = new OrderModel();
        $this->paymentLogModel = new PaymentLogModel();
    }

    /**
     * Handle Midtrans Notification / Webhook
     */
    public function midtrans()
    {
        // Lakukan validasi bahwa request dari Midtrans
        $serverKey = getenv('MIDTRANS_SERVER_KEY');
        
        try {
            $notif = new Notification();
        } catch (\Exception $e) {
            http_response_code(400);
            return $this->response->setJSON([
                'error' => 'Invalid request'
            ]);
        }

        // Get transaction status
        $transactionStatus = $notif->transaction_status;
        $paymentType = $notif->payment_type;
        $orderId = $notif->order_id;
        $transactionId = $notif->transaction_id;
        $grossAmount = $notif->gross_amount;

        // Extract order ID dari format: "ORDER-{id}-{timestamp}"
        $parts = explode('-', $orderId);
        $internalOrderId = $parts[1] ?? null;

        if (!$internalOrderId) {
            http_response_code(400);
            return $this->response->setJSON([
                'error' => 'Invalid order ID format'
            ]);
        }

        // Cari order
        $order = $this->orderModel->find($internalOrderId);
        if (!$order) {
            http_response_code(404);
            return $this->response->setJSON([
                'error' => 'Order not found'
            ]);
        }

        // Log payment notification
        $this->paymentLogModel->insert([
            'order_id' => $internalOrderId,
            'midtrans_transaction_id' => $transactionId,
            'reference_number' => $orderId,
            'amount' => $grossAmount,
            'status' => $transactionStatus,
            'payment_method' => $paymentType,
        ]);

        // Handle berdasarkan transaction status
        if ($transactionStatus == 'capture' || $transactionStatus == 'settlement') {
            // Pembayaran berhasil
            $this->orderModel->update($internalOrderId, [
                'payment_status' => 'dp_paid',
            ]);
            
            log_message('info', "Payment sukses untuk order: {$internalOrderId}");
            
        } else if ($transactionStatus == 'pending') {
            // Pembayaran pending
            log_message('info', "Payment pending untuk order: {$internalOrderId}");
            
        } else if ($transactionStatus == 'deny' || $transactionStatus == 'cancel' || $transactionStatus == 'expire') {
            // Pembayaran gagal / ditolak / expired
            $this->orderModel->update($internalOrderId, [
                'payment_status' => 'cancelled',
            ]);
            
            log_message('warning', "Payment failed untuk order: {$internalOrderId} - Status: {$transactionStatus}");
        }

        // Response ke Midtrans
        http_response_code(200);
        return $this->response->setJSON([
            'status' => 'ok'
        ]);
    }
}
```

### Step 4: Setup Webhook di Midtrans Dashboard

1. Login ke Midtrans Dashboard
2. Pergi ke **Settings** → **Configuration**
3. Cari **HTTP Notification** atau **Notification Center**
4. Set URL notification menjadi: 
   ```
   https://yourdomain.com/webhooks/midtrans
   ```
5. Pastikan menggunakan HTTPS untuk production
6. Save configuration

### Step 5: Register Route Webhook

Di `app/Config/Routes.php`:

```php
// Webhook routes (tanpa filter)
$routes->post('webhooks/midtrans', 'Webhooks::midtrans');
```

---

## Helper Functions

### 1. generateSnapToken()

```php
$order = $orderModel->getOrderDetail($orderId);
$result = generateSnapToken($order);

if ($result['success']) {
    $snapToken = $result['snap_token'];
    $snapUrl = $result['snap_url'];
} else {
    // Error handling
}
```

**Response:**
```php
[
    'success' => true,
    'snap_token' => 'xxxxx',
    'snap_url' => 'https://app.midtrans.com/snap/...'
]
```

### 2. verifyMidtransPayment()

```php
$verification = verifyMidtransPayment($transactionId);

if ($verification['success']) {
    $status = $verification['status']; // settlement, capture, pending, etc
}
```

### 3. updateOrderPaymentStatus()

```php
$paymentStatus = [
    'order_id' => 'ORDER-123-123456',
    'transaction_id' => 'xxx',
    'status' => 'settlement',
    'payment_method' => 'credit_card'
];

updateOrderPaymentStatus($paymentStatus);
```

---

## Payment Status Mapping

| Midtrans Status | App Status | Meaning |
|-----------------|-----------|---------|
| capture | paid | Pembayaran sukses (CC temp) |
| settlement | paid | Pembayaran final settled |
| pending | pending | Menunggu konfirmasi |
| deny | cancelled | Pembayaran ditolak |
| cancel | cancelled | Pembayaran dibatalkan |
| expire | cancelled | Pembayaran expired |

---

## Testing dengan Sandbox

### Test Scenario

1. **Success Payment**
   ```
   Kartu: 4811111111111114
   Exp: 12/25
   CVV: 123
   OTP: 123456
   Klik: Accept
   ```

2. **Pending Payment**
   ```
   Metodde: Transfer Bank / ATM Bersama
   Nominal: berapa saja
   Tungggu konfirmasi manual
   ```

3. **Failed Payment**
   ```
   Kartu: 4111111111111112
   Click: Reject
   ```

### Monitoring Sandbox

Di Midtrans Dashboard → **Transactions**:
- Lihat semua transaksi test
- Check status berdasarkan transaction ID
- Trigger ulang notifikasi jika perlu

---

## Security Best Practices

1. **Do NOT expose Server Key**
   - Hanya digunakan di backend (PHP)
   - Jangan pernah letakkan di frontend

2. **Validate Webhook**
   - Selalu verify bahwa request dari Midtrans
   - Check server key dalam calculation

3. **Use HTTPS**
   - All communication must be HTTPS di production
   - Sandbox bisa HTTP

4. **Store Transaction ID**
   - Simpan transaction ID dari Midtrans
   - Gunakan untuk reconciliation

5. **Implement Idempotency**
   - Handle duplicate webhook notifications
   - Check apakah order sudah di-process

---

## Error Handling

### 1. Network Error

```php
try {
    $snapToken = Snap::getSnapToken($transactionData);
} catch (\Exception $e) {
    log_message('error', 'Midtrans Error: ' . $e->getMessage());
    return redirect()->back()->with('error', 'Gagal membuat token pembayaran');
}
```

### 2. Invalid Configuration

```
Error: "Midtrans Server Key or Client Key not provided"
→ Check .env file

Error: "Invalid Server Key format"
→ Copy dari dashboard, jangan typo
```

### 3. Transaction Not Found

```
Error: "Transaction does not exist"
→ Check order ID format di parameter Snap
```

---

## Migration dari Development ke Production

### Checklist

- [ ] Update MIDTRANS_ENV ke PRODUCTION
- [ ] Use Production Server Key & Client Key
- [ ] Setup HTTPS certificate
- [ ] Update webhook URL ke production
- [ ] Test dengan transaksi kecil dulu
- [ ] Monitor transaction di dashboard
- [ ] Setup email notification ke merchant
- [ ] Implementasi retry logic untuk webhook
- [ ] Setup monitoring & alerting
- [ ] Dokumentasi procedure settlement & refund

---

## Advanced Features

### 1. Recurring Payment / Subscription
```php
// Untuk langganan bulanan
$transactionData['customer_details']['customer_id'] = $customerId;
```

### 2. Multitenancy
```php
// Multiple merchant dengan satu aplikasi
// Sesuaikan Server Key berdasarkan merchant
```

### 3. Installment Payment
```php
// Cicilan 3, 6, 12 bulan
$transactionData['credit_card']['installment'] = [
    'required' => false,
    'terms' => ['3', '6', '12']
];
```

### 4. Split Payment
```php
// Bagi hasil untuk multi-merchant
$transactionData['payout'] = [];
```

---

## Reference Links

- Midtrans Documentation: https://docs.midtrans.com
- Snap Integration: https://snap.midtrans.com
- API Reference: https://api-docs.midtrans.com
- Status Codes: https://snap-docs.midtrans.com/

---

**Last Updated: 20 February 2026**
