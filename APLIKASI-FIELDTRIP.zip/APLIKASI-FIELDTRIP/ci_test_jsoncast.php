<?php

require __DIR__ . '/vendor/codeigniter4/framework/system/DataCaster/Cast/JsonCast.php';

use CodeIgniter\DataCaster\Cast\JsonCast;

try {
    $res1 = JsonCast::get('"hello"');
    var_dump($res1);

    $res2 = JsonCast::get('{"a":1}');
    var_dump($res2);

    $res3 = JsonCast::get('null');
    var_dump($res3);

    echo "DONE\n";
} catch (Throwable $e) {
    echo get_class($e) . ': ' . $e->getMessage() . PHP_EOL;
}
