# APLIKASI PEMESANAN FIELDTRIP - DOKUMENTASI LENGKAP

## Ringkasan Proyek

Aplikasi web pemesanan tiket fieldtrip berbasis CodeIgniter 4 dengan fitur multi-role, payment gateway integration (Midtrans), dan reporting system.

---

## 📋 FITUR UTAMA

### ✅ 4 Role Pengguna

#### 1. ADMIN
- Dashboard dengan statistik
- Kelola Paket (CRUD): Ula (Rp75.000), Aulia (Rp85.000), Ulya (Rp95.000)
- Kelola Wahana Satuan (CRUD)
- Kelola Jadwal Fieldtrip (max 300 peserta/hari)
- Verifikasi Pembayaran DP
- Konfirmasi Pesanan
- Laporan Penjualan
- Logout

#### 2. CUSTOMER (Pemesan)
- Registrasi & Login
- View Paket & Wahana (public)
- Form Pemesanan:
  - Nama Sekolah/Instansi
  - Nama Pemesan & No. HP
  - Jumlah Peserta & Wali Murid
  - Pilih Paket & Wahana Tambahan
  - Pilih Jadwal
- Otomatis hitung Total Harga & DP (30%)
- Pembayaran via Midtrans (DP only)
- Upload Bukti Pembayaran
- Download PDF Bukti Pemesanan
- Riwayat Pesanan
- Logout

#### 3. PENGELOLA
- Dashboard
- Kelola Status Operasional Wahana (Aktif/Nonaktif)
- Laporan Jadwal Pesanan (persiapan fieldtrip)
- Logout

#### 4. OWNER
- Dashboard (statistik penjualan bulan ini)
- Laporan Penjualan dengan Filter Bulan & Tahun
- Download Laporan PDF
- Logout

### ✅ Sistem Perhitungan

```
Total Harga = (Jumlah Peserta × Harga Paket) + Total Wahana Tambahan
DP (30%)    = Total Harga × 0.30
Sisa Bayar  = Total Harga - DP
```

**Aturan Jadwal:**
- Maksimal 300 peserta per jadwal per hari
- Jika full → jadwal tidak bisa dipilih
- Sistem otomatis reserve & update status

### ✅ Payment Gateway

- Integrasi Midtrans Snap
- Support berbagai metode pembayaran
- Sandbox mode untuk testing
- Production mode untuk live
- Webhook handling untuk update status

### ✅ Laporan & PDF

- PDF bukti pemesanan (untuk customer)
- PDF laporan penjualan (untuk owner/admin)
- CSV export (future)

---

## 📁 STRUKTUR FOLDER

```
d:\APLIKASI-FIELDTRIP\
├── app/
│   ├── Config/
│   │   ├── Routes.php              ✅ Semua routes
│   │   ├── Filters.php             ✅ Role-based filters
│   │   ├── Database.php            ✅ DB Config
│   │   └── ... (config lainnya)
│   │
│   ├── Controllers/
│   │   ├── Auth.php                ✅ Login/Register
│   │   ├── Dashboard.php           ✅ Router dashboard
│   │   ├── Admin.php               ✅ Admin management
│   │   ├── Customer.php            ✅ Customer order
│   │   ├── Pengelola.php          ✅ Pengelola management
│   │   ├── Owner.php              ✅ Owner reports
│   │   ├── Pages.php              ⚙️ Public pages (TODO)
│   │   └── Webhooks.php           ⚙️ Payment webhook (TODO)
│   │
│   ├── Models/
│   │   ├── UserModel.php           ✅ User management + login
│   │   ├── PackageModel.php        ✅ Paket fieldtrip
│   │   ├── AttractionModel.php     ✅ Wahana satuan
│   │   ├── ScheduleModel.php       ✅ Jadwal + reserve logic
│   │   ├── OrderModel.php          ✅ Pemesanan + stats
│   │   ├── OrderAttractionItemModel.php ✅ Wahana per order
│   │   ├── PaymentLogModel.php     ✅ Log pembayaran
│   │   └── ReportModel.php         ✅ Reports
│   │
│   ├── Database/
│   │   ├── Migrations/
│   │   │   ├── 2026-02-20-000001_CreateUsersTable.php
│   │   │   ├── 2026-02-20-000002_CreatePackagesTable.php
│   │   │   ├── 2026-02-20-000003_CreateAttractionsTable.php
│   │   │   ├── 2026-02-20-000004_CreateSchedulesTable.php
│   │   │   ├── 2026-02-20-000005_CreateOrdersTable.php
│   │   │   ├── 2026-02-20-000006_CreateOrderAttractionItemsTable.php
│   │   │   ├── 2026-02-20-000007_CreatePaymentLogTable.php
│   │   │   └── 2026-02-20-000008_CreateReportsTable.php
│   │   └── Seeds/
│   │       └── SampleSeeder.php    ⚙️ Sample data (TODO)
│   │
│   ├── Filters/
│   │   ├── FilterCheckLogin.php    ✅ Check if logged in
│   │   ├── FilterAdmin.php         ✅ Admin only
│   │   ├── FilterCustomer.php      ✅ Customer only
│   │   ├── FilterPengelola.php     ✅ Pengelola only
│   │   └── FilterOwner.php         ✅ Owner only
│   │
│   ├── Helpers/
│   │   ├── PdfHelper.php           ✅ PDF generation (DomPDF)
│   │   └── PaymentHelper.php       ✅ Midtrans integration
│   │
│   ├── Views/
│   │   ├── layouts/
│   │   │   ├── app.php             ✅ Main layout
│   │   │   └── app_auth.php        ✅ Auth layout
│   │   ├── auth/
│   │   │   ├── login.php           ✅ Login page
│   │   │   └── register.php        ✅ Register page
│   │   ├── admin/
│   │   │   ├── dashboard.php       ✅ Admin dashboard
│   │   │   ├── packages/           ⚙️ Package management views (TODO)
│   │   │   ├── attractions/        ⚙️ Attraction views (TODO)
│   │   │   ├── schedules/          ⚙️ Schedule views (TODO)
│   │   │   ├── orders/             ⚙️ Order detail views (TODO)
│   │   │   └── reports/            ⚙️ Report views (TODO)
│   │   ├── customer/
│   │   │   ├── dashboard.php       ✅ Customer dashboard
│   │   │   └── order/              ⚙️ Order form & detail (TODO)
│   │   ├── pengelola/
│   │   │   ├── dashboard.php       ⚙️ Pengelola dashboard (TODO)
│   │   │   ├── attractions/        ⚙️ Attraction status (TODO)
│   │   │   └── reports/            ⚙️ Schedule report (TODO)
│   │   └── owner/
│   │       ├── dashboard.php       ⚙️ Owner dashboard (TODO)
│   │       └── reports/            ⚙️ Sales report (TODO)
│   │
│   ├── Common.php
│   └── ... (file lainnya)
│
├── public/
│   ├── index.php
│   └── uploads/                    ⚙️ Upload directory (create these)
│       ├── packages/
│       ├── attractions/
│       └── payments/
│
├── DATABASE_DESIGN.md              ✅ ERD & tabel design
├── SETUP_GUIDE.md                  ✅ Installation guide
├── API_ROUTES.md                   ✅ API documentation
├── MIDTRANS_INTEGRATION.md         ✅ Payment integration
├── composer.json                   ✅ Dependencies
├── .env                            ⚙️ Environment config (TODO)
└── ... (file lainnya)
```

**Status:**
- ✅ Completed - Sudah dibuat
- ⚙️ TODO - Perlu dibuat lebih lanjut

---

## 📊 DATABASE DESIGN

### 8 Tabel Utama

1. **users** - User dengan 4 role (admin, customer, pengelola, owner)
2. **packages** - Paket fieldtrip (Ula, Aulia, Ulya)
3. **attractions** - Wahana satuan
4. **schedules** - Jadwal fieldtrip (max 300 peserta/hari)
5. **orders** - Pemesanan (detail sekolah, peserta, harga, payment status)
6. **order_attraction_items** - Wahana tambahan yang dipilih per order
7. **payment_log** - Log pembayaran dari Midtrans
8. **reports** - Laporan penjualan & jadwal

### Relasi Kunci

```
users ← orders (1:M)
packages ← orders (1:M)
schedules ← orders (1:M)
attractions ← order_attraction_items (1:M)
orders ← order_attraction_items (1:M)
orders ← payment_log (1:M)
```

---

## 🔐 AUTHENTICATION & AUTHORIZATION

### Login Flow

```
1. User masukkan email & password
2. System validasi via UserModel::verifyLogin()
3. Password di-hash dengan bcrypt
4. Jika valid → simpan session:
   - user_id
   - user_name
   - user_email
   - user_role
5. Redirect ke dashboard sesuai role
```

### Role-Based Access Control

Menggunakan **Filters** di CodeIgniter:

```php
// app/Config/Filters.php
'aliases' => [
    'check_login' => FilterCheckLogin::class,
    'admin'       => FilterAdmin::class,
    'customer'    => FilterCustomer::class,
    'pengelola'   => FilterPengelola::class,
    'owner'       => FilterOwner::class,
]

// app/Config/Routes.php
$routes->group('admin', ['filter' => 'admin'], function($routes) {
    // Hanya accessible jika user role = 'admin'
});
```

---

## 💰 ORDER CALCULATION

### Contoh Kasus

```
Sekolah: SMA Negeri 1
Peserta: 50 orang
Wali Murid: 5 orang
Paket: Ula (Rp 75.000/orang)
Wahana Tambahan: Berkuda (Rp 100.000), Kolam Ikan (Rp 50.000)

Perhitungan:
- Paket: 50 × Rp 75.000 = Rp 3.750.000
- Wahana: Rp 100.000 + Rp 50.000 = Rp 150.000
- Total Harga: Rp 3.750.000 + Rp 150.000 = Rp 3.900.000
- DP (30%): Rp 3.900.000 × 0.30 = Rp 1.170.000
- Sisa Bayar: Rp 3.900.000 - Rp 1.170.000 = Rp 2.730.000

Status Pembayaran: DP PAID (setelah Midtrans konfirmasi)
Order Status: CONFIRMED (setelah admin verifikasi)
```

---

## 🔄 WORKFLOW PEMESANAN

### Customer Flow

```
1. Register / Login
   ↓
2. View Paket & Wahana
   ↓
3. Buat Pesanan (form)
   ↓ (Validasi ketersediaan jadwal)
   ↓
4. System generate Midtrans Snap Token
   ↓
5. Customer bayar via Midtrans
   ↓
6. Midtrans kirim webhook notification
   ↓
7. System update order payment status
   ↓
8. Admin verifikasi & konfirmasi
   ↓
9. Customer dapat bukti PDF
```

### Admin Flow

```
1. Kelola Paket/Wahana (CRUD)
   ↓
2. Buat Jadwal fieldtrip
   ↓
3. Review pending orders
   ↓
4. Verifikasi bukti pembayaran
   ↓
5. Konfirmasi order
   ↓ (auto-reserve jadwal)
   ↓
6. Generate laporan penjualan
```

---

## 🚀 SETUP CHECKLIST

- [ ] Clone/download project
- [ ] Run `composer install`
- [ ] Copy `.env.example` → `.env`
- [ ] Generate APP_KEY: `php spark key:generate`
- [ ] Setup database di `.env`
- [ ] Create database: `CREATE DATABASE fieldtrip_db`
- [ ] Run migration: `php spark migrate`
- [ ] Setup Midtrans credentials di `.env`
- [ ] Create upload folders
- [ ] Setup session database: `php spark session:migration`
- [ ] Run `php spark serve` untuk development
- [ ] Test login dengan akun dummy
- [ ] Setup webhook URL di Midtrans Dashboard

---

## 📝 KEY FILES EXPLANATION

### Controllers

| File | Purpose |
|------|---------|
| Auth.php | Login, Register, Logout |
| Dashboard.php | Router ke dashboard sesuai role |
| Admin.php | Manage paket, wahana, jadwal, verifikasi order |
| Customer.php | Order form, payment, riwayat |
| Pengelola.php | Manage wahana status, schedule report |
| Owner.php | View laporan penjualan, download PDF |

### Models

| File | Methods |
|------|---------|
| UserModel | verifyLogin(), registerUser(), findByEmail() |
| PackageModel | getActivePackages(), getPackageById() |
| AttractionModel | getActiveAttractions(), getAttractionsByIds() |
| ScheduleModel | isAvailableForParticipants(), reserveParticipants(), getSchedulesByPackage() |
| OrderModel | createOrder(), getUserOrders(), getPendingOrders(), getSalesStats() |
| PaymentLogModel | logPayment(), updatePaymentStatus() |

### Helpers

| File | Functions |
|------|-----------|
| PdfHelper.php | generatePdfBooking(), generatePdfSalesReport() |
| PaymentHelper.php | generateSnapToken(), verifyMidtransPayment(), initMidtransConfig() |

### Filters

| File | Purpose |
|------|---------|
| FilterCheckLogin.php | Cek user sudah login |
| FilterAdmin.php | Cek role = admin |
| FilterCustomer.php | Cek role = customer |
| FilterPengelola.php | Cek role = pengelola |
| FilterOwner.php | Cek role = owner |

---

## 🎨 VIEWS YANG SUDAH DIBUAT

✅ **Layouts**
- app.php - Main layout dengan navbar
- app_auth.php - Auth layout (login/register)

✅ **Auth Pages**
- auth/login.php
- auth/register.php

✅ **Dashboards**
- admin/dashboard.php
- customer/dashboard.php

⚙️ **TODO - Masih perlu dibuat:**
- Admin: packages, attractions, schedules, orders detail, reports
- Customer: order form, order detail, payment page, history
- Pengelola: dashboard, attractions list, schedule report
- Owner: dashboard, sales report, download PDF
- Pages: home, about, attractions, packages, gallery, contact

---

## 🔄 NEXT STEPS UNTUK DEVELOPMENT

### Phase 1: Complete Views (Priority High)
```
1. Admin panel views untuk CRUD
2. Customer order form dengan dynamic selection
3. Payment page dengan Midtrans JS
4. Report pages dengan charts
```

### Phase 2: Features & Enhancement
```
1. Email notification untuk customer
2. SMS notification untuk admin
3. Analytics dashboard
4. Advanced filtering & search
5. Bulk import paket/wahana
```

### Phase 3: Optimization
```
1. Cache frequently accessed data
2. Async job processing untuk report
3. Generate PDF dalam background
4. Add API documentation
5. Unit & integration testing
```

---

## 🔗 DEPENDENCIES

```json
{
  "require": {
    "codeigniter4/framework": "^4.x",
    "midtrans/midtrans-php": "^2.0",
    "dompdf/dompdf": "^2.0"
  }
}
```

**Install:**
```bash
composer install
composer require midtrans/midtrans-php
composer require dompdf/dompdf
```

---

## 📚 DOKUMENTASI LENGKAP

1. **DATABASE_DESIGN.md** - ERD, tabel design, relasi
2. **SETUP_GUIDE.md** - Instalasi & konfigurasi
3. **API_ROUTES.md** - Semua endpoint & request/response
4. **MIDTRANS_INTEGRATION.md** - Payment gateway setup & flow

---

## ✨ BEST PRACTICES DITERAPKAN

✅ **Security**
- Password hashing dengan bcrypt
- CSRF protection
- Role-based access control
- Input validation & sanitization
- Prepared statements (query builder)

✅ **Architecture**
- Separation of Concerns (MVC)
- Keep business logic di Model
- Controllers handle HTTP
- Views untuk presentation

✅ **Code Quality**
- Consistent naming convention
- Helper functions untuk reusable logic
- Validation rules terpusat
- Proper error handling

✅ **Database**
- Proper indexing
- Foreign keys dengan constraints
- Data type yang sesuai
- Transaction handling untuk consistency

---

## 📞 SUPPORT & TROUBLESHOOTING

### Common Issues

**Database connection error:**
```bash
# Check .env configuration
# Test connection: php spark db:connect
```

**Payment gateway error:**
```
Check Midtrans credentials di .env
Verify server key & client key format
Test dengan Sandbox mode terlebih dahulu
```

**PDF generation error:**
```bash
# Install DomPDF
composer require dompdf/dompdf

# Check file write permission di writable/
chmod 755 writable/
```

---

## 🎯 CHECKLIST DEPLOYMENT

Production Checklist:
- [ ] Update .env untuk production
- [ ] Disable debug mode: CI_ENVIRONMENT = production
- [ ] Setup HTTPS
- [ ] Update Midtrans ke PRODUCTION key
- [ ] Setup webhook URL
- [ ] Configure proper logging
- [ ] Database backup schedule
- [ ] Monitor payment transactions
- [ ] Setup email notifications
- [ ] Performance testing

---

## 📄 LISENSI & CREDIT

- Framework: CodeIgniter 4
- Payment Gateway: Midtrans
- PDF Library: DomPDF
- UI Framework: Bootstrap 5
- Icons: FontAwesome 6

---

**Status: READY FOR DEVELOPMENT**
**Last Updated: 20 February 2026**
**Version: 1.0.0**
