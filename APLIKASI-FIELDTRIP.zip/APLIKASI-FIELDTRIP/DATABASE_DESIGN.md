# Database Design - Aplikasi Pemesanan Tiket Fieldtrip

## ERD (Entity Relationship Diagram)

```
┌─────────────────────┐
│      USERS          │
├─────────────────────┤
│ id (PK)             │
│ name                │
│ email (UNIQUE)      │
│ password            │
│ phone               │
│ role (ENUM)         │ ──┐
│ is_active           │   │
│ created_at          │   │
│ updated_at          │   │
└─────────────────────┘   │
         │                │
         │        ┌───────┴────────────────────────────────┐
         │        │                                        │
         ▼        ▼                                        ▼
    ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
    │   PACKAGES       │  │   ATTRACTIONS    │  │   SCHEDULES      │
    ├──────────────────┤  ├──────────────────┤  ├──────────────────┤
    │ id (PK)          │  │ id (PK)          │  │ id (PK)          │
    │ name             │  │ name             │  │ date             │
    │ description      │  │ description      │  │ max_participants │
    │ price            │  │ price            │  │ current_reserved │
    │ facilities       │  │ image            │  │ package_id (FK)  │
    │ image            │  │ is_active        │  │ status           │
    │ is_active        │  │ created_at       │  │ created_at       │
    │ created_at       │  │ updated_at       │  │ updated_at       │
    │ updated_at       │  └──────────────────┘  └──────────────────┘
    └──────────────────┘           ▲                    ▲
            │                      │                    │
            │                      │                    │
            ▼                      ▼                    │
         ┌──────────────────────────────┐              │
         │  ORDER_ATTRACTION_ITEMS      │              │
         ├──────────────────────────────┤              │
         │ id (PK)                      │              │
         │ order_id (FK)                │              │
         │ attraction_id (FK)           │              │
         │ price_at_booking             │              │
         │ quantity                     │              │
         └──────────────────────────────┘              │
                    ▲                                  │
                    │                                  │
                    │                                  │
         ┌──────────┴────────────────────┐             │
         │        ORDERS (Bookings)      │◄────────────┘
         ├───────────────────────────────┤
         │ id (PK)                       │
         │ user_id (FK) → CUSTOMER       │
         │ visit_date                    │
         │ school_name                   │
         │ booker_name                   │
         │ phone                         │
         │ num_participants              │
         │ num_guardians                 │
         │ num_teachers                  │
         │ package_id (FK)               │
         │ total_price                   │
         │ dp_amount (30%)               │
         │ payment_status                │
         │ order_status                  │
         │ confirmation_date             │
         │ proof_payment_image           │
         │ verified_by (FK) → ADMIN      │
         │ verified_date                 │
         │ pdf_token (untuk download)    │
         │ created_at                    │
         │ updated_at                    │
         └───────────────────────────────┘

┌──────────────────────┐
│  PAYMENT_LOG         │
├──────────────────────┤
│ id (PK)              │
│ order_id (FK)        │
│ midtrans_snap_id     │
│ midtrans_transaction │
│ reference_number     │
│ amount               │
│ status               │
│ payment_method       │
│ created_at           │
│ updated_at           │
└──────────────────────┘

┌──────────────────────┐
│  REPORTS             │
├──────────────────────┤
│ id (PK)              │
│ title                │
│ type (sales, schedule)
│ filter_month         │
│ filter_year          │
│ total_revenue        │
│ total_orders         │
│ created_by (FK)      │
│ created_at           │
└──────────────────────┘
```

## Tabel dan Struktur

### 1. USERS (Tabel User dengan role-based)
- id: INT PRIMARY KEY AUTO_INCREMENT
- name: VARCHAR(255)
- email: VARCHAR(255) UNIQUE
- password: VARCHAR(255) (bcrypt hash)
- phone: VARCHAR(15)
- role: ENUM('admin', 'customer', 'pengelola', 'owner')
- is_active: TINYINT(1)
- created_at: TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- updated_at: TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

### 2. PACKAGES (Paket Fieldtrip)
- id: INT PRIMARY KEY AUTO_INCREMENT
- name: VARCHAR(100) (Ula, Aulia, Ulya)
- description: TEXT
- price: DECIMAL(10,2)
- facilities: JSON (array fasilitas)
- image: VARCHAR(255)
- is_active: TINYINT(1)
- created_at: TIMESTAMP
- updated_at: TIMESTAMP

### 3. ATTRACTIONS (Wahana Satuan)
- id: INT PRIMARY KEY AUTO_INCREMENT
- name: VARCHAR(255)
- description: TEXT
- price: DECIMAL(10,2)
- image: VARCHAR(255)
- is_active: TINYINT(1)
- created_at: TIMESTAMP
- updated_at: TIMESTAMP

### 4. SCHEDULES (Jadwal Fieldtrip)
- id: INT PRIMARY KEY AUTO_INCREMENT
- date: DATE
- max_participants: INT (300)
- current_reserved: INT
- package_id: INT (FK ke PACKAGES)
- status: ENUM('available', 'full', 'cancelled')
- created_at: TIMESTAMP
- updated_at: TIMESTAMP

### 5. ORDERS (Pemesanan)
- id: INT PRIMARY KEY AUTO_INCREMENT
- user_id: INT (FK ke USERS - customer yang pesan)
- visit_date: DATE
- school_name: VARCHAR(255)
- booker_name: VARCHAR(255)
- phone: VARCHAR(15)
- num_participants: INT
- num_guardians: INT
- num_teachers: INT
- package_id: INT (FK ke PACKAGES)
- total_price: DECIMAL(12,2)
- dp_amount: DECIMAL(12,2) (30% dari total)
- payment_status: ENUM('pending', 'dp_paid', 'paid', 'cancelled')
- order_status: ENUM('pending', 'confirmed', 'cancelled')
- confirmation_date: DATETIME
- proof_payment_image: VARCHAR(255)
- verified_by: INT (FK ke USERS - admin yang verifikasi)
- verified_date: DATETIME
- pdf_token: VARCHAR(255)
- created_at: TIMESTAMP
- updated_at: TIMESTAMP

### 6. ORDER_ATTRACTION_ITEMS (Detail Wahana per Pemesanan)
- id: INT PRIMARY KEY AUTO_INCREMENT
- order_id: INT (FK ke ORDERS)
- attraction_id: INT (FK ke ATTRACTIONS)
- price_at_booking: DECIMAL(10,2)
- quantity: INT
- created_at: TIMESTAMP

### 7. PAYMENT_LOG (Log Pembayaran dari Gateway)
- id: INT PRIMARY KEY AUTO_INCREMENT
- order_id: INT (FK ke ORDERS)
- midtrans_snap_id: VARCHAR(255)
- midtrans_transaction_id: VARCHAR(255)
- reference_number: VARCHAR(100)
- amount: DECIMAL(12,2)
- status: VARCHAR(50) (capture, settlement, pending, deny, cancel, expire)
- payment_method: VARCHAR(100)
- created_at: TIMESTAMP
- updated_at: TIMESTAMP

### 8. REPORTS (Laporan untuk Owner/Admin)
- id: INT PRIMARY KEY AUTO_INCREMENT
- title: VARCHAR(255)
- type: ENUM('sales', 'schedule')
- filter_month: INT
- filter_year: INT
- total_revenue: DECIMAL(12,2)
- total_orders: INT
- created_by: INT (FK ke USERS)
- created_at: TIMESTAMP

## Relasi Kunci

1. USERS ← ORDERS (1:M) - Customer membuat banyak pesanan
2. USERS ← ORDERS.verified_by (1:M) - Admin verifikasi banyak pesanan
3. PACKAGES ← ORDERS (1:M) - Paket memiliki banyak pesanan
4. SCHEDULES ← ORDERS (1:M) - Jadwal memiliki banyak pesanan
5. ORDERS ← ORDER_ATTRACTION_ITEMS (1:M) - Pesanan bisa pilih banyak wahana
6. ATTRACTIONS ← ORDER_ATTRACTION_ITEMS (1:M)
7. ORDERS ← PAYMENT_LOG (1:M) - Pesanan bisa membuat banyak log pembayaran
