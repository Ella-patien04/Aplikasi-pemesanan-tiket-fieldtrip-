# TODO_FIX_MIDTRANS_WEBHOOK

## Target
Midtrans webhook **POST /payment/notification** harus bisa masuk ke `Payment::notification()` dan tidak lagi menghasilkan **404 Not Found**.

## Steps
1. **Pastikan route match** saat runtime: tambah logging awal `Payment::notification()` (method, URI path, raw body length).
2. Kirim test request manual (curl/Postman) ke dua kandidat URL webhook:
   - `/payment/notification`
   - `/index.php/payment/notification`
3. Cek log `writable/logs/` untuk memastikan request benar-benar masuk ke `Payment::notification()`.
4. Jika request tidak masuk (log tidak ada), fokus perbaikan pada webserver/ngrok (document root, rewrite).
5. Jika request masuk tapi payload gagal parsing, tambahkan logging payload dan parsing `order_id`.
6. Setelah endpoint terbukti masuk dan memproses webhook, revisi response agar **selalu HTTP 200** ketika payload webhook valid (untuk mencegah Midtrans retry 404).

