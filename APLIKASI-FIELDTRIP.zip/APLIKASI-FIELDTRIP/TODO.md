# TODO (Admin Dashboard UI Redesign)

- [ ] Update global dashboard theme CSS in `app/Views/layouts/dashboard.php` (navy sidebar, gold accents, soft content background, premium cards)
- [ ] Redesign `app/Views/admin/dashboard.php` markup (premium header, top stats cards, management cards grid)
- [ ] Update `app/Views/layouts/_sidebar.php` admin menu items to include Paket & Wahana (UI-only, keep existing route URLs)
- [ ] Verify manually: admin dashboard loads, sidebar active state works, responsive layout looks correct

