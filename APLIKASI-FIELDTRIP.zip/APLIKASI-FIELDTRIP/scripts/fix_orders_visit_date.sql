-- Fix orders table schema for visit_date-based booking
-- Usage:
--   mysql -u DB_USER -p DB_NAME < scripts/fix_orders_visit_date.sql
-- Replace DB_USER and DB_NAME sesuai environment Anda.

-- 1. Pastikan backup sudah dibuat terlebih dahulu.
--    Jangan jalankan ini sebelum backup.
--    Contoh backup:
--      mysqldump -u DB_USER -p DB_NAME > backup_before_fix.sql

-- 2. Tampilkan kolom di tabel orders untuk verifikasi awal.
SHOW COLUMNS FROM orders;

-- 3. Tambahkan kolom visit_date jika belum ada.
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS visit_date DATE NOT NULL AFTER user_id;

-- 4. Isi nilai visit_date dari referensi tabel schedules jika masih ada schedule_id.
--    Hanya jalankan jika tabel orders masih memiliki schedule_id.
UPDATE orders o
JOIN schedules s ON o.schedule_id = s.id
SET o.visit_date = s.date
WHERE (o.visit_date IS NULL OR o.visit_date = '')
  AND o.schedule_id IS NOT NULL;

-- 5. Verifikasi apakah masih ada baris yang belum punya visit_date
--    tapi masih punya schedule_id.
SELECT COUNT(*) AS remaining_order_rows_with_schedule_id
FROM orders
WHERE (visit_date IS NULL OR visit_date = '')
  AND schedule_id IS NOT NULL;

-- 6. Jika hasil di atas adalah 0, maka aman untuk menghapus schedule_id.
--    Hapus constraint foreign key schedule jika ada.
ALTER TABLE orders
  DROP FOREIGN KEY IF EXISTS fk_orders_schedule;

-- 7. Hapus INDEX schedule_id jika masih tersisa.
ALTER TABLE orders
  DROP INDEX IF EXISTS schedule_id;

-- 8. Hapus kolom schedule_id jika masih ada.
ALTER TABLE orders
  DROP COLUMN IF EXISTS schedule_id;

-- 9. Verifikasi enum order_status dan pastikan default adalah pending.
SELECT COLUMN_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'orders'
  AND COLUMN_NAME = 'order_status';

-- 10. Jika enum order_status tidak sesuai, perbaiki dengan nilai valid berikut.
ALTER TABLE orders
  MODIFY COLUMN order_status ENUM('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending';

-- 11. Contoh cek kuota untuk satu tanggal.
SELECT COALESCE(SUM(num_participants),0) AS total_participants
FROM orders
WHERE visit_date = '2026-07-01'
  AND order_status != 'cancelled'
  AND payment_status != 'cancelled';

-- 12. Pastikan visit_date sudah ada dan menjadi dasar kuota.
SHOW COLUMNS FROM orders LIKE 'visit_date';
