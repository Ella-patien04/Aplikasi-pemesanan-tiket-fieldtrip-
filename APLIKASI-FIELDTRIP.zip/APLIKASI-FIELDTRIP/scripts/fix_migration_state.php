<?php

/**
 * Fix migration state when the database already contains the schema,
 * but CodeIgniter's migrations table does not include the applied files.
 */
$root = realpath(__DIR__ . '/../');
$envFile = $root . '/.env';

function parseEnvFile(string $path): array
{
    if (!is_file($path)) {
        return [];
    }

    $data = [];
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') {
            continue;
        }

        if (strpos($line, '=') === false) {
            continue;
        }

        [$key, $value] = array_map('trim', explode('=', $line, 2));
        $value = trim($value, " \t\n\r\0\x0B\"'");
        $data[$key] = $value;
    }

    return $data;
}

function getEnvValue(array $env, string $key, string $fallback = ''): string
{
    return $env[$key] ?? $fallback;
}

$env = parseEnvFile($envFile);

$dbHost = getEnvValue($env, 'database.default.hostname', 'localhost');
$dbName = getEnvValue($env, 'database.default.database');
$dbUser = getEnvValue($env, 'database.default.username', 'root');
$dbPass = getEnvValue($env, 'database.default.password', '');
$dbPort = getEnvValue($env, 'database.default.port', '3306');

if ($dbName === '') {
    echo "ERROR: Database name is not configured in .env\n";
    exit(1);
}

$mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName, (int) $dbPort);
if ($mysqli->connect_error) {
    echo "ERROR: Could not connect to database: {$mysqli->connect_error}\n";
    exit(1);
}

$migrationsTable = 'migrations';
$requiredTables = [
    'users',
    'packages',
    'attractions',
    'schedules',
    'orders',
    'order_attraction_items',
    'payment_log',
    'reports',
];

$missingTables = [];
foreach ($requiredTables as $table) {
    $result = $mysqli->query("SHOW TABLES LIKE '{$mysqli->real_escape_string($table)}'");
    if (!$result || $result->num_rows === 0) {
        $missingTables[] = $table;
    }
}

if (!empty($missingTables)) {
    echo "ERROR: The following required tables are missing:\n";
    foreach ($missingTables as $missing) {
        echo " - {$missing}\n";
    }
    echo "\nThis script is intended to be run only when the schema already exists.\n";
    exit(1);
}

$createMigrationsSql = <<<SQL
CREATE TABLE IF NOT EXISTS `{$migrationsTable}` (
  `version` VARCHAR(180) NOT NULL,
  `group` VARCHAR(20) NOT NULL DEFAULT 'default',
  `batch` INT(11) UNSIGNED NOT NULL,
  `time` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`version`, `group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
if (!$mysqli->query($createMigrationsSql)) {
    echo "ERROR: Failed to ensure migrations table exists: {$mysqli->error}\n";
    exit(1);
}

$existingVersions = [];
$result = $mysqli->query("SELECT version FROM `{$migrationsTable}`");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $existingVersions[$row['version']] = true;
    }
    $result->free();
}

$files = glob($root . '/app/Database/Migrations/*.php');
sort($files, SORT_STRING);

if (empty($files)) {
    echo "ERROR: No migration files found in app/Database/Migrations.\n";
    exit(1);
}

$batch = 1;
$result = $mysqli->query("SELECT MAX(batch) AS max_batch FROM `{$migrationsTable}`");
if ($result) {
    $row = $result->fetch_assoc();
    if ($row && isset($row['max_batch']) && $row['max_batch'] !== null) {
        $batch = (int) $row['max_batch'] + 1;
    }
    $result->free();
}

$inserted = 0;
$now = time();

foreach ($files as $file) {
    $basename = basename($file, '.php');
    if (isset($existingVersions[$basename])) {
        continue;
    }

    $escapedVersion = $mysqli->real_escape_string($basename);
    $sql = "INSERT INTO `{$migrationsTable}` (`version`, `group`, `batch`, `time`) VALUES ('{$escapedVersion}', 'default', {$batch}, {$now})";
    if ($mysqli->query($sql)) {
        $inserted++;
        echo "Marked migration as applied: {$basename}\n";
    } else {
        echo "ERROR: Failed to insert migration {$basename}: {$mysqli->error}\n";
    }
}

if ($inserted === 0) {
    echo "No new migration versions needed. All migration files are already recorded.\n";
} else {
    echo "Inserted {$inserted} migration version(s) into {$migrationsTable}.\n";
    echo "You can now run: php spark migrate\n";
}

$mysqli->close();
