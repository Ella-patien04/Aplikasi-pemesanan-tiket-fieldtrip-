# Fix Orders Schema untuk visit_date

File ini membantu memperbaiki tabel `orders` agar booking menggunakan `visit_date` dan bukan `schedule_id`.

## Langkah yang dijalankan oleh skrip

1. Memeriksa struktur kolom `orders`
2. Menambahkan `visit_date` jika belum ada
3. Mengisi `visit_date` dari tabel `schedules` bila masih ada `schedule_id`
4. Menghapus `schedule_id` setelah migrasi data
5. Memastikan enum `order_status` hanya menerima `pending`, `confirmed`, `cancelled`
6. Menyediakan query pengecekan kuota `visit_date`

## Cara menjalankan

1. Backup database terlebih dahulu:

```bash
mysqldump -u DB_USER -p DB_NAME > backup_before_fix.sql
```

2. Jalankan skrip SQL:

```bash
mysql -u DB_USER -p DB_NAME < scripts/fix_orders_visit_date.sql
```

3. Cek ulang hasilnya:

```sql
SHOW COLUMNS FROM orders;
SELECT COLUMN_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'orders'
  AND COLUMN_NAME = 'order_status';
```

## Notes

- Jika Anda menggunakan CodeIgniter migration, jalankan `php spark migrate` terlebih dahulu.
- Jika `schedule_id` sudah tidak ada lagi, skrip akan melewati bagian drop kolom.
- Pastikan `visit_date` terisi untuk setiap order sebelum menghapus `schedule_id`.
