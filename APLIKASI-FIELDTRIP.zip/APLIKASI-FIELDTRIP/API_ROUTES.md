# API ROUTES & ENDPOINTS DOCUMENTATION

## Authentication Routes

### Login
```
GET  /auth/login                    → Show login form
POST /auth/do-login               → Process login
GET  /auth/logout                 → Logout dan destroy session
```

### Register
```
GET  /auth/register               → Show register form
POST /auth/do-register            → Process registration
```

### Dashboard
```
GET  /dashboard                   → Route ke dashboard sesuai role
```

---

## Admin Routes

**Prefix:** `/admin`
**Filter:** `admin` (hanya user dengan role admin)

### Dashboard
```
GET /admin/dashboard              → Admin dashboard
```

### Package Management (CRUD)
```
GET  /admin/packages              → List semua paket
GET  /admin/packages/add          → Form tambah paket
POST /admin/packages/save         → Simpan paket baru
GET  /admin/packages/edit/{id}    → Form edit paket
POST /admin/packages/update/{id}  → Update paket
GET  /admin/packages/delete/{id}  → Delete paket
```

**Request Body untuk POST/PUT:**
```json
{
  "name": "Paket Ula",
  "description": "Deskripsi paket",
  "price": 75000,
  "facilities": "Makan Siang,Transport,Pemandu Wisata",
  "image": "file_upload"
}
```

### Attraction Management (CRUD)
```
GET  /admin/attractions           → List semua wahana
GET  /admin/attractions/add       → Form tambah wahana
POST /admin/attractions/save      → Simpan wahana baru
GET  /admin/attractions/edit/{id} → Form edit wahana
POST /admin/attractions/update/{id} → Update wahana
GET  /admin/attractions/delete/{id} → Delete wahana
```

**Request Body:**
```json
{
  "name": "Wahana Berkuda",
  "description": "Naik kuda berkeliling kebun",
  "price": 50000,
  "image": "file_upload"
}
```

{
  "date": "2026-03-15",
  "package_id": 1
}
```

### Order Management
```
GET  /admin/orders/pending        → List pesanan pending
GET  /admin/orders/detail/{id}    → Detail pesanan
GET  /admin/orders/verify-payment/{id} → Verifikasi pembayaran DP
GET  /admin/orders/confirm/{id}   → Konfirmasi pesanan
```

### Reports
```
GET  /admin/reports/sales         → Laporan penjualan
```

---

## Customer Routes

**Prefix:** `/customer`
**Filter:** `customer` (hanya user dengan role customer)

### Dashboard
```
GET /customer/dashboard           → Customer dashboard
```

### Order Management
```
GET  /customer/order/form                      → Form pemesanan
POST /customer/order/save                      → Simpan pesanan baru
GET  /customer/order/{id}                      → Detail pesanan
GET  /customer/order/{id}/payment              → Halaman pembayaran
POST /customer/order/{id}/get-snap-token       → Ambil Snap token untuk pembayaran
GET  /customer/order/{id}/download-pdf         → Download bukti PDF
GET  /customer/order/history                   → Riwayat semua pesanan
GET  /customer/api/available-dates             → AJAX: daftar tanggal tersedia
GET  /customer/api/date-capacity/{date}        → AJAX: kapasitas tersisa per tanggal
GET  /customer/api/check-availability/{date}/{num_participants} → AJAX: cek kapasitas untuk jumlah peserta
```

**Request Body untuk POST /customer/order/save:**
```json
{
  "school_name": "SMA Negeri 1",
  "booker_name": "Budi Santoso",
  "phone": "081234567890",
  "num_participants": 50,
  "num_guardians": 5,
  "package_id": 1,
  "visit_date": "2026-06-30",
  "attractions": [1, 2, 3]  // Optional: array of attraction IDs
}
```

---

## Pengelola Routes

**Prefix:** `/pengelola`
**Filter:** `pengelola` (hanya user dengan role pengelola)

### Dashboard
```
GET /pengelola/dashboard          → Pengelola dashboard
```

### Attraction Status Management
```
GET /pengelola/attractions        → List wahana dengan status toggle
GET /pengelola/attractions/update-status/{id} → Toggle aktif/nonaktif wahana
```

### Schedule Reports
```
GET /pengelola/reports/schedule   → Laporan jadwal pesanan
GET /pengelola/reports/schedule/{id} → Detail schedule dengan orders
```

---

## Owner Routes

**Prefix:** `/owner`
**Filter:** `owner` (hanya user dengan role owner)

### Dashboard
```
GET /owner/dashboard              → Owner dashboard (lastest stats)
```

### Reports
```
GET  /owner/reports/sales         → Laporan penjualan (dengan filter)
GET  /owner/reports/sales/download-pdf → Download laporan PDF
```

**Query Parameters:**
```
?month=3&year=2026
```

---

## Public Routes

### Pages (No Authentication Required)
```
GET  /pages/home                  → Halaman beranda
GET  /pages/about                 → Tentang wisata
GET  /pages/attractions           → Daftar wahana
GET  /pages/packages              → Daftar paket
GET  /pages/gallery               → Galeri foto
GET  /pages/contact               → Kontak
```

---

## Response Format

### Success Response (200 OK)
```json
{
  "success": true,
  "message": "Operation berhasil",
  "data": {
    // data content
  }
}
```

### Error Response (4xx/5xx)
```json
{
  "success": false,
  "message": "Error message",
  "errors": {
    "field_name": "Validation error message"
  }
}
```

### Redirect Response
- Success: Redirect ke halaman terkait dengan flash message `success`
- Error: Redirect back with flash message `error` dan `withInput()`

---

## AJAX Endpoints

### Get Available Dates
```
GET /customer/api/available-dates

Response:
{
  "success": true,
  "dates": [
    {
      "date": "2026-07-01",
      "available": 120
    }
  ]
}
```

### Get Date Capacity
```
GET /customer/api/date-capacity/{date}

Response:
{
  "success": true,
  "date": "2026-07-01",
  "available": 120,
  "is_full": false,
  "message": "Kapasitas tersedia: 120 peserta"
}
```

### Check Availability for Participants
```
GET /customer/api/check-availability/{date}/{num_participants}

Response:
{
  "success": true,
  "available": true  // atau false jika tidak tersedia
}
```

---

## HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request berhasil |
| 201 | Created - Resource berhasil dibuat |
| 400 | Bad Request - Validasi gagal |
| 401 | Unauthorized - Belum login |
| 403 | Forbidden - Akses ditolak (role tidak sesuai) |
| 404 | Not Found - Resource tidak ditemukan |
| 422 | Unprocessable Entity - Validasi gagal |
| 500 | Internal Server Error |

---

## Authentication & Authorization

### Session-based Authentication
- Login menyimpan data ke session: `user_id`, `user_name`, `user_email`, `user_role`
- Setiap request protected route di-filter via Filter classes
- Role check dilakukan di filter untuk prevent unauthorized access

### Available Roles
- `admin` - Admin penuh
- `customer` - Pelanggan yang bisa order
- `pengelola` - Manager wahana
- `owner` - Pemilik untuk melihat laporan

---

## Webhooks

### Midtrans Payment Webhook
```
POST /webhooks/midtrans

Body (dari Midtrans):
{
  "transaction_id": "xxx",
  "order_id": "ORDER-123-123456",
  "payment_type": "credit_card",
  "transaction_status": "settlement",
  "fraud_status": "accept",
  "gross_amount": "12750000"
}
```

---

## Rate Limiting (Optional)

Untuk production, implementasikan rate limiting:
```php
// Di Routes.php
$routes->group('api', ['filter' => 'throttle:60,1'], function($routes) {
    // routes here
});
```

---

## CORS Headers (Optional)

Jika akan diakses dari frontend terpisah:
```php
// Di .env
app.enableCORS = true

// Atau di Routes.php
$routes->options('(:any)', static function () {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
});
```

---

**Last Updated: 20 February 2026**
