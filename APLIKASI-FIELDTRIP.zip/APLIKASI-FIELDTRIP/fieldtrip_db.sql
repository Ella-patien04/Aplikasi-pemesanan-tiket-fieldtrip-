-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jul 2026 pada 03.15
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fieldtrip_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `attractions`
--

CREATE TABLE `attractions` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `attractions`
--

INSERT INTO `attractions` (`id`, `name`, `description`, `price`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Flying fox', 'flying fox adalah wahana uji adrenalin ', 35000.00, 'uploads/attractions/1780992888_0dbde81f7748445c8f02.jpeg', 1, '2026-06-09 01:14:48', '2026-07-01 13:41:48'),
(2, 'Outbond', '....', 30000.00, 'uploads/attractions/1782515389_6bb6f49dfb91489c1300.jpeg', 1, '2026-06-26 16:09:49', '2026-06-26 16:09:49'),
(3, 'Berkuda', 'Nikmati pengalaman seru menunggang kuda dengan suasana yang aman dan menyenangkan. penumpang akan diajak mengelilingi area wahana sambil merasakan sensasi berkuda yang cocok untuk anak-anak maupun deawasa. Aktivitas ini didampingi oleh petugas untuk memastikan kenyamanan dan keselamatan selama berkuda.', 25000.00, 'uploads/attractions/1782974080_dcbe40d538a944e6805e.jpeg', 0, '2026-07-01 23:34:40', '2026-07-12 16:18:27'),
(4, 'Feeding Animals', 'Berinteraksi langsung dengan hewan jinak dan memberi makan menggunakan pakan yang telah disediakan. Aktivitas edukatif yang aman dan menyenangkan untuk semua pengunjung.', 30000.00, 'uploads/attractions/1782974615_78fb5e2d6314a49c2f9d.jpeg', 1, '2026-07-01 23:43:35', '2026-07-01 23:43:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2026-02-20-000001', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', 1779971783, 1),
(2, '2026-02-20-000002', 'App\\Database\\Migrations\\CreatePackagesTable', 'default', 'App', 1779971783, 1),
(3, '2026-02-20-000003', 'App\\Database\\Migrations\\CreateAttractionsTable', 'default', 'App', 1779971783, 1),
(4, '2026-02-20-000004', 'App\\Database\\Migrations\\CreateSchedulesTable', 'default', 'App', 1779971783, 1),
(5, '2026-02-20-000005', 'App\\Database\\Migrations\\CreateOrdersTable', 'default', 'App', 1779971784, 1),
(6, '2026-02-20-000006', 'App\\Database\\Migrations\\CreateOrderAttractionItemsTable', 'default', 'App', 1779971784, 1),
(7, '2026-02-20-000007', 'App\\Database\\Migrations\\CreatePaymentLogTable', 'default', 'App', 1779971784, 1),
(8, '2026-02-20-000008', 'App\\Database\\Migrations\\CreateReportsTable', 'default', 'App', 1779971784, 1),
(9, '2026-05-26-000001', 'App\\Database\\Migrations\\AddNumTeachersToOrdersTable', 'default', 'App', 1779971784, 1),
(10, '2026-06-09-000006', 'App\\Database\\Migrations\\MigrateScheduleToVisitDate', 'default', 'App', 1781002094, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `visit_date` date DEFAULT NULL,
  `school_name` varchar(255) NOT NULL,
  `booker_name` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `num_participants` int(11) NOT NULL,
  `num_guardians` int(11) NOT NULL,
  `package_id` int(11) UNSIGNED NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `dp_amount` decimal(12,2) NOT NULL,
  `payment_status` enum('pending','dp_paid','paid','cancelled') NOT NULL DEFAULT 'pending',
  `order_status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  `confirmation_date` datetime DEFAULT NULL,
  `proof_payment_image` varchar(255) DEFAULT NULL,
  `verified_by` int(11) UNSIGNED DEFAULT NULL,
  `verified_date` datetime DEFAULT NULL,
  `pdf_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `num_teachers` int(11) DEFAULT 0,
  `fieldtrip_status` enum('pending','sedang_dilaksanakan','selesai') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `visit_date`, `school_name`, `booker_name`, `phone`, `num_participants`, `num_guardians`, `package_id`, `total_price`, `dp_amount`, `payment_status`, `order_status`, `confirmation_date`, `proof_payment_image`, `verified_by`, `verified_date`, `pdf_token`, `created_at`, `updated_at`, `num_teachers`, `fieldtrip_status`) VALUES
(8, 6, '2026-06-21', 'al markaz', 'Alya', '083817955190', 35, 5, 1, 2600000.00, 780000.00, 'paid', 'confirmed', '2026-07-02 06:18:28', NULL, 3, '2026-07-02 06:18:21', NULL, '2026-06-19 20:26:01', '2026-07-12 17:44:06', 5, 'selesai'),
(9, 1, '2026-06-25', 'sdn', 'Ana', '088948237263', 75, 10, 1, 5415000.00, 1624500.00, 'paid', 'confirmed', '2026-07-02 06:19:46', NULL, 3, '2026-07-02 06:18:15', NULL, '2026-06-20 18:11:55', '2026-07-12 17:15:56', 6, 'selesai'),
(11, 1, '2026-06-23', 'al markaz', 'Ana', '0387955190', 15, 7, 1, 1230000.00, 369000.00, 'paid', 'confirmed', '2026-07-02 06:17:14', NULL, 3, '2026-07-02 06:16:45', NULL, '2026-06-20 20:21:26', '2026-07-12 17:26:27', 5, 'selesai'),
(13, 6, '2026-06-25', 'al markaz', 'Alya', '083817955190', 120, 15, 1, 12900000.00, 3870000.00, 'paid', 'confirmed', '2026-07-02 06:16:39', NULL, 3, '2026-07-02 06:16:30', NULL, '2026-06-22 18:32:04', '2026-07-12 17:45:20', 10, 'selesai'),
(16, 6, '2026-06-24', 'Miftahul Hayat', 'Alya', '083817955190', 100, 20, 2, 13950000.00, 4185000.00, 'paid', 'confirmed', '2026-07-02 06:16:06', NULL, 3, '2026-07-02 00:01:41', NULL, '2026-06-22 20:16:20', '2026-07-12 17:46:39', 15, 'selesai'),
(17, 6, '2026-06-26', 'al markaz', 'alya', '0391955190', 75, 15, 1, 8100000.00, 2430000.00, 'paid', 'confirmed', '2026-07-02 06:15:47', NULL, 3, '2026-07-02 00:01:31', NULL, '2026-06-22 21:03:21', '2026-07-12 17:47:49', 5, 'selesai'),
(18, 6, '2026-06-26', 'alya', 'al markaz', '0831955190', 75, 15, 1, 8175000.00, 2452500.00, 'paid', 'confirmed', '2026-07-02 06:16:23', NULL, 3, '2026-07-02 06:16:12', NULL, '2026-06-22 21:10:03', '2026-07-12 17:49:39', 10, 'selesai'),
(19, 6, '2026-06-26', 'alya', 'al markaz', '083817955190', 75, 15, 1, 8175000.00, 2452500.00, 'paid', 'confirmed', '2026-07-02 06:15:32', NULL, 3, '2026-06-27 03:50:59', NULL, '2026-06-22 21:13:08', '2026-07-12 17:50:50', 10, 'selesai'),
(22, 1, '2026-06-30', 'al markaz', 'Ella', '083817955190', 75, 10, 1, 7725000.00, 2317500.00, 'paid', 'confirmed', NULL, NULL, 3, '2026-07-02 00:01:11', NULL, '2026-06-28 22:38:50', '2026-07-01 21:43:48', 10, 'selesai'),
(23, 1, '2026-07-01', 'al markaz', 'Ella', '083817955190', 100, 10, 2, 13195000.00, 3958500.00, 'paid', 'confirmed', NULL, NULL, 3, '2026-07-02 00:01:00', NULL, '2026-06-29 06:36:20', '2026-07-01 21:41:29', 8, 'selesai'),
(24, 1, '2026-07-02', 'al markaz', 'Ella', '083817955190', 75, 5, 1, 7590000.00, 2277000.00, 'paid', 'confirmed', '2026-07-02 06:03:05', NULL, 3, '2026-07-02 00:00:50', NULL, '2026-06-29 14:52:08', '2026-07-12 17:29:57', 6, 'selesai'),
(25, 1, '2026-07-04', 'al markaz', 'Ella', '083817955190', 80, 20, 2, 10775000.00, 3232500.00, 'paid', 'confirmed', NULL, NULL, 3, '2026-07-02 04:49:17', NULL, '2026-07-01 13:26:58', '2026-07-12 17:31:11', 10, 'selesai'),
(26, 1, '2026-07-05', 'al markaz', 'Ella', '083817955190', 85, 20, 1, 9330000.00, 2799000.00, 'paid', 'confirmed', NULL, NULL, NULL, NULL, NULL, '2026-07-01 21:33:31', '2026-07-12 17:32:42', 12, 'selesai'),
(27, 1, '2026-07-16', 'al markaz', 'Ella', '083817955190', 100, 20, 1, 10450000.00, 3135000.00, 'dp_paid', 'confirmed', '2026-07-12 23:43:13', NULL, 3, '2026-07-12 23:43:01', NULL, '2026-07-12 16:20:51', '2026-07-12 16:43:13', 15, 'pending'),
(28, 1, '2026-07-16', 'al markaz', 'Ella', '083817955190', 200, 50, 2, 20900000.00, 6270000.00, 'dp_paid', 'confirmed', NULL, NULL, NULL, NULL, NULL, '2026-07-12 16:37:52', '2026-07-12 16:39:09', 20, 'pending'),
(29, 6, '2026-07-15', 'Miftahul Hayat', 'Alya', '0387955190', 100, 10, 3, 16225000.00, 4867500.00, 'dp_paid', 'confirmed', NULL, NULL, NULL, NULL, NULL, '2026-07-12 17:53:42', '2026-07-12 17:54:23', 10, 'pending'),
(30, 1, '2026-07-18', 'al markaz', 'Ella', '083817955190', 100, 0, 2, 13075000.00, 3922500.00, 'dp_paid', 'confirmed', NULL, NULL, NULL, NULL, NULL, '2026-07-17 01:24:08', '2026-07-17 01:25:10', 10, 'pending'),
(31, 1, '2026-07-19', 'al markaz', 'Ella', '083817955190', 100, 25, 1, 10950000.00, 3285000.00, 'pending', 'pending', NULL, NULL, NULL, NULL, NULL, '2026-07-18 02:28:00', '2026-07-18 02:28:00', 10, 'pending'),
(32, 1, '2026-07-23', 'al markaz', 'Ella', '083817955190', 100, 20, 2, 10450000.00, 3135000.00, 'dp_paid', 'confirmed', NULL, NULL, NULL, NULL, NULL, '2026-07-22 09:18:04', '2026-07-22 09:21:46', 15, 'pending'),
(33, 1, '2026-07-24', 'al markaz', 'Ella', '083817955190', 200, 15, 2, 27225000.00, 8167500.00, 'pending', 'pending', NULL, NULL, NULL, NULL, NULL, '2026-07-22 18:51:51', '2026-07-22 18:51:51', 10, 'pending');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_attraction_items`
--

CREATE TABLE `order_attraction_items` (
  `id` int(11) UNSIGNED NOT NULL,
  `order_id` int(11) UNSIGNED NOT NULL,
  `attraction_id` int(11) UNSIGNED NOT NULL,
  `price_at_booking` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `order_attraction_items`
--

INSERT INTO `order_attraction_items` (`id`, `order_id`, `attraction_id`, `price_at_booking`, `quantity`, `created_at`, `updated_at`) VALUES
(4, 13, 1, 35000.00, 120, '2026-06-22 18:32:04', '2026-06-22 18:32:04'),
(6, 16, 1, 35000.00, 100, '2026-06-22 20:16:20', '2026-06-22 20:16:20'),
(7, 17, 1, 35000.00, 75, '2026-06-22 21:03:21', '2026-06-22 21:03:21'),
(8, 18, 1, 35000.00, 75, '2026-06-22 21:10:03', '2026-06-22 21:10:03'),
(9, 19, 1, 35000.00, 75, '2026-06-22 21:13:08', '2026-06-22 21:13:08'),
(11, 22, 2, 30000.00, 75, '2026-06-28 22:38:50', '2026-06-28 22:38:50'),
(12, 23, 2, 30000.00, 100, '2026-06-29 06:36:20', '2026-06-29 06:36:20'),
(13, 24, 2, 30000.00, 75, '2026-06-29 14:52:09', '2026-06-29 14:52:09'),
(14, 25, 2, 30000.00, 80, '2026-07-01 13:26:58', '2026-07-01 13:26:58'),
(15, 26, 1, 35000.00, 85, '2026-07-01 21:33:32', '2026-07-01 21:33:32'),
(16, 27, 4, 30000.00, 100, '2026-07-12 16:20:51', '2026-07-12 16:20:51'),
(17, 29, 2, 30000.00, 100, '2026-07-12 17:53:42', '2026-07-12 17:53:42'),
(18, 30, 2, 30000.00, 100, '2026-07-17 01:24:08', '2026-07-17 01:24:08'),
(19, 31, 1, 35000.00, 100, '2026-07-18 02:28:00', '2026-07-18 02:28:00'),
(20, 33, 1, 35000.00, 200, '2026-07-22 18:51:51', '2026-07-22 18:51:51');

-- --------------------------------------------------------

--
-- Struktur dari tabel `packages`
--

CREATE TABLE `packages` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `facilities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`facilities`)),
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `packages`
--

INSERT INTO `packages` (`id`, `name`, `description`, `price`, `facilities`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Ula', 'Paket Ula – 70K\r\nPaket hemat dengan pengalaman belajar yang tetap seru dan berkesan untuk anak-anak. Dalam paket ini, peserta akan diajak mengenal dunia pertanian dan alam secara langsung melalui aktivitas edukatif yang menyenangkan. Mulai dari tour greenhouse anggur, melon, dan sayur, bermain di mini zoo, hingga praktik hidroponik dan menanam padi yang menambah wawasan serta pengalaman baru. Cocok untuk sekolah yang ingin memberikan kegiatan field trip edukatif dengan harga terjangkau namun tetap lengkap dan menyenangkan.', 70000.00, '\"[\\\"paket ayam chicken\\\",\\\"GH tour anggur melon dan sayur\\\",\\\"akses taman sayur dan taman bunga\\\",\\\"akses mini zoo\\\",\\\"akses obstacle  air\\\",\\\"outbound\\\\\\/flying Fox\\\",\\\"dua item belajar pertanian (menanam padi hidroponik\\\",\\\"menangkap ikan)\\\",\\\"guru free 1:20 orang.\\\"]\"', 'uploads/packages/1780984632_da33d34bc66b34656816.jpeg', 1, '2026-06-08 22:57:12', '2026-06-08 22:57:12'),
(2, 'Wushto', 'Paket Wushto – 100K\r\nPaket favorit dengan kombinasi edukasi, petualangan, dan aktivitas interaktif yang lebih lengkap. Selain menikmati wisata edukasi pertanian dan mini zoo, peserta juga dapat merasakan keseruan outbound dan flying fox yang melatih keberanian serta kekompakan. Anak-anak juga akan belajar langsung melalui dua aktivitas pertanian pilihan seperti menanam padi, menangkap ikan, atau hidroponik. Paket ini sangat cocok untuk menciptakan pengalaman field trip yang aktif, seru, sekaligus penuh pembelajaran.', 100000.00, '\"[\\\"Paket ayam chicken\\\",\\\"GH tour anggur melon dan sayur\\\",\\\"akses taman sayur dan taman bunga\\\",\\\"akses mini zoo\\\",\\\"akses obstacle  air\\\",\\\"outbound\\\\\\/flying Fox\\\",\\\"dua item belajar pertanian (menanam padi hidroponik\\\",\\\"menangkap ikan)\\\",\\\"guru free 1:20 orang.\\\"]\"', 'uploads/packages/1780984829_cb3a6227db7da72603d8.jpeg', 1, '2026-06-08 23:00:29', '2026-06-08 23:00:29'),
(3, 'Ulya', 'Paket Ulya – 130K\r\nPaket paling lengkap dengan pengalaman field trip premium yang menggabungkan edukasi, petualangan, dan interaksi alam dalam satu kegiatan. Peserta akan menikmati seluruh fasilitas terbaik mulai dari greenhouse tour, taman bunga, mini zoo, obstacle air, outbound, flying fox, hingga berkuda. Tidak hanya bermain, anak-anak juga belajar langsung melalui tiga aktivitas pertanian edukatif seperti menanam padi, menangkap ikan, dan hidroponik. Paket ini dirancang untuk memberikan pengalaman field trip yang tak terlupakan, menyenangkan, sekaligus penuh nilai edukasi bagi siswa.', 130000.00, '\"[\\\"Paket ayam chicken\\\",\\\"GH tour anggur melon dan sayur\\\",\\\"akses taman sayur dan taman bunga\\\",\\\"akses mini zoo\\\",\\\"akses obstacle  air\\\",\\\"outbound\\\",\\\"flying Fox\\\",\\\"berkuda (bisa mix)\\\",\\\"tiga item belajar pertanian (menanam padi hidroponik\\\",\\\"menangkap ikan)\\\",\\\"guru free 1:20 orang.\\\"]\"', 'uploads/packages/1780984971_85a7e76db0d95aad60fd.jpeg', 1, '2026-06-08 23:02:51', '2026-06-08 23:02:51');

-- --------------------------------------------------------

--
-- Struktur dari tabel `payment_log`
--

CREATE TABLE `payment_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `order_id` int(11) UNSIGNED NOT NULL,
  `midtrans_snap_id` varchar(255) DEFAULT NULL,
  `midtrans_transaction_id` varchar(255) DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `payment_log`
--

INSERT INTO `payment_log` (`id`, `order_id`, `midtrans_snap_id`, `midtrans_transaction_id`, `reference_number`, `amount`, `status`, `payment_method`, `created_at`, `updated_at`) VALUES
(1, 22, '80396e81-60e0-4347-914b-667b7ea3b4b4', NULL, NULL, 2317500.00, 'pending', NULL, '2026-06-28 22:38:54', '2026-06-28 22:38:54'),
(2, 23, '228960e6-c9ae-41d4-ae6f-5461993c77c4', NULL, NULL, 3958500.00, 'pending', NULL, '2026-06-29 06:36:26', '2026-06-29 06:36:26'),
(3, 24, 'baeb6e10-0a02-4f77-9cc4-472c91af94cf', NULL, NULL, 2277000.00, 'pending', NULL, '2026-06-29 14:52:13', '2026-06-29 14:52:13'),
(4, 25, 'bce0f8e3-8d4c-44c2-ab2a-f1613e301aa5', NULL, NULL, 3232500.00, 'pending', NULL, '2026-07-01 13:27:03', '2026-07-01 13:27:03'),
(7, 25, NULL, 'FT-25-DP', NULL, 3232500.00, 'paid', 'dana', '2026-07-01 20:39:33', '2026-07-01 20:39:33'),
(9, 25, NULL, 'FT-25-DP', NULL, 3232500.00, 'paid', 'dana', '2026-07-01 20:39:36', '2026-07-01 20:39:36'),
(10, 25, NULL, 'FT-25-DP', NULL, 3232500.00, 'paid', 'dana', '2026-07-01 20:39:38', '2026-07-01 20:39:38'),
(12, 25, NULL, 'FT-25-DP', NULL, 3232500.00, 'paid', 'dana', '2026-07-01 20:39:40', '2026-07-01 20:39:40'),
(13, 25, NULL, 'FT-25-DP', NULL, 3232500.00, 'paid', 'dana', '2026-07-01 20:39:42', '2026-07-01 20:39:42'),
(14, 25, NULL, 'FT-25-DP', NULL, 3232500.00, 'paid', 'dana', '2026-07-01 20:39:44', '2026-07-01 20:39:44'),
(18, 26, '1fafe847-0f83-4c28-a225-097618f23642', NULL, NULL, 2799000.00, 'pending', NULL, '2026-07-01 21:33:35', '2026-07-01 21:33:35'),
(19, 26, NULL, 'FT-26-DP', NULL, 2799000.00, 'paid', 'dana', '2026-07-01 21:34:16', '2026-07-01 21:34:16'),
(20, 23, 'b3a5a665-c397-49d8-b641-a1ee076959fe', NULL, NULL, 9236500.00, 'pending', NULL, '2026-07-01 21:41:01', '2026-07-01 21:41:01'),
(21, 23, NULL, 'FT-23-FINAL', NULL, 9236500.00, 'paid', 'dana', '2026-07-01 21:41:29', '2026-07-01 21:41:29'),
(22, 22, '11da68e2-851b-4d8a-9f8c-8635f1226561', NULL, NULL, 5407500.00, 'pending', NULL, '2026-07-01 21:43:19', '2026-07-01 21:43:19'),
(23, 22, NULL, 'FT-22-FINAL', NULL, 5407500.00, 'paid', 'dana', '2026-07-01 21:43:48', '2026-07-01 21:43:48'),
(24, 27, '13c4434c-183c-40a6-8a10-2d8472303804', NULL, NULL, 3135000.00, 'pending', NULL, '2026-07-12 16:20:55', '2026-07-12 16:20:55'),
(25, 28, '1319577d-b237-4f9e-ab66-bdb67dceff78', NULL, NULL, 6270000.00, 'pending', NULL, '2026-07-12 16:37:53', '2026-07-12 16:37:53'),
(26, 28, NULL, 'FT-28-DP', NULL, 6270000.00, 'paid', 'bank_transfer', '2026-07-12 16:39:09', '2026-07-12 16:39:09'),
(27, 9, '058c3559-7263-4866-9368-745eb1b3bc91', NULL, NULL, 3790500.00, 'pending', NULL, '2026-07-12 17:14:47', '2026-07-12 17:14:47'),
(28, 9, NULL, 'FT-9-FINAL', NULL, 3790500.00, 'paid', 'bank_transfer', '2026-07-12 17:15:56', '2026-07-12 17:15:56'),
(30, 11, '25e08fca-8e13-4379-83cf-1b51a0f74530', NULL, NULL, 861000.00, 'pending', NULL, '2026-07-12 17:23:08', '2026-07-12 17:23:08'),
(31, 11, NULL, 'FT-11-FINAL', NULL, 861000.00, 'paid', 'echannel', '2026-07-12 17:26:27', '2026-07-12 17:26:27'),
(32, 24, 'bf393d6c-bac9-4db2-8e8a-2eaf3977d220', NULL, NULL, 5313000.00, 'pending', NULL, '2026-07-12 17:29:02', '2026-07-12 17:29:02'),
(33, 24, NULL, 'FT-24-FINAL', NULL, 5313000.00, 'paid', 'ovo', '2026-07-12 17:29:57', '2026-07-12 17:29:57'),
(34, 25, '9db43916-ef7d-46ea-b3c4-f62ce926cf74', NULL, NULL, 7542500.00, 'pending', NULL, '2026-07-12 17:30:21', '2026-07-12 17:30:21'),
(35, 25, NULL, 'FT-25-FINAL', NULL, 7542500.00, 'paid', 'dana', '2026-07-12 17:31:11', '2026-07-12 17:31:11'),
(36, 26, '39dd713f-3291-4d98-8792-43b9f3c32bab', NULL, NULL, 6531000.00, 'pending', NULL, '2026-07-12 17:31:57', '2026-07-12 17:31:57'),
(37, 26, NULL, 'FT-26-FINAL', NULL, 6531000.00, 'paid', 'ovo', '2026-07-12 17:32:42', '2026-07-12 17:32:42'),
(38, 8, '8b77ede4-3fae-4c89-9b33-69606a61f337', NULL, NULL, 1820000.00, 'pending', NULL, '2026-07-12 17:43:02', '2026-07-12 17:43:02'),
(39, 8, NULL, 'FT-8-FINAL', NULL, 1820000.00, 'paid', 'ovo', '2026-07-12 17:44:07', '2026-07-12 17:44:07'),
(40, 13, '7c5372db-e146-4607-a150-a26c4ae76689', NULL, NULL, 9030000.00, 'pending', NULL, '2026-07-12 17:44:28', '2026-07-12 17:44:28'),
(41, 13, NULL, 'FT-13-FINAL', NULL, 9030000.00, 'paid', 'ovo', '2026-07-12 17:45:20', '2026-07-12 17:45:20'),
(42, 16, 'ea41d430-e821-4f18-8579-6172efa23c1f', NULL, NULL, 9765000.00, 'pending', NULL, '2026-07-12 17:45:53', '2026-07-12 17:45:53'),
(43, 16, NULL, 'FT-16-FINAL', NULL, 9765000.00, 'paid', 'bank_transfer', '2026-07-12 17:46:39', '2026-07-12 17:46:39'),
(44, 17, '091ef5c4-af36-445f-9bba-787074931416', NULL, NULL, 5670000.00, 'pending', NULL, '2026-07-12 17:47:15', '2026-07-12 17:47:15'),
(45, 17, NULL, 'FT-17-FINAL', NULL, 5670000.00, 'paid', 'bank_transfer', '2026-07-12 17:47:49', '2026-07-12 17:47:49'),
(46, 18, '4b23087d-8591-4050-b4f9-0d836fe659fe', NULL, NULL, 5722500.00, 'pending', NULL, '2026-07-12 17:48:20', '2026-07-12 17:48:20'),
(47, 18, NULL, 'FT-18-FINAL', NULL, 5722500.00, 'paid', 'bank_transfer', '2026-07-12 17:49:39', '2026-07-12 17:49:39'),
(48, 19, 'c1fe6834-b5c8-4434-b5d2-2907f2ba22e7', NULL, NULL, 5722500.00, 'pending', NULL, '2026-07-12 17:50:10', '2026-07-12 17:50:10'),
(49, 19, NULL, 'FT-19-FINAL', NULL, 5722500.00, 'paid', 'bank_transfer', '2026-07-12 17:50:50', '2026-07-12 17:50:50'),
(50, 29, 'a457c0be-31ae-43e4-aa5d-5e371b7c38c2', NULL, NULL, 4867500.00, 'pending', NULL, '2026-07-12 17:53:44', '2026-07-12 17:53:44'),
(51, 29, NULL, 'FT-29-DP', NULL, 4867500.00, 'paid', 'bank_transfer', '2026-07-12 17:54:23', '2026-07-12 17:54:23'),
(52, 30, 'a5e0cf06-756e-4d24-8765-03ead2c54912', NULL, NULL, 3922500.00, 'pending', NULL, '2026-07-17 01:24:13', '2026-07-17 01:24:13'),
(53, 30, NULL, 'FT-30-DP', NULL, 3922500.00, 'paid', 'dana', '2026-07-17 01:25:10', '2026-07-17 01:25:10'),
(54, 31, '7b2bbbd9-42c6-4322-8de6-84a3f5ebb92b', NULL, NULL, 3285000.00, 'pending', NULL, '2026-07-18 02:28:04', '2026-07-18 02:28:04'),
(55, 32, '541ed823-33e0-4493-8ba0-5423e4907a14', NULL, NULL, 3135000.00, 'pending', NULL, '2026-07-22 09:18:12', '2026-07-22 09:18:12'),
(56, 32, NULL, 'FT-32-DP', NULL, 3135000.00, 'paid', 'dana', '2026-07-22 09:21:46', '2026-07-22 09:21:46'),
(57, 33, '5700d887-9e5d-4d42-b932-b6e45857ff34', NULL, NULL, 8167500.00, 'pending', NULL, '2026-07-22 18:51:55', '2026-07-22 18:51:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `reports`
--

CREATE TABLE `reports` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` enum('sales','schedule') NOT NULL,
  `filter_month` int(11) DEFAULT NULL,
  `filter_year` int(11) DEFAULT NULL,
  `total_revenue` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_orders` int(11) NOT NULL DEFAULT 0,
  `created_by` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `max_participants` int(11) NOT NULL DEFAULT 300,
  `current_reserved` int(11) NOT NULL DEFAULT 0,
  `package_id` int(11) UNSIGNED NOT NULL,
  `status` enum('available','full','cancelled') NOT NULL DEFAULT 'available',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role` enum('admin','customer','pengelola','owner') NOT NULL DEFAULT 'customer',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `otp_code` varchar(10) DEFAULT NULL,
  `otp_expired_at` datetime DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expired_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `role`, `is_active`, `created_at`, `updated_at`, `otp_code`, `otp_expired_at`, `reset_token`, `reset_token_expired_at`) VALUES
(1, 'Ella', 'hulelahella2504@gmail.com', '$2y$10$lye1mJFZ59c1YCDuQ4pjPe9zqSYwZBO3LZ3U.fYX2ynw9bJKvMz7C', '083817955190', 'customer', 1, '2026-05-28 05:51:04', '2026-07-12 23:23:52', '936170', '2026-07-13 06:38:52', NULL, NULL),
(3, 'Admin Fieldtrip', 'admin@example.com', '$2y$10$emPv8JkYRmZ/INhV3kfMt.qQhx9wLiWk4.UIKDd2/XP8HOvtCLKde', '081234567890', 'admin', 1, '2026-05-28 14:52:38', '2026-05-28 14:52:38', NULL, NULL, NULL, NULL),
(4, 'Pengelola Fieldtrip', 'pengelola@example.com', '$2y$10$KhCcZ1JX68e.y545MIp./Ow0wKXAQjxcZUBOI6pw/u0lgW1NrZu2K', '081234567891', 'pengelola', 1, '2026-05-28 14:52:38', '2026-05-28 14:52:38', NULL, NULL, NULL, NULL),
(5, 'Owner Fieldtrip', 'owner@example.com', '$2y$10$BngxGnULpSWbaP4r1I3FeeULv9pqUg6lkkxfH5jx7G6Lm2FY3AM.6', '081234567892', 'owner', 1, '2026-05-28 14:52:38', '2026-05-28 14:52:38', NULL, NULL, NULL, NULL),
(6, 'alya alisya putri', 'ponpesalmarkaz19@gmail.com', '$2y$10$s.a3JMU3r/NkiYML.Tx83eF6cctvWooFZ/PRQdZod.FHGWgPX6PTG', '083817955190', 'customer', 1, '2026-06-19 19:57:21', '2026-06-19 19:57:21', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `attractions`
--
ALTER TABLE `attractions`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_package_id_foreign` (`package_id`),
  ADD KEY `orders_verified_by_foreign` (`verified_by`);

--
-- Indeks untuk tabel `order_attraction_items`
--
ALTER TABLE `order_attraction_items`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `order_attraction_items_order_id_foreign` (`order_id`),
  ADD KEY `order_attraction_items_attraction_id_foreign` (`attraction_id`);

--
-- Indeks untuk tabel `packages`
--
ALTER TABLE `packages`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indeks untuk tabel `payment_log`
--
ALTER TABLE `payment_log`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `payment_log_order_id_foreign` (`order_id`);

--
-- Indeks untuk tabel `reports`
--
ALTER TABLE `reports`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `reports_created_by_foreign` (`created_by`);

--
-- Indeks untuk tabel `schedules`
--
ALTER TABLE `schedules`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `schedules_package_id_foreign` (`package_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role` (`role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `attractions`
--
ALTER TABLE `attractions`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `order_attraction_items`
--
ALTER TABLE `order_attraction_items`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `payment_log`
--
ALTER TABLE `payment_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT untuk tabel `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL;

--
-- Ketidakleluasaan untuk tabel `order_attraction_items`
--
ALTER TABLE `order_attraction_items`
  ADD CONSTRAINT `order_attraction_items_attraction_id_foreign` FOREIGN KEY (`attraction_id`) REFERENCES `attractions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_attraction_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `payment_log`
--
ALTER TABLE `payment_log`
  ADD CONSTRAINT `payment_log_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
