-- Fieldtrip project schema
-- SQL file generated from app/Database/Migrations

CREATE DATABASE IF NOT EXISTS `fieldtrip_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `fieldtrip_db`;

-- users
CREATE TABLE `users` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(15) DEFAULT NULL,
  `role` ENUM('admin','customer','pengelola','owner') NOT NULL DEFAULT 'customer',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- packages
CREATE TABLE `packages` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `facilities` JSON DEFAULT NULL,
  `image` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- attractions
CREATE TABLE `attractions` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `image` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- schedules
CREATE TABLE `schedules` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` DATE NOT NULL,
  `max_participants` INT(11) NOT NULL DEFAULT 300,
  `current_reserved` INT(11) NOT NULL DEFAULT 0,
  `package_id` INT(11) UNSIGNED NOT NULL,
  `status` ENUM('available','full','cancelled') NOT NULL DEFAULT 'available',
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `package_id` (`package_id`),
  CONSTRAINT `fk_schedules_package` FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- orders
CREATE TABLE `orders` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `visit_date` DATE NOT NULL,
  `school_name` VARCHAR(255) NOT NULL,
  `booker_name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(15) NOT NULL,
  `num_participants` INT(11) NOT NULL,
  `num_guardians` INT(11) NOT NULL,
  `num_teachers` INT(11) NOT NULL DEFAULT 0,
  `package_id` INT(11) UNSIGNED NOT NULL,
  `total_price` DECIMAL(12,2) NOT NULL,
  `dp_amount` DECIMAL(12,2) NOT NULL,
  `payment_status` ENUM('pending','dp_paid','paid','cancelled') NOT NULL DEFAULT 'pending',
  `order_status` ENUM('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  `confirmation_date` DATETIME DEFAULT NULL,
  `proof_payment_image` VARCHAR(255) DEFAULT NULL,
  `verified_by` INT(11) UNSIGNED DEFAULT NULL,
  `verified_date` DATETIME DEFAULT NULL,
  `pdf_token` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `package_id` (`package_id`),
  KEY `verified_by` (`verified_by`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_orders_package` FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_orders_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- order_attraction_items
CREATE TABLE `order_attraction_items` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INT(11) UNSIGNED NOT NULL,
  `attraction_id` INT(11) UNSIGNED NOT NULL,
  `price_at_booking` DECIMAL(10,2) NOT NULL,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `attraction_id` (`attraction_id`),
  CONSTRAINT `fk_item_order` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_item_attraction` FOREIGN KEY (`attraction_id`) REFERENCES `attractions`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- payment_log
CREATE TABLE `payment_log` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INT(11) UNSIGNED NOT NULL,
  `midtrans_snap_id` VARCHAR(255) DEFAULT NULL,
  `midtrans_transaction_id` VARCHAR(255) DEFAULT NULL,
  `reference_number` VARCHAR(100) DEFAULT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `payment_method` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `fk_payment_order` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- reports
CREATE TABLE `reports` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `type` ENUM('sales','schedule') NOT NULL,
  `filter_month` INT(11) DEFAULT NULL,
  `filter_year` INT(11) DEFAULT NULL,
  `total_revenue` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `total_orders` INT(11) NOT NULL DEFAULT 0,
  `created_by` INT(11) UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `fk_reports_user` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional: initial accounts (recommended to run seeder instead for proper password hashing)
-- You can import these rows only if you replace hashed_password_here with real bcrypt hashes,
-- or run the seeder: php spark db:seed UserSeeder
-- INSERT INTO `users` (`name`,`email`,`password`,`phone`,`role`,`is_active`,`created_at`,`updated_at`) VALUES
-- ('Admin Fieldtrip','admin@example.com','hashed_password_here','081234567890','admin',1,NOW(),NOW());

COMMIT;
