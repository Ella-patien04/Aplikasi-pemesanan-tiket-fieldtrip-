# SETUP & INSTALASI APLIKASI PEMESANAN FIELDTRIP

## 1. SETUP DATABASE

### Langkah 1: Konfigurasi Database

Buka file `.env` dan sesuaikan konfigurasi database:

```
database.default.hostname = localhost
database.default.database = fieldtrip_db
database.default.username = root
database.default.password = 
database.default.DBDriver = MySQLi
```

### Langkah 2: Buat Database

```sql
CREATE DATABASE fieldtrip_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Langkah 3: Jalankan Migrasi

```bash
php spark migrate
```

Migrasi akan membuat semua tabel yang diperlukan:
- users (tabel user dengan 4 role: admin, customer, pengelola, owner)
- packages (paket fieldtrip)
- attractions (wahana satuan)
- schedules (jadwal fieldtrip)
- orders (pemesanan)
- order_attraction_items (detail wahana per pemesanan)
- payment_log (log pembayaran)
- reports (laporan penjualan)

Jika migrasi gagal karena tabel sudah ada tetapi status migrasi belum tercatat,
jalankan skrip berikut untuk menandai semua file migrasi sebagai sudah diterapkan:

```bash
php scripts/fix_migration_state.php
```

Kemudian jalankan kembali:

```bash
php spark migrate
```

### Langkah 4: Seeder Data (Optional)

Jika ingin menambah data dummy, jalankan:

```bash
php spark db:seed SampleSeeder
```

## 2. KONFIGURASI PAYMENT GATEWAY (Midtrans)

### Langkah 1: Registrasi Midtrans

1. Daftar di https://midtrans.com
2. Buat akun merchant
3. Ambil Server Key dan Client Key dari dashboard

### Langkah 2: Setup .env

Tambahkan ke file `.env`:

```
MIDTRANS_SERVER_KEY = your_server_key
MIDTRANS_CLIENT_KEY = your_client_key
MIDTRANS_ENV = SANDBOX  # Ubah ke PRODUCTION untuk production

# Optional: Untuk testing/development
PAYMENT_SIMULATION = true
```

### Langkah 3: Install Midtrans SDK

```bash
composer require midtrans/midtrans-php
```

Untuk PDF generation:

```bash
composer require dompdf/dompdf
```

Jika `composer install` memberi peringatan bahwa `composer.lock` tidak sesuai dengan `composer.json`, jalankan:

```bash
composer update
```

Ini akan memperbarui lock file dan menginstal dependensi yang dibutuhkan.

### Langkah 4: Load Helper di BaseController

Edit `app/Controllers/BaseController.php`:

```php
public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
{
    parent::initController($request, $response, $logger);
    
    // Load helpers
    helper('pdf');
    helper('payment');
}
```

## 3. SETUP FOLDER UPLOADS

Buat folder untuk upload files:

```bash
mkdir public/uploads/packages
mkdir public/uploads/attractions
mkdir public/uploads/payments
chmod 755 public/uploads/packages
chmod 755 public/uploads/attractions
chmod 755 public/uploads/payments
```

## 4. SETUP SESSION

Session di CodeIgniter 4 menggunakan database secara default. Pastikan table sessions sudah ada:

```bash
php spark session:migration
php spark migrate
```

## 5. TESTING APLIKASI

### Langkah 1: Buat Admin Default

Setelah database sudah siap, jalankan seeder admin untuk membuat akun admin default:

```bash
php spark db:seed AdminSeeder
```

Output yang diharapkan:
```
Admin account created: admin@gmail.com
Credentials:
  Email: admin@gmail.com
  Password: 123456
```

### Langkah 2: Akun Testing Default

#### Admin
- Email: admin@gmail.com
- Password: 123456
- URL: http://localhost:8080/auth/admin-login

#### Customer
- Bisa membuat akun sendiri melalui: http://localhost:8080/auth/register
- URL Login: http://localhost:8080/auth/login

#### Pengelola (Optional)
- Email: pengelola@example.com
- Password: Pengelola123
- (Jika menggunakan UserSeeder)

#### Owner (Optional)
- Email: owner@example.com
- Password: Owner1234
- (Jika menggunakan UserSeeder)

### Langkah 3: Testing Login Flows

**Login Admin (Khusus):**
```
1. Akses: http://localhost:8080/auth/admin-login
2. Masukkan email: admin@gmail.com
3. Masukkan password: 123456
4. Klik tombol "Login"
5. Jika berhasil → redirect ke: /admin/dashboard
6. Session tersimpan dengan role: admin
```

**Login Customer (Umum):**
```
1. Akses: http://localhost:8080/auth/login
2. Masukkan email customer
3. Masukkan password
4. Jika berhasil → redirect ke: /dashboard
5. Session tersimpan dengan role: customer
```

**Logout:**
```
1. Klik tombol Logout (ada di navbar/dashboard)
2. Session dihapus
3. Redirect ke: http://localhost:8080/
4. Bisa login lagi
```

### Langkah 4: Ganti Password Admin (Optional)

Password hash menggunakan `PASSWORD_DEFAULT` untuk keamanan maksimal.

Untuk mengganti password admin:

```php
// Di dalam database atau programmatic
$newPassword = password_hash('password_baru', PASSWORD_DEFAULT);
// Update tabel users set password = $newPassword where email = 'admin@gmail.com'
```

Atau gunakan command:
```bash
php spark db:seed AdminSeeder  # Reset ke password default (123456)
```

### Langkah 5: URL Aplikasi Setelah Login

**Dashboard:**
```
Umum: http://localhost:8080/dashboard
Admin: http://localhost:8080/admin/dashboard
Customer: http://localhost:8080/customer/dashboard
Pengelola: http://localhost:8080/pengelola/dashboard
Owner: http://localhost:8080/owner/dashboard
```

### Akun Testing:

## 6. SECURITY & AUTHENTICATION

### Sistem Keamanan Login

Aplikasi menggunakan sistem keamanan yang kuat dengan:

#### Password Hashing dengan bcrypt

```php
// Saat registrasi atau seeder
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);
// PASSWORD_DEFAULT menggunakan bcrypt dengan hash terkuat
```

#### Password Verification

```php
// Saat login
if (password_verify($userInputPassword, $hashedPassword)) {
    // Password cocok - aman dari brute force
}
```

#### Session Management

Session disimpan setelah login berhasil:
- `user_id` - ID user
- `user_name` - Nama lengkap
- `user_email` - Email user
- `user_role` - Role: admin, customer, pengelola, owner
- `logged_in` - Flag status login

#### Filter Protection

- **FilterAdmin** → Proteksi `/admin/*` (harus admin)
- **FilterCustomer** → Proteksi `/customer/*` (harus customer)
- **FilterCheckLogin** → Proteksi `/dashboard` (harus login)
- **FilterPengelola, FilterOwner** → Proteksi routes masing-masing role

#### CSRF Protection

Semua form dilindungi dengan CSRF token:
```php
<?= csrf_field() ?>  <!-- Di setiap form -->
```

### Routes Authentication

```
/auth/login          → Login untuk semua role
/auth/admin-login    → Login khusus admin (recommended)
/auth/register       → Registrasi customer baru
/auth/logout         → Logout semua role
/dashboard           → Umum (setelah login)
/admin/dashboard     → Khusus admin (filter admin)
/customer/dashboard  → Khusus customer (filter customer)
```

## 7. FITUR UTAMA APLIKASI

### Untuk Midtrans:

1. Customer membuat order
2. System generate Snap Token menggunakan `generateSnapToken()` helper
3. Customer diarahkan ke halaman pembayaran dengan Midtrans JS
4. Setelah pembayaran, Midtrans mengirim notification ke webhook
5. Webhook update order status

### Setup Webhook:

1. Login ke Midtrans Dashboard
2. Ke Settings > HTTP Notification
3. Set URL notification ke: `http://yourdomain.com/webhooks/midtrans`
4. Buat webhook handler di `app/Controllers/Webhooks.php`

### Webhook Handler Example:

```php
public function midtrans()
{
    $notif = new \Midtrans\Notification();
    
    $paymentStatus = $notif->transaction_status;
    $type = $notif->fraud_status;
    $orderId = $notif->order_id;
    $transactionId = $notif->transaction_id;
    
    // Update order based on status
    $paymentLogModel = new PaymentLogModel();
    $paymentLogModel->insert([
        'order_id' => $orderId,
        'transaction_id' => $transactionId,
        'status' => $paymentStatus,
    ]);
    
    echo json_encode(['status' => 'ok']);
}
```

## 7. FITUR UTAMA APLIKASI

### ADMIN
- ✅ Kelola Paket (CRUD)
- ✅ Kelola Wahana (CRUD)
- ✅ Kelola Jadwal (CRUD)
- ✅ Verifikasi Pembayaran
- ✅ Konfirmasi Pesanan
- ✅ Laporan Penjualan

### CUSTOMER
- ✅ View Paket & Wahana
- ✅ Form Pemesanan 
- ✅ Upload Bukti Pembayaran
- ✅ Riwayat Pesanan
- ✅ Download PDF Bukti

### PENGELOLA
- ✅ Manajemen Status Wahana
- ✅ Laporan Jadwal Pesanan
- ✅ Persiapan Fieldtrip

### OWNER
- ✅ Laporan Penjualan
- ✅ Filter Per Bulan/Tahun
- ✅ Download PDF Laporan

## 8. STRUKTUR FOLDER APLIKASI

```
app/
├── Controllers/
│   ├── Auth.php              # Login/Register
│   ├── Dashboard.php         # Router Dashboard
│   ├── Admin.php            # Admin Controller
│   ├── Customer.php         # Customer Controller
│   ├── Pengelola.php        # Pengelola Controller
│   ├── Owner.php            # Owner Controller
│   └── Pages.php            # Public Pages
├── Models/
│   ├── UserModel.php
│   ├── PackageModel.php
│   ├── AttractionModel.php
│   ├── ScheduleModel.php
│   ├── OrderModel.php
│   ├── OrderAttractionItemModel.php
│   ├── PaymentLogModel.php
│   └── ReportModel.php
├── Database/
│   ├── Migrations/
│   │   ├── 2026-02-20-000001_CreateUsersTable.php
│   │   ├── 2026-02-20-000002_CreatePackagesTable.php
│   │   ├── 2026-02-20-000003_CreateAttractionsTable.php
│   │   ├── 2026-02-20-000004_CreateSchedulesTable.php
│   │   ├── 2026-02-20-000005_CreateOrdersTable.php
│   │   ├── 2026-02-20-000006_CreateOrderAttractionItemsTable.php
│   │   ├── 2026-02-20-000007_CreatePaymentLogTable.php
│   │   └── 2026-02-20-000008_CreateReportsTable.php
│   └── Seeds/
│       └── SampleSeeder.php
├── Filters/
│   ├── FilterCheckLogin.php
│   ├── FilterAdmin.php
│   ├── FilterCustomer.php
│   ├── FilterPengelola.php
│   └── FilterOwner.php
├── Helpers/
│   ├── PdfHelper.php       # PDF Generation
│   └── PaymentHelper.php   # Payment Gateway
├── Views/
│   ├── layouts/
│   │   ├── app.php         # Main layout
│   │   └── app_auth.php    # Auth layout
│   ├── auth/
│   │   ├── login.php
│   │   └── register.php
│   ├── admin/
│   │   ├── dashboard.php
│   │   ├── packages/
│   │   ├── attractions/
│   │   ├── schedules/
│   │   ├── orders/
│   │   └── reports/
│   ├── customer/
│   │   ├── dashboard.php
│   │   └── order/
│   ├── pengelola/
│   │   ├── dashboard.php
│   │   ├── attractions/
│   │   └── reports/
│   └── owner/
│       ├── dashboard.php
│       └── reports/
└── Config/
    ├── Routes.php         # URL Routes
    └── Filters.php        # Filter Configuration
```

## 9. PERHITUNGAN HARGA

### Formula:

```
Total Harga = (Jumlah Peserta × Harga Paket) + Total Wahana Tambahan

DP (30%) = Total Harga × 0.30

Sisa Pembayaran = Total Harga - DP
```

### Contoh:

```
Peserta: 50 orang
Paket Ula: Rp 75.000/orang
Paket Total: 50 × 75.000 = Rp 3.750.000

Wahana Tambahan: Rp 500.000
Total Harga: Rp 3.750.000 + Rp 500.000 = Rp 4.250.000

DP (30%): Rp 4.250.000 × 0.30 = Rp 1.275.000
Sisa: Rp 4.250.000 - Rp 1.275.000 = Rp 2.975.000
```

## 10. ATURAN JADWAL

### Maksimal Peserta Per Jadwal: 300 orang

```php
// Check availability
if (!$scheduleModel->isAvailableForParticipants($scheduleId, $numParticipants)) {
    // Peserta tidak bisa dipesan
}

// Reserve participants
$scheduleModel->reserveParticipants($scheduleId, $numParticipants);

// Update status otomatis
// Jika current_reserved >= 300 → status = 'full'
// Jika current_reserved < 300 → status = 'available'
```

## 11. BEST PRACTICES

### Security:
- ✅ Hash password menggunakan bcrypt (password_hash)
- ✅ CSRF protection pada semua form
- ✅ Role-based access control via Filters
- ✅ Input validation dan sanitization
- ✅ Query builder untuk prevent SQL injection

### Performance:
- ✅ Database indexing pada kolom yang sering dicari
- ✅ Eager loading relasi data
- ✅ Pagination untuk list data besar
- ✅ Caching untuk data statis

### Code Quality:
- ✅ Separation of concerns (Model, Controller, View)
- ✅ Helper functions untuk logic yang reusable
- ✅ Validation rules terpusat
- ✅ Error handling yang proper

## 12. TROUBLESHOOTING

### Database Connection Error
```
Check .env configuration
php spark db:connect
```

### Migration Error
```
php spark migrate:status
php spark migrate:rollback
php spark migrate
```

### Session Error
```
Check write permission pada folder writable/
chmod 755 writable/
```

### PDF Generation Error
```
Install DomPDF:
composer require dompdf/dompdf
```

### Payment Gateway Error
```
Check Server Key dan Client Key di .env
Test dengan Sandbox mode terlebih dahulu
```

## 13. NEXT STEPS

1. Customize branding dan logo
2. Buat halaman public beranda
3. Setup email notification
4. Implement SMS notification
5. Add analytics/reporting dashboard
6. Mobile app integration
7. Multi-language support

---

**Last Updated: 20 February 2026**
