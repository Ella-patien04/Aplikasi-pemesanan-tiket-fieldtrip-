<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\OrderModel;

class CancelExpiredPayment extends BaseCommand
{
    protected $group = 'Orders';
    protected $name = 'orders:cancel-expired';
    protected $description = 'Cancel orders that exceed payment deadline (24 hours)';
    protected $usage = 'orders:cancel-expired';
    protected $arguments = [];
    protected $options = [];

    public function run(array $params = [])
    {
        $orderModel = new OrderModel();
        
        // Cari pesanan dengan status pending dan payment sudah expired
        $expiredOrders = $orderModel
            ->where('payment_status', 'pending')
            ->where('order_status', 'pending')
            ->where('payment_expired_at IS NOT NULL', null, false)
            ->where('payment_expired_at <= NOW()', null, false)
            ->findAll();

        if (empty($expiredOrders)) {
            CLI::write('No expired orders found.', 'green');
            return;
        }

        $cancelledCount = 0;
        foreach ($expiredOrders as $order) {
            // Update pesanan ke status cancelled
            $data = [
                'order_status' => 'cancelled',
                'payment_status' => 'cancelled',
            ];
            log_message('debug', 'CancelExpiredPayment: BEFORE UPDATE ' . json_encode($data));
            $orderModel->update($order['id'], $data);
            $new = $orderModel->find($order['id']);
            log_message('debug', 'CancelExpiredPayment: AFTER UPDATE ' . json_encode($new));
            
            $cancelledCount++;
            CLI::write("Order #{$order['id']} (School: {$order['school_name']}) has been cancelled.", 'yellow');
        }

        CLI::write("Total orders cancelled: {$cancelledCount}", 'green');
    }
}
