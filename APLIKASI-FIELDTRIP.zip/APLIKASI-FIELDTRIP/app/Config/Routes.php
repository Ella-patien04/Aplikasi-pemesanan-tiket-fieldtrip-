<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 * 
 * APLIKASI PEMESANAN TIKET FIELDTRIP
 * Routes untuk semua endpoint aplikasi
 */

// Default route
$routes->get('/', 'Auth::login');

// ===== AUTH ROUTES =====
$routes->group('auth', function ($routes) {
    $routes->get('login', 'Auth::login');
    $routes->post('do-login', 'Auth::doLogin');
    $routes->get('forgot-password', 'Auth::forgotPassword');
    $routes->post('forgot-password', 'Auth::sendForgotPassword');
    $routes->get('verify-otp', 'Auth::verifyOtp');
    $routes->post('verify-otp', 'Auth::processVerifyOtp');
    $routes->get('reset-password', 'Auth::resetPassword');
    $routes->post('reset-password', 'Auth::processResetPassword');
    $routes->get('admin-login', 'Auth\AdminAuth::adminLogin');
    $routes->post('do-admin-login', 'Auth\AdminAuth::doAdminLogin');
    $routes->get('register', 'Auth::register');
    $routes->post('do-register', 'Auth::doRegister');
    $routes->get('logout', 'Auth::logout');
});

// Global dev route (no auth) to test PDF download locally. REMOVE in production.
$routes->get('dev/reports/sales/download-pdf', 'Owner::downloadSalesReportDev');

// ===== DASHBOARD ROUTER =====
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'check_login']);

// ===== ADMIN ROUTES =====
$routes->group('admin', ['filter' => 'admin'], function ($routes) {
    // Dashboard
    $routes->get('dashboard', 'Admin::dashboard');

    // Packages
    $routes->get('packages', 'Admin::packageList');
    $routes->get('packages/add', 'Admin::packageAdd');
    $routes->post('packages/save', 'Admin::packageSave');
    $routes->get('packages/edit/(:num)', 'Admin::packageEdit/$1');
    $routes->post('packages/update/(:num)', 'Admin::packageUpdate/$1');
    $routes->get('packages/delete/(:num)', 'Admin::packageDelete/$1');

    // Attractions
    $routes->get('attractions', 'Admin::attractionList');
    $routes->get('attractions/add', 'Admin::attractionAdd');
    $routes->post('attractions/save', 'Admin::attractionSave');
    $routes->get('attractions/edit/(:num)', 'Admin::attractionEdit/$1');
    $routes->post('attractions/update/(:num)', 'Admin::attractionUpdate/$1');
    $routes->get('attractions/delete/(:num)', 'Admin::attractionDelete/$1');

    // Orders
    $routes->get('orders', 'Admin::allOrders');
    $routes->get('orders/pending', 'Admin::pendingOrders');
    $routes->get('orders/detail/(:num)', 'Admin::orderDetail/$1');
    $routes->get('orders/create', 'Admin::orderCreate');
    $routes->post('orders/save', 'Admin::orderSave');
    $routes->get('orders/edit/(:num)', 'Admin::orderEdit/$1');
    $routes->post('orders/update/(:num)', 'Admin::orderUpdate/$1');
    $routes->get('orders/delete/(:num)', 'Admin::orderDelete/$1');
    $routes->get('orders/verify-payment/(:num)', 'Admin::verifyPayment/$1');
    $routes->post('orders/confirm/(:num)', 'Admin::confirmOrder/$1');


    // Reports
    $routes->get('reports/sales', 'Admin::salesReport');
    $routes->get('reports/booking', 'Admin::bookingReport');
    $routes->get('reports/booking/print', 'Admin::bookingReportPrint');
    $routes->get('users', 'Admin::userList');


    // Kelola Pengguna
    $routes->get('users/edit/(:num)', 'Admin::userEdit/$1');
    $routes->post('users/update/(:num)', 'Admin::userUpdate/$1');
    $routes->get('users/delete/(:num)', 'Admin::userDelete/$1');
});

// ===== CUSTOMER ROUTES =====
$routes->group('customer', ['filter' => 'customer'], function ($routes) {
    // Dashboard
    $routes->get('dashboard', 'Customer::dashboard');

    // Order
    $routes->get('order/form', 'Customer::orderForm');
    $routes->post('order/save', 'Customer::saveOrder');
    $routes->get('order/(:num)', 'Customer::orderDetail/$1');
    $routes->get('order/(:num)/payment', 'Customer::paymentPage/$1');
    $routes->post('order/(:num)/get-snap-token', 'Customer::getSnapToken/$1');
    $routes->match(['GET', 'POST'], 'order/(:num)/process-payment', 'Customer::processPayment/$1');
    $routes->get('order/(:num)/download-pdf', 'Customer::downloadPDF/$1');
    $routes->get('order/history', 'Customer::orderHistory');

    // AJAX APIs
    $routes->get('api/available-dates', 'Customer::getAvailableDates');
    $routes->get('api/date-capacity/(:any)', 'Customer::getDateCapacity/$1');
    $routes->get('api/check-availability/(:any)/(:num)', 'Customer::checkAvailability/$1/$2');
    $routes->get('profile', 'Customer::profile');
});

// ===== PAYMENT ROUTES =====
// Midtrans webhook kadang dipanggil lewat proxy dengan method yang tidak persis POST saat test.
// Untuk memastikan endpoint tetap ter-route, terima GET sebagai fallback (tetap hanya balas OK).
$routes->match(['POST', 'GET'], 'payment/notification', 'Payment::notification');
$routes->get('payment/status/(:num)', 'Payment::status/$1');
$routes->get('payment/finish', 'Payment::finish');
$routes->get('payment/unfinish', 'Payment::unfinish');
$routes->get('payment/error', 'Payment::error');


// ===== PENGELOLA ROUTES =====
$routes->group('pengelola', ['filter' => 'pengelola'], function ($routes) {
    // Dashboard
    $routes->get('dashboard', 'Pengelola::dashboard');

    // Attractions Status
    $routes->get('attractions', 'Pengelola::attractionList');
    $routes->get('attractions/update-status/(:num)', 'Pengelola::updateAttractionStatus/$1');

    // Packages
    $routes->get('packages', 'Pengelola::packageList');

    // Reports
    $routes->get('reports/schedule', 'Pengelola::scheduleReport');
    $routes->get('reports/schedule/(:any)', 'Pengelola::scheduleDetail/$1');
    $routes->get('information', 'Pengelola::information');

    // Kelola Pesanan (Pengelola)
    $routes->get('orders', 'Pengelola::orders');
    $routes->get('orders/detail/(:num)', 'Pengelola::orderDetail/$1');
    $routes->post('orders/update-status/(:num)', 'Pengelola::updateOrderFieldtripStatus/$1');
});



// ===== OWNER ROUTES =====
$routes->group('owner', ['filter' => 'owner'], function ($routes) {
    // Dashboard
    $routes->get('dashboard', 'Owner::dashboard');

    // Reports: Penjualan (existing)
    $routes->get('reports/sales', 'Owner::salesReport');
    $routes->get('reports/sales/download-pdf', 'Owner::downloadSalesReport');

    // Reports: Booking (DP vs Lunas)
    $routes->get('reports/booking', 'Owner::bookingReportOwner');
    $routes->get('reports/booking/print', 'Owner::bookingReportOwnerPrint');

    // Dev-only: bypass owner filter to test PDF download (remove in production)
    // NOTE: global dev route added after the group to bypass filters.

});


// ===== PUBLIC PAGES (TIDAK MEMERLUKAN LOGIN) =====
$routes->group('pages', function ($routes) {

    $routes->get('home', 'Pages::home');
    $routes->get('about', 'Pages::about');
    $routes->get('attractions', 'Pages::attractions');
    $routes->get('packages', 'Pages::packages');
    $routes->get('packages/(:num)', 'Pages::packageDetail/$1');
    $routes->get('gallery', 'Pages::gallery');
    $routes->get('contact', 'Pages::contact');
});
