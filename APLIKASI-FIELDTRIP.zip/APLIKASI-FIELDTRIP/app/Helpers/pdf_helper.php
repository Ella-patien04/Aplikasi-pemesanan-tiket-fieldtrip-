<?php

/**
 * PDF Helper
 * Helper untuk generate PDF bukti pemesanan dan laporan penjualan
 * 
 * Menggunakan library TCPDF atau DomPDF
 * Install: composer require dompdf/dompdf
 */

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Generate PDF untuk bukti pemesanan
 */
if (!function_exists('generatePdfBooking')) {
    function generatePdfBooking($order)
    {
        $options = new Options();
        $options->set('defaultFont', 'Courier');
        $dompdf = new Dompdf($options);

        // HTML content untuk PDF
        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Bukti Pemesanan</title>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { text-align: center; margin-bottom: 30px; }
                .header h1 { margin: 0; color: #333; }
                .header p { margin: 5px 0; color: #666; }
                .section { margin-bottom: 20px; }
                .section h3 { background-color: #f5f5f5; padding: 10px; margin: 0 0 10px 0; }
                .row { display: flex; margin-bottom: 8px; }
                .label { width: 150px; font-weight: bold; }
                .value { flex: 1; }
                .table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                .table th { background-color: #f5f5f5; padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
                .table td { padding: 8px; border-bottom: 1px solid #ddd; }
                .total-section { background-color: #f9f9f9; padding: 15px; margin-top: 20px; }
                .total-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 16px; }
                .total-amount { font-size: 20px; font-weight: bold; color: #d9534f; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>BUKTI PEMESANAN FIELDTRIP</h1>
                    <p>Agro Edu Wisata</p>
                    <p>Nomor Order: <strong>' . $order['id'] . '</strong></p>
                </div>

                <div class="section">
                    <h3>Data Pemesanan</h3>
                    <div class="row">
                        <div class="label">Nama Sekolah:</div>
                        <div class="value">' . htmlspecialchars($order['school_name']) . '</div>
                    </div>
                    <div class="row">
                        <div class="label">Nama Pemesan:</div>
                        <div class="value">' . htmlspecialchars($order['booker_name']) . '</div>
                    </div>
                    <div class="row">
                        <div class="label">No. HP/WhatsApp:</div>
                        <div class="value">' . htmlspecialchars($order['phone']) . '</div>
                    </div>
                    <div class="row">
                        <div class="label">Jumlah Peserta:</div>
                        <div class="value">' . $order['num_participants'] . ' orang</div>
                    </div>
                    <div class="row">
                        <div class="label">Jumlah Wali Murid:</div>
                        <div class="value">' . $order['num_guardians'] . ' orang</div>
                    </div>
                </div>

                <div class="section">
                    <h3>Detail Paket</h3>
                    <div class="row">
                        <div class="label">Nama Paket:</div>
                        <div class="value">' . htmlspecialchars($order['package']['name']) . '</div>
                    </div>
                    <div class="row">
                        <div class="label">Harga Paket:</div>
                        <div class="value">Rp ' . number_format($order['package']['price'], 0, ',', '.') . '/orang</div>
                    </div>
                </div>

                <div class="section">
                    <h3>Tanggal Kunjungan</h3>
                    <div class="row">
                            <div class="label">Tanggal:</div>
                            <div class="value">' . date('d F Y', strtotime($order['visit_date'])) . '</div>
                        </div>
                </div>

                ' . (!empty($order['attractions']) ? '
                <div class="section">
                    <h3>Wahana Tambahan</h3>
                    <table class="table">
                        <tr>
                            <th>Wahana</th>
                            <th>Harga</th>
                            <th>Qty</th>
                        </tr>
                        ' . implode('', array_map(fn($item) => '
                        <tr>
                            <td>' . htmlspecialchars($item['name'] ?? '') . '</td>
                            <td>Rp ' . number_format($item['price_at_booking'], 0, ',', '.') . '</td>
                            <td>' . ($item['quantity'] ?? 1) . '</td>
                        </tr>
                        ', $order['attractions'])) . '
                    </table>
                </div>
                ' : '') . '

                <div class="total-section">
                    <div class="total-row">
                        <span>Total Harga:</span>
                        <strong>Rp ' . number_format($order['total_price'], 0, ',', '.') . '</strong>
                    </div>
                    <div class="total-row">
                        <span>DP (30%):</span>
                        <strong class="total-amount">Rp ' . number_format($order['dp_amount'], 0, ',', '.') . '</strong>
                    </div>
                    <div class="total-row">
                        <span>Status Pembayaran:</span>
                        <strong>' . ucfirst(str_replace('_', ' ', $order['payment_status'])) . '</strong>
                    </div>
                </div>

                <div class="footer">
                    <p>Tanggal Cetak: ' . date('d F Y H:i:s') . '</p>
                    <p>Silakan datang 15 menit sebelum kegiatan dimulai.</p>
                </div>
            </div>
        </body>
        </html>
        ';

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        return $dompdf->stream("bukti_pemesanan_" . $order['id'] . ".pdf", ['Attachment' => false]);
    }
}

/**
 * Generate PDF untuk laporan penjualan
 */
if (!function_exists('generatePdfSalesReport')) {
    /**
     * Generate or stream PDF for sales report.
     * If $stream === true, will send headers and stream PDF directly (Attachment = 1) and exit.
     * Otherwise returns raw PDF bytes.
     */
    function generatePdfSalesReport($data, $stream = false)
    {
        $options = new Options();
        $options->set('defaultFont', 'Courier');
        $dompdf = new Dompdf($options);

        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Laporan Penjualan</title>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { max-width: 900px; margin: 0 auto; padding: 20px; }
                .header { text-align: center; margin-bottom: 30px; }
                .header h1 { margin: 0; color: #333; font-size: 24px; }
                .header p { margin: 5px 0; color: #666; }
                .period { text-align: center; margin-bottom: 20px; font-size: 14px; }
                .summary { background-color: #f5f5f5; padding: 15px; margin-bottom: 20px; }
                .summary-row { display: flex; justify-content: space-between; margin-bottom: 8px; }
                .summary-label { font-weight: bold; }
                .summary-value { font-weight: bold; color: #d9534f; }
                .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                .table th { background-color: #333; color: white; padding: 12px; text-align: left; }
                .table td { padding: 10px; border-bottom: 1px solid #ddd; }
                .table tr:nth-child(even) { background-color: #f9f9f9; }
                .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>LAPORAN PENJUALAN</h1>
                    <p>Agro Edu Wisata</p>
                </div>

                <div class="period">
                    <p>Periode: ' . $data['month_name'] . ' ' . $data['filter_year'] . '</p>
                </div>

                <div class="summary">
                    <div class="summary-row">
                        <span class="summary-label">Total Pesanan:</span>
                        <span class="summary-value">' . $data['total_orders'] . ' pesanan</span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Total Pendapatan:</span>
                        <span class="summary-value">Rp ' . number_format($data['total_revenue'], 0, ',', '.') . '</span>
                    </div>
                </div>

                <table class="table">
                    <tr>
                        <th style="width: 5%">No</th>
                        <th style="width: 15%">Order ID</th>
                        <th style="width: 25%">Sekolah</th>
                        <th style="width: 15%">Peserta</th>
                        <th style="width: 20%">Total Harga</th>
                        <th style="width: 20%">Tanggal</th>
                    </tr>
                    ' . implode('', array_map(function ($order, $index) {
                        static $no = 1;
                        return '
                        <tr>
                            <td>' . $no++ . '</td>
                            <td>#' . $order['id'] . '</td>
                            <td>' . htmlspecialchars($order['school_name']) . '</td>
                            <td>' . $order['num_participants'] . '</td>
                            <td>Rp ' . number_format($order['total_price'], 0, ',', '.') . '</td>
                            <td>' . date('d/m/Y', strtotime($order['created_at'])) . '</td>
                        </tr>
                        ';
                    }, $data['orders'], array_keys($data['orders'])) ?? '') . '
                </table>

                <div class="footer">
                    <p>Laporan Generated: ' . date('d F Y H:i:s') . '</p>
                </div>
            </div>
        </body>
        </html>
        ';

        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        if ($stream) {
            // Stream as attachment and terminate to avoid additional output (debug toolbar, etc.)
            $filename = "laporan_penjualan_" . ($data['filter_month'] ?? 'all') . "_" . ($data['filter_year'] ?? date('Y')) . ".pdf";
            $dompdf->stream($filename, ['Attachment' => 1]);
            exit; // ensure no further output
        }

        return $dompdf->output();
    }
}
