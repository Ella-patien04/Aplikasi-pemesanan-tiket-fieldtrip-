<?php

use CodeIgniter\HTTP\IncomingRequest;

/**
 * Helper utilities untuk flash message berdasarkan status payment.
 */

if (!function_exists('setPaymentFlashByStatus')) {
    /**
     * Set flashdata success/error berdasarkan status pembayaran.
     * 
     * @param string|null $paymentStatus
     * @return void
     */
    function setPaymentFlashByStatus(?string $paymentStatus): void
    {
        $paymentStatus = (string) ($paymentStatus ?? '');

        if ($paymentStatus === 'paid' || $paymentStatus === 'dp_paid') {
            session()->setFlashdata('success', 'Pembayaran berhasil');
            return;
        }

        if (in_array($paymentStatus, ['failed', 'cancelled', 'refunded'], true)) {
            session()->setFlashdata('error', 'Pembayaran gagal');
            return;
        }

        // expire/cancelled bisa juga muncul dari sistem sebagai nilai berbeda
        if (in_array($paymentStatus, ['expire', 'expired'], true)) {
            session()->setFlashdata('error', 'Pembayaran gagal (kadaluarsa)');
            return;
        }

        // default: tidak ada flash
    }
}

