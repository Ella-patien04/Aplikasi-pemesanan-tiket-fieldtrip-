<?php

/**
 * Payment Helper
 * Helper untuk integrasi payment gateway (Midtrans)
 * 
 * Install Midtrans SDK: composer require midtrans/midtrans-php
 * 
 * Konfigurasi:
 * - Server Key: Dari Midtrans dashboard (production/sandbox)
 * - Client Key: Dari Midtrans dashboard (production/sandbox)
 * - Environment: SANDBOX atau PRODUCTION
 */

use Midtrans\Config;
use Midtrans\Snap;
use Midtrans\Transaction;

/**
 * Initialize Midtrans Configuration
 */
if (!function_exists('initMidtransConfig')) {
    function initMidtransConfig()
    {
        // Get dari environment atau config file
        Config::$serverKey = getenv('MIDTRANS_SERVER_KEY') ?? '';
        Config::$clientKey = getenv('MIDTRANS_CLIENT_KEY') ?? '';
        Config::$isProduction = getenv('MIDTRANS_ENV') === 'PRODUCTION' ? true : false;
        Config::$isSanitized = true;
        Config::$is3ds = true;
    }
}

/**
 * Generate Midtrans Snap Token untuk pembayaran
 * 
 * @param array $order Data order dari database
 * @return array|false Array berisi snap_url dan snap_token, atau false jika gagal
 */
if (!function_exists('generateSnapToken')) {
    function generateSnapToken($order)
    {
        initMidtransConfig();

        try {
            // Prepare transaction details
            $transactionDetails = [
                'order_id' => 'ORDER-' . $order['id'] . '-' . time(),
                'gross_amount' => (int)$order['dp_amount'], // DP amount only
            ];

            // Customer details
            $customerDetails = [
                'first_name' => explode(' ', $order['booker_name'])[0],
                'last_name' => isset(explode(' ', $order['booker_name'])[1]) ? explode(' ', $order['booker_name'])[1] : '',
                'email' => $order['user']['email'] ?? 'customer@example.com',
                'phone' => $order['phone'],
            ];

            // Item details
            $itemDetails = [];

            // Add package item
            $itemDetails[] = [
                'id' => 'PACKAGE-' . $order['package_id'],
                'price' => (int)$order['package']['price'],
                'quantity' => $order['num_participants'],
                'name' => $order['package']['name'] . ' (' . $order['num_participants'] . ' peserta)',
            ];

            // Add attractions if any
            if (!empty($order['attractions'])) {
                foreach ($order['attractions'] as $attraction) {
                    $itemDetails[] = [
                        'id' => 'ATTRACTION-' . $attraction['attraction_id'],
                        'price' => (int)$attraction['price_at_booking'],
                        'quantity' => $attraction['quantity'] ?? 1,
                        'name' => $attraction['name'] ?? 'Wahana Tambahan',
                    ];
                }
            }

            // Build transaction data
            $transactionData = [
                'transaction_details' => $transactionDetails,
                'customer_details' => $customerDetails,
                'item_details' => $itemDetails,
                'callbacks' => [
                    'finish' => base_url('customer/order/' . $order['id'] . '/payment-success'),
                    'error' => base_url('customer/order/' . $order['id'] . '/payment-error'),
                    'pending' => base_url('customer/order/' . $order['id'] . '/payment-pending'),
                ],
            ];

            // Create Snap transaction
            $snapToken = Snap::getSnapToken($transactionData);
            $snapUrl = Snap::getSnapUrl($transactionData);

            return [
                'success' => true,
                'snap_token' => $snapToken,
                'snap_url' => $snapUrl,
            ];
        } catch (\Exception $e) {
            log_message('error', 'Midtrans Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Gagal generate token pembayaran',
            ];
        }
    }
}

/**
 * Verify payment dari Midtrans
 * Biasanya dipanggil dari webhook Midtrans
 * 
 * @param string $transactionId Transaction ID dari Midtrans
 * @return array|false Status pembayaran
 */


/**
 * Update order payment status berdasarkan status dari Midtrans
 * 
 * @param array $paymentStatus Status dari Midtrans
 * @return bool
 */
if (!function_exists('updateOrderPaymentStatus')) {
    function updateOrderPaymentStatus($paymentStatus)
    {
        $orderModel = new \App\Models\OrderModel();
        $paymentLogModel = new \App\Models\PaymentLogModel();

        // Extract order ID dari Midtrans order_id format: "ORDER-{order_id}-{timestamp}"
        $parts = explode('-', $paymentStatus['order_id']);
        $orderId = $parts[1] ?? null;

        if (!$orderId) {
            return false;
        }

        $order = $orderModel->find($orderId);
        if (!$order) {
            return false;
        }

        // Map Midtrans payment status ke aplikasi status
        $statusMapping = [
            'capture' => 'paid',
            'settlement' => 'paid',
            'pending' => 'pending',
            'deny' => 'cancelled',
            'cancel' => 'cancelled',
            'expire' => 'cancelled',
        ];

        $newStatus = $statusMapping[$paymentStatus['status']] ?? 'pending';

        // Update payment log (best-effort)
        log_message('debug', 'PaymentHelper updateOrderPaymentStatus: BEFORE UPDATE PAYMENT LOG ' . json_encode([
            'order_id' => $orderId,
            'status' => $newStatus,
            'transaction_id' => $paymentStatus['transaction_id'] ?? null,
        ]));
        // Note: updatePaymentStatus expects paymentLogId; if not present, this is a noop.
        if (isset($paymentStatus['payment_log_id']) && $paymentStatus['payment_log_id']) {
            $paymentLogModel->updatePaymentStatus(
                $paymentStatus['payment_log_id'],
                $newStatus,
                $paymentStatus['transaction_id'] ?? null
            );
        }

        // Update order jika payment berhasil. Determine dp vs final by order_id suffix.
        if ($newStatus === 'paid') {
            $setStatus = 'paid';
            if (strpos($paymentStatus['order_id'] ?? '', '-DP') !== false) {
                $setStatus = 'dp_paid';
            }

            $data = ['payment_status' => $setStatus];
            log_message('debug', 'PaymentHelper updateOrderPaymentStatus: BEFORE UPDATE ' . json_encode($data));
            $res = $orderModel->update($orderId, $data);
            log_message('debug', 'PaymentHelper updateOrderPaymentStatus: UPDATE RESULT=' . ($res ? 'SUCCESS' : 'FAILED'));
            if (!$res) {
                log_message('error', json_encode($orderModel->errors()));
            }
            $new = $orderModel->find($orderId);
            log_message('debug', json_encode($new));
            return (bool)$res;
        }

        return false;
    }
}

/**
 * Format response untuk payment gateway
 */
if (!function_exists('paymentResponse')) {
    function paymentResponse($success, $message, $data = [])
    {
        return json_encode(array_merge([
            'success' => $success,
            'message' => $message,
        ], $data));
    }
}

/**
 * Simulate pembayaran untuk development/testing
 * (Gunakan hanya untuk testing, JANGAN di production)
 */
if (!function_exists('simulatePayment')) {
    function simulatePayment($orderId)
    {
        $orderModel = new \App\Models\OrderModel();
        $paymentLogModel = new \App\Models\PaymentLogModel();

        $order = $orderModel->find($orderId);
        if (!$order) {
            return false;
        }

        // Update order
        $data = ['payment_status' => 'dp_paid'];
        log_message('debug', 'simulatePayment: BEFORE UPDATE ' . json_encode($data));
        $res = $orderModel->update($orderId, $data);
        log_message('debug', 'simulatePayment: UPDATE RESULT=' . ($res ? 'SUCCESS' : 'FAILED'));
        if (!$res) {
            log_message('error', json_encode($orderModel->errors()));
        }
        $new = $orderModel->find($orderId);
        log_message('debug', json_encode($new));

        // Log
        $paymentLogModel->insert([
            'order_id' => $orderId,
            'reference_number' => 'SIM-' . time(),
            'amount' => $order['dp_amount'],
            'status' => 'settlement',
            'payment_method' => 'SIMULASI',
        ]);

        return true;
    }
}
