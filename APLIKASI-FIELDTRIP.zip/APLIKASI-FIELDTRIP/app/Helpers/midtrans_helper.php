<?php

/**
 * Midtrans Payment Gateway Helper
 * Provides safe autoload fallback and namespace imports.
 */

// Ensure Composer autoload is available (in case CI did not autoload it yet)
if (!class_exists(\Midtrans\Config::class)) {
    $autoloadPath = __DIR__ . '/../../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
}

use Midtrans\Config;
use Midtrans\Snap;
use Midtrans\Transaction;

if (!function_exists('midtrans_autoload_check')) {
    function midtrans_autoload_check()
    {
        return class_exists(\Midtrans\Config::class);
    }
}

if (!function_exists('midtrans_load_env_file')) {
    function midtrans_load_env_file(string $key)
    {
        $envPath = realpath(__DIR__ . '/../../.env.midtrans');
        if (!$envPath || !file_exists($envPath)) {
            return null;
        }

        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$name, $value] = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            if ($name === $key) {
                return trim($value, ' "\'');
            }
        }

        return null;
    }
}

if (!function_exists('midtrans_get_env')) {
    function midtrans_get_env(string $key, $default = null)
    {
        $value = env($key);
        if ($value === null || $value === false || $value === '') {
            $value = getenv($key);
        }
        if ($value === false || $value === null || $value === '') {
            $value = midtrans_load_env_file($key);
        }

        return $value !== null && $value !== false && $value !== '' ? $value : $default;
    }
}

if (!function_exists('midtrans_debug_env')) {
    function midtrans_debug_env(): array
    {
        $serverKey = midtrans_get_env('MIDTRANS_SERVER_KEY');
        $clientKey = midtrans_get_env('MIDTRANS_CLIENT_KEY');
        $production = midtrans_get_env('MIDTRANS_PRODUCTION', false);

        return [
            'MIDTRANS_SERVER_KEY' => $serverKey,
            'MIDTRANS_CLIENT_KEY' => $clientKey,
            'MIDTRANS_PRODUCTION' => $production,
            'serverKey_set' => !empty($serverKey),
            'clientKey_set' => !empty($clientKey),
            'env_source' => file_exists(__DIR__ . '/../../.env') ? '.env' : '.env not found',
            'fallback_source' => file_exists(__DIR__ . '/../../.env.midtrans') ? '.env.midtrans' : '.env.midtrans not found',
        ];
    }
}

if (!function_exists('getMidtransSnapToken')) {
    /**
     * Get Snap Token from Midtrans
     */
    function getMidtransSnapToken($orderId, $orderData, $paymentType = 'dp')
    {

        // Debug helper - ensure class exists
        if (!midtrans_autoload_check()) {
            throw new \RuntimeException('Midtrans classes not available. Ensure Composer autoload is loaded.');
        }

        $serverKey = midtrans_get_env('MIDTRANS_SERVER_KEY');
        $clientKey = midtrans_get_env('MIDTRANS_CLIENT_KEY');
        $production = midtrans_get_env('MIDTRANS_PRODUCTION', false);

        Config::$serverKey = $serverKey;
        Config::$clientKey = $clientKey;
        Config::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);
        Config::$isSanitized = true;
        Config::$is3ds = true;

        $debug = midtrans_debug_env();
        log_message('debug', 'Midtrans env debug: ' . json_encode($debug));

        if (empty($serverKey) || empty($clientKey)) {
            throw new \RuntimeException('The ServerKey/ClientKey is null. Check MIDTRANS_SERVER_KEY and MIDTRANS_CLIENT_KEY in .env or .env.midtrans.');
        }

        $midtransOrderId = 'FT-' . $orderId . ($paymentType === 'final' ? '-FINAL' : '-DP');
        $amount = (int)$orderData['total_price'];

        $transactionDetails = [
            'order_id' => $midtransOrderId,
            'gross_amount' => $amount,
        ];

        $customer = [
            'first_name' => $orderData['booker_name'],
            'email' => $orderData['email'] ?? 'customer@fieldtrip.id',
            'phone' => $orderData['phone'],
        ];

        $item_details = [
            [
                'id' => 'fieldtrip-' . $orderId,
                'price' => $amount,
                'quantity' => 1,
                'name' => $paymentType === 'final' ? 'Pelunasan Fieldtrip' : 'DP Fieldtrip',
            ],
        ];

        $payload = [
            'transaction_details' => $transactionDetails,
            'customer_details' => $customer,
            'item_details' => $item_details,
            'vtweb' => [],
        ];

        $snapToken = Snap::getSnapToken($payload);

        return $snapToken;
    }
}

if (!function_exists('verifyMidtransPayment')) {
    /**
     * Verify Midtrans Payment Status
     */
    function verifyMidtransPayment($orderId, $paymentType = 'dp')
    {
        if (!midtrans_autoload_check()) {
            throw new \RuntimeException('Midtrans classes not available. Ensure Composer autoload is loaded.');
        }

        $serverKey = midtrans_get_env('MIDTRANS_SERVER_KEY');
        $production = midtrans_get_env('MIDTRANS_PRODUCTION', false);

        Config::$serverKey = $serverKey;
        Config::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);

        $debug = midtrans_debug_env();
        log_message('debug', 'Midtrans env debug: ' . json_encode($debug));

        if (empty($serverKey)) {
            throw new \RuntimeException('The ServerKey is null. Check MIDTRANS_SERVER_KEY in .env or .env.midtrans.');
        }

        $midtransOrderId = 'FT-' . $orderId . ($paymentType === 'final' ? '-FINAL' : '-DP');
        $status = Transaction::status($midtransOrderId);

        return $status;
    }
}

if (!function_exists('handleMidtransNotification')) {
    /**
     * Handle Midtrans Notification Callback
     */
    function handleMidtransNotification($notificationPayload)
    {
        if (!midtrans_autoload_check()) {
            throw new \RuntimeException('Midtrans classes not available. Ensure Composer autoload is loaded.');
        }

        $serverKey = midtrans_get_env('MIDTRANS_SERVER_KEY');
        $production = midtrans_get_env('MIDTRANS_PRODUCTION', false);

        Config::$serverKey = $serverKey;
        Config::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);

        $debug = midtrans_debug_env();
        log_message('debug', 'Midtrans env debug: ' . json_encode($debug));

        if (empty($serverKey)) {
            throw new \RuntimeException('The ServerKey is null. Check MIDTRANS_SERVER_KEY in .env or .env.midtrans.');
        }

        // Accept payload as array (controller already json_decoded)
        $payload = $notificationPayload;
        if (is_object($payload)) {
            $payload = (array) $payload;
        }

        $orderIdRaw = (string) ($payload['order_id'] ?? ($payload['orderId'] ?? ''));
        $paymentType = 'dp';
        if (strpos($orderIdRaw, '-FINAL') !== false) {
            $paymentType = 'final';
        }

        // Robust parsing: collect all numbers and join them.
        $parsedOrderId = null;
        if ($orderIdRaw !== '') {
            if (preg_match_all('/\d+/', $orderIdRaw, $matches) && !empty($matches[0])) {
                $joined = implode('', $matches[0]);
                // cast to int to match OrderModel primary key type
                $parsedOrderId = (int) $joined;
            } else {
                // Fallback: try extracting a single numeric segment as before
                if (preg_match('/^(?:FT-)?(\d+)(?:-DP|-FINAL)?$/', $orderIdRaw, $m)) {
                    $parsedOrderId = (int) $m[1];
                }
            }
        }

        return [
            'order_id' => $parsedOrderId,
            'midtrans_order_id' => $orderIdRaw,
            'payment_type' => $paymentType,
            'transaction_status' => $payload['transaction_status'] ?? ($payload['status_code'] ?? null),
            'payment_method' => $payload['payment_type'] ?? $payload['payment_method'] ?? null,
            'fraud_status' => $payload['fraud_status'] ?? 'accept',
            'gross_amount' => $payload['gross_amount'] ?? $payload['gross_amounts'] ?? null,
            'notification' => $payload,
        ];
    }
}
