<?php

namespace App\Models;

use CodeIgniter\Model;
use Config\Database;

class OwnerReportModel extends Model
{
    /** @var string */
    protected $table = 'orders';

    /**
     * Hitung total kemunculan nama paket untuk transaksi sukses (dp_paid & paid).
     * Return: [ package_name => count ]
     */
    public function getOwnerPackageSalesCounts(): array
    {
        $db = Database::connect();

        $builder = $db->table('orders as o')
            ->select('p.name as package_name, COUNT(*) as cnt')
            ->join('packages as p', 'p.id = o.package_id')
            ->whereIn('o.payment_status', ['dp_paid', 'paid'])
            ->where('o.order_status !=', 'cancelled')
            ->where('o.payment_status !=', 'cancelled')
            ->groupBy('p.id');

        $rows = $builder->get()->getResultArray();

        $result = [];
        foreach ($rows as $r) {
            $name = (string) ($r['package_name'] ?? '');
            $cnt = (int) ($r['cnt'] ?? 0);
            if ($name !== '') {
                $result[$name] = $cnt;
            }
        }

        return $result;
    }

    /**
     * Pendapatan bulanan tahun berjalan (dp_amount) untuk transaksi sukses.
     * Return: [1..12 => total]
     */
    public function getOwnerMonthlyRevenueCurrentYear(int $year): array
    {
        $db = Database::connect();

        $builder = $db->table('orders as o')
            ->select('MONTH(o.created_at) as month_num, COALESCE(SUM(o.dp_amount),0) as revenue')
            ->whereIn('o.payment_status', ['dp_paid', 'paid'])
            ->where('o.order_status !=', 'cancelled')
            ->where('o.payment_status !=', 'cancelled')
            ->where('YEAR(o.created_at)', (int) $year)
            ->groupBy('MONTH(o.created_at)')
            ->orderBy('MONTH(o.created_at)', 'ASC');

        $rows = $builder->get()->getResultArray();

        $result = array_fill(1, 12, 0);
        foreach ($rows as $r) {
            $m = (int) ($r['month_num'] ?? 0);
            $rev = (float) ($r['revenue'] ?? 0);
            if ($m >= 1 && $m <= 12) {
                $result[$m] = (float) $rev;
            }
        }

        return $result;
    }

    /**
     * Laporan pemesanan Owner DP (dp_paid) berdasarkan created_at.
     */
    public function getOwnerBookingDPReport(?string $startDate, ?string $endDate): array
    {
        return $this->getBookingByStatus('dp_paid', $startDate, $endDate);
    }

    /**
     * Laporan pemesanan Owner Lunas (paid) berdasarkan created_at.
     */
    public function getOwnerBookingPaidReport(?string $startDate, ?string $endDate): array
    {
        return $this->getBookingByStatus('paid', $startDate, $endDate);
    }

    private function getBookingByStatus(string $paymentStatus, ?string $startDate, ?string $endDate): array
    {
        // Join package untuk ambil nama paket.
        $db = Database::connect();
        $builder = $db->table('orders as o')
            ->select([
                'o.id',
                'o.created_at',
                'o.school_name',
                'o.booker_name',
                'o.num_participants',
                'o.num_guardians',
                'o.num_teachers',
                'o.package_id',
                'o.total_price',
                'o.dp_amount',
                'o.payment_status',
                'p.name as package_name',
            ])
            ->join('packages as p', 'p.id = o.package_id', 'left')
            ->where('o.payment_status', $paymentStatus)
            ->where('o.order_status !=', 'cancelled')
            ->where('o.payment_status !=', 'cancelled')
            ->orderBy('o.created_at', 'DESC');

        if (!empty($startDate)) {
            $builder->where('o.created_at >=', $startDate . ' 00:00:00');
        }
        if (!empty($endDate)) {
            $builder->where('o.created_at <=', $endDate . ' 23:59:59');
        }

        $rows = $builder->get()->getResultArray();

        // Hitung sisa tagihan dan jumlah peserta/tiket.
        $out = [];
        foreach ($rows as $o) {
            $jumlahPeserta = (int) ($o['num_participants'] ?? 0)
                + (int) ($o['num_guardians'] ?? 0)
                + (int) ($o['num_teachers'] ?? 0);

            $total = (float) ($o['total_price'] ?? 0);
            $paidNominal = (float) ($o['dp_amount'] ?? 0);
            if ($paymentStatus === 'paid') {
                // For consistency: paid => nominal terbayar dianggap lunas.
                $paidNominal = $total;
            }

            $sisa = $total - $paidNominal;

            $out[] = [
                'id' => (int) ($o['id'] ?? 0),
                'created_at' => $o['created_at'],
                'school_name' => $o['school_name'],
                'booker_name' => $o['booker_name'],
                'package_name' => $o['package_name'],
                'jumlah_peserta' => $jumlahPeserta,
                'total_price' => $total,
                'dp_amount' => $paidNominal,
                'sisa_tagihan' => $sisa,
                'payment_status' => (string) ($o['payment_status'] ?? ''),
            ];
        }

        return $out;
    }
}

