<?php

namespace App\Models;

use CodeIgniter\Model;

class PackageModel extends Model
{
    protected $table = 'packages';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name', 'description', 'price', 'facilities', 'image', 'is_active'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected array $casts = [
        'facilities' => 'json[array]',
    ];
    protected $validationRules = [
        'name' => 'required|string|max_length[100]',
        'description' => 'string',
        'price' => 'required|decimal',
        'facilities' => 'required',
    ];

    /**
     * Dapatkan semua paket aktif
     */
    public function getActivePackages()
    {
        return $this->where('is_active', 1)->findAll();
    }

    /**
     * Dapatkan paket berdasarkan ID
     */
    public function getPackageById($id)
    {
        return $this->find($id);
    }

    /**
     * Update status aktif paket
     */
    public function updateStatus($id, $status)
    {
        return $this->update($id, ['is_active' => $status]);
    }
}
