<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name', 'email', 'password', 'phone', 'role', 'is_active', 'reset_token', 'otp_code', 'otp_expired_at'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $validationRules = [
        'name' => 'required|string|max_length[255]',
        'email' => 'required|valid_email|is_unique[users.email,id,{id}]',
        'password' => 'required|min_length[6]',
        'phone' => 'string|max_length[15]',
        'role' => 'required|in_list[admin,customer,pengelola,owner]',
    ];
    protected $validationMessages = [
        'email' => [
            'is_unique' => 'Email sudah terdaftar',
            'valid_email' => 'Format email tidak valid',
        ],
    ];
    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    // Custom methods

    /**
     * Cari user dengan email
     */
    public function findByEmail($email)
    {
        return $this->where('email', $email)->first();
    }

    /**
     * Set OTP reset password
     */
    public function setPasswordResetOtp($userId, string $otp, string $expiresAt)
    {
        return $this->skipValidation(true)->update($userId, [
            'otp_code' => $otp,
            'otp_expired_at' => $expiresAt,
            'reset_token' => null,
        ]);
    }

    /**
     * Verifikasi OTP reset password
     */
    public function verifyResetOtp(string $email, string $otp)
    {
        $user = $this->where('email', $email)
            ->where('is_active', 1)
            ->where('otp_code', $otp)
            ->first();

        if (!$user) {
            return null;
        }

        if (empty($user['otp_expired_at']) || strtotime($user['otp_expired_at']) < time()) {
            return null;
        }

        return $user;
    }

    /**
     * Hapus OTP setelah reset password berhasil
     */
    public function clearPasswordResetOtp($userId)
    {
        return $this->skipValidation(true)->update($userId, [
            'otp_code' => null,
            'otp_expired_at' => null,
            'reset_token' => null,
        ]);
    }

    /**
     * Cari user dengan role
     */
    public function findByRole($role, $active = true)
    {
        return $this->where('role', $role)->where('is_active', $active)->findAll();
    }

    /**
     * Daftarkan user baru
     */
    public function registerUser($data)
    {
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        $data['role'] = 'customer';
        return $this->insert($data);
    }

    /**
     * Verifikasi login user
     */
    public function verifyLogin($email, $password)
    {
        $user = $this->findByEmail($email);
        if (!$user) {
            return null;
        }

        if (!password_verify($password, $user['password'])) {
            return null;
        }

        if (!$user['is_active']) {
            return null;
        }

        return $user;
    }
}
