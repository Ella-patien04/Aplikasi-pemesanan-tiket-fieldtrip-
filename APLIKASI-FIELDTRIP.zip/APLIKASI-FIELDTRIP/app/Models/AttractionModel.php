<?php

namespace App\Models;

use CodeIgniter\Model;

class AttractionModel extends Model
{
    protected $table = 'attractions';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name', 'description', 'price', 'image', 'is_active'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $validationRules = [
        'name' => 'required|string|max_length[255]',
        'description' => 'string',
        'price' => 'required|decimal',
    ];

    /**
     * Dapatkan semua wahana aktif
     */
    public function getActiveAttractions()
    {
        return $this->where('is_active', 1)->findAll();
    }

    /**
     * Dapatkan wahana berdasarkan ID array
     */
    public function getAttractionsByIds($ids)
    {
        if (empty($ids)) {
            return [];
        }
        return $this->whereIn('id', $ids)->findAll();
    }

    /**
     * Update status aktif wahana
     */
    public function updateStatus($id, $status)
    {
        return $this->update($id, ['is_active' => $status]);
    }
}
