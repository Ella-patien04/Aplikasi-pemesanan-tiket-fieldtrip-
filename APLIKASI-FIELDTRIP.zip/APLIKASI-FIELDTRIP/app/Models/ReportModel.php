<?php

namespace App\Models;

use CodeIgniter\Model;

class ReportModel extends Model
{
    protected $table = 'reports';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = [
        'title',
        'type',
        'filter_month',
        'filter_year',
        'total_revenue',
        'total_orders',
        'created_by',
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';

    /**
     * Buat laporan penjualan
     */
    public function createSalesReport($userId, $month, $year)
    {
        $orderModel = new OrderModel();
        $stats = $orderModel->getSalesStats($month, $year);

        return $this->insert([
            'title' => "Laporan Penjualan " . date('F Y', mktime(0, 0, 0, $month, 1)),
            'type' => 'sales',
            'filter_month' => $month,
            'filter_year' => $year,
            'total_revenue' => $stats['total_revenue'] ?? 0,
            'total_orders' => $stats['total_orders'] ?? 0,
            'created_by' => $userId,
        ]);
    }

    /**
     * Dapatkan laporan penjualan
     */
    public function getSalesReports($userId = null, $month = null, $year = null)
    {
        $query = $this->where('type', 'sales');

        if ($userId) {
            $query->where('created_by', $userId);
        }

        if ($month) {
            $query->where('filter_month', $month);
        }

        if ($year) {
            $query->where('filter_year', $year);
        }

        return $query->orderBy('created_at', 'DESC')->findAll();
    }

    /**
     * Dapatkan laporan jadwal pesanan
     */
    public function getScheduleReports($month = null, $year = null)
    {
        return $this->where('type', 'schedule')
            ->when($month, function ($query) use ($month) {
                return $query->where('filter_month', $month);
            })
            ->when($year, function ($query) use ($year) {
                return $query->where('filter_year', $year);
            })
            ->orderBy('created_at', 'DESC')
            ->findAll();
    }
}
