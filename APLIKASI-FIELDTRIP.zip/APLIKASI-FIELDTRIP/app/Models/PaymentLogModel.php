<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentLogModel extends Model
{
    protected $table = 'payment_log';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = [
        'order_id',
        'midtrans_snap_id',
        'midtrans_transaction_id',
        'reference_number',
        'amount',
        'status',
        'payment_method',
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Buat log pembayaran baru
     */
    public function logPayment($orderId, $amount, $snapId = null)
    {
        return $this->insert([
            'order_id' => $orderId,
            'amount' => $amount,
            'midtrans_snap_id' => $snapId,
            'status' => 'pending',
        ]);
    }

    /**
     * Update status pembayaran
     */
    public function updatePaymentStatus($paymentLogId, $status, $transactionId = null)
    {
        $data = ['status' => $status];
        if ($transactionId) {
            $data['midtrans_transaction_id'] = $transactionId;
        }
        return $this->update($paymentLogId, $data);
    }

    /**
     * Log pembayaran sukses
     */
    public function logPaymentSuccess($orderId, $amount, $midtransOrderId = null, $paymentMethod = null)
    {
        return $this->insert([
            'order_id' => $orderId,
            'amount' => $amount,
            'midtrans_transaction_id' => $midtransOrderId,
            'payment_method' => $paymentMethod,
            'status' => 'paid',
        ]);
    }

    /**
     * Dapatkan log pembayaran untuk order
     */
    public function getOrderPaymentLogs($orderId)
    {
        return $this->where('order_id', $orderId)
            ->orderBy('created_at', 'DESC')
            ->findAll();
    }

    /**
     * Dapatkan log pembayaran terakhir
     */
    public function getLastPaymentLog($orderId)
    {
        return $this->where('order_id', $orderId)
            ->orderBy('created_at', 'DESC')
            ->first();
    }

    /**
     * Cari berdasarkan Snap ID
     */
    public function findBySnapId($snapId)
    {
        return $this->where('midtrans_snap_id', $snapId)->first();
    }

    /**
     * Cari berdasarkan Transaction ID
     */
    public function findByTransactionId($transactionId)
    {
        return $this->where('midtrans_transaction_id', $transactionId)->first();
    }
}
