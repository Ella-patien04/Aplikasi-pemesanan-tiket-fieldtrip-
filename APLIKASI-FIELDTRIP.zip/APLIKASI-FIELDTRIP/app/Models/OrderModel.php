<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table = 'orders';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = [
        'user_id',
        'visit_date',
        'school_name',
        'booker_name',
        'phone',
        'num_participants',
        'num_guardians',
        'num_teachers',
        'package_id',
        'total_price',
        'dp_amount',
        'payment_status',
        'order_status',
        'confirmation_date',
        'proof_payment_image',
        'verified_by',
        'verified_date',
        'fieldtrip_status',
        'pdf_token',
    ];


    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $validationRules = [
        'user_id' => 'required|integer',
        'visit_date' => 'required',
        'school_name' => 'required|string',
        'booker_name' => 'required|string',
        'phone' => 'required|string',
        'num_participants' => 'required|integer',
        'num_guardians' => 'required|integer',
        'num_teachers' => 'required|integer',
        'package_id' => 'required|integer',
        'total_price' => 'required|decimal',
    ];

    /**
     * Buat pesanan baru
     */
    public function createOrder($data)
    {
        // Hitung DP (30% dari total harga)
        $data['dp_amount'] = $data['total_price'] * 0.30;
        $data['pdf_token'] = bin2hex(random_bytes(16));

        return $this->insert($data);
    }

    /**
     * Dapatkan pesanan user
     */
    public function getUserOrders($userId)
    {
        return $this->where('user_id', $userId)
            ->orderBy('created_at', 'DESC')
            ->findAll();
    }

    /**
     * Dapatkan detail order dengan relasi
     */
    public function getOrderDetail($orderId)
    {
        $order = $this->find($orderId);
        if (!$order) {
            return null;
        }

        // Load relasi (dibatasi supaya ringan untuk halaman pengelola)
        $packageModel = new PackageModel();

        // Package selalu dibutuhkan untuk view detail
        $order['package'] = $packageModel->getPackageById($order['package_id']);

        // Untuk kebutuhan Pengelola:
        // - User/verified_by_user sering tidak tampil penuh di list/detail pengelola
        // - Menghindari query relasi tambahan agar tidak memicu timeout/debug dump
        $order['attractions'] = $this->getOrderAttractions($orderId);

        $order['attraction_total'] = 0;
        foreach ($order['attractions'] as &$item) {
            $item['subtotal'] = (float) ($item['price_at_booking'] ?? 0) * (int) ($item['quantity'] ?? 0);
            $order['attraction_total'] += $item['subtotal'];
        }

        return $order;

    }

    /**
     * Get total participants already booked on a specific date
     */
    public function getTotalParticipantsByDate($date)
    {
        $date = $this->normalizeDate($date);

        $db = \Config\Database::connect();
        $builder = $db->table('orders');
        $row = $builder->select('COALESCE(SUM(num_participants),0) as total')
            ->where('visit_date', $date)
            ->where('order_status !=', 'cancelled')
            ->where('payment_status !=', 'cancelled')
            ->get()->getRowArray();

        return (int) ($row['total'] ?? 0);
    }

    /**
     * Check if a date can accommodate additional participants (max 350 per day)
     */
    public function canAccommodateOnDate($date, $additionalParticipants)
    {
        $MAX = 350;
        $date = $this->normalizeDate($date);
        $current = $this->getTotalParticipantsByDate($date);
        return (($current + (int)$additionalParticipants) <= $MAX);
    }

    /**
     * Get available capacity for a date (remaining slots)
     */
    public function getAvailableCapacityByDate($date)
    {
        $MAX = 350;
        $date = $this->normalizeDate($date);
        $current = $this->getTotalParticipantsByDate($date);
        $avail = $MAX - $current;
        return $avail < 0 ? 0 : $avail;
    }

    /**
     * Normalize date input to Y-m-d string
     */
    private function normalizeDate($date)
    {
        if ($date instanceof \DateTime) {
            return $date->format('Y-m-d');
        }

        $ts = strtotime((string)$date);
        if ($ts === false) {
            // fallback to today's date
            return date('Y-m-d');
        }

        return date('Y-m-d', $ts);
    }

    /**
     * Dapatkan wahana yang dipilih untuk pesanan
     */
    public function getOrderAttractions($orderId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('order_attraction_items as items');
        return $builder->select('items.*, a.name as attraction_name, a.description as attraction_description, a.price as attraction_price')
            ->join('attractions as a', 'a.id = items.attraction_id')
            ->where('items.order_id', $orderId)
            ->get()
            ->getResultArray();
    }

    /**
     * Dapatkan semua pesanan yang pending
     */
    public function getPendingOrders()
    {
        return $this->where('order_status', 'pending')
            ->orderBy('created_at', 'DESC')
            ->findAll();
    }

    /**
     * Dapatkan pesanan berdasarkan status pembayaran
     */
    public function getOrdersByPaymentStatus($status)
    {
        return $this->where('payment_status', $status)
            ->orderBy('created_at', 'DESC')
            ->findAll();
    }

    /**
     * Update status order
     */
    public function updateOrderStatus($orderId, $orderStatus, $paymentStatus = null)
    {
        $data = ['order_status' => $orderStatus];
        if ($paymentStatus) {
            $data['payment_status'] = $paymentStatus;
        }
        if ($orderStatus == 'confirmed') {
            $data['confirmation_date'] = date('Y-m-d H:i:s');
        }

        // Audit logging for updates
        log_message('debug', 'BEFORE UPDATE ' . json_encode($data));
        $result = $this->update($orderId, $data);
        log_message('debug', 'UPDATE RESULT=' . ($result ? 'SUCCESS' : 'FAILED'));
        if (!$result) {
            log_message('error', json_encode($this->errors()));
        }
        $new = $this->find($orderId);
        log_message('debug', json_encode($new));

        return $result;
    }

    /**
     * Verifikasi pembayaran
     */
    public function verifyPayment($orderId, $adminId)
    {
        return $this->update($orderId, [
            'payment_status' => 'dp_paid',
            'verified_by' => $adminId,
            'verified_date' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Dapatkan laporan penjualan per bulan/tahun
     */
    public function getSalesReport($month = null, $year = null, $paymentStatus = null)
    {
        $query = $this->where('payment_status !=', 'cancelled')
            ->where('order_status !=', 'cancelled');

        // If paymentStatus explicitly provided, filter for it (e.g., 'paid')
        if ($paymentStatus !== null) {
            $query->where('payment_status', $paymentStatus);
        }

        if ($month) {
            $query->where("MONTH(created_at)", $month);
        }
        if ($year) {
            $query->where("YEAR(created_at)", $year);
        }

        return $query->findAll();
    }

    /**
     * Dapatkan stat penjualan
     */
    public function getSalesStats($month = null, $year = null, $paymentStatus = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('orders')
            ->select('COUNT(*) as total_orders, SUM(total_price) as total_revenue')
            ->where('payment_status !=', 'cancelled')
            ->where('order_status !=', 'cancelled');

        if ($paymentStatus !== null) {
            // Support both single status (string) and multiple statuses (array)
            if (is_array($paymentStatus)) {
                $builder->whereIn('payment_status', $paymentStatus);
            } else {
                $builder->where('payment_status', $paymentStatus);
            }
        }

        if ($month) {
            $builder->where("MONTH(created_at)", $month);
        }
        if ($year) {
            $builder->where("YEAR(created_at)", $year);
        }

        return $builder->get()->getRowArray();
    }

}
