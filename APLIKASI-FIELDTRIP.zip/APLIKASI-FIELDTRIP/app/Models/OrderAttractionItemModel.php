<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderAttractionItemModel extends Model
{
    protected $table = 'order_attraction_items';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['order_id', 'attraction_id', 'price_at_booking', 'quantity'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';

    /**
     * Tambah wahana ke pesanan
     */
    public function addAttractionToOrder($orderId, $attractionId, $price, $quantity = 1)
    {
        return $this->insert([
            'order_id' => $orderId,
            'attraction_id' => $attractionId,
            'price_at_booking' => $price,
            'quantity' => $quantity,
        ]);
    }

    /**
     * Dapatkan total harga wahana untuk pesanan
     */
    public function getTotalAttractionPrice($orderId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('order_attraction_items');
        $result = $builder->select('COALESCE(SUM(price_at_booking * quantity), 0) as total')
            ->where('order_id', $orderId)
            ->get()
            ->getRowArray();

        return $result['total'] ?? 0;
    }

    /**
     * Delete wahana dari pesanan
     */
    public function removeAttractionFromOrder($orderId, $attractionId)
    {
        return $this->where('order_id', $orderId)
            ->where('attraction_id', $attractionId)
            ->delete();
    }
}
