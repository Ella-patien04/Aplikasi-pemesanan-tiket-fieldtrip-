<?php

namespace App\Controllers;

use App\Models\OrderModel;
use CodeIgniter\Controller;

class OrderController extends Controller
{
    public function save()
    {
        $orderModel = new OrderModel();

        // Ambil input dari form (sesuai dengan field di customer/order/form.php)
        $numParticipants = (int)$this->request->getPost('num_participants');
        $numGuardians = (int)$this->request->getPost('num_guardians');
        $numTeachers = (int)$this->request->getPost('num_teachers');
        $package_id = $this->request->getPost('package_id');

        // Harga paket berdasarkan package_id
        $prices = [
            1 => 75000,
            2 => 85000,
            3 => 95000
        ];

        $price = $prices[$package_id] ?? 0;
        $total = $numParticipants * $price;
        $dp = $total * 0.3;

        // Normalize visit_date
        $visitDate = $this->request->getPost('visit_date') 
            ? date('Y-m-d', strtotime($this->request->getPost('visit_date'))) 
            : date('Y-m-d');

        // Cek apakah kuota cukup untuk tanggal yang dipilih
        if (!$orderModel->canAccommodateOnDate($visitDate, $numParticipants)) {
            $available = $orderModel->getAvailableCapacityByDate($visitDate);
            return redirect()->back()->withInput()->with('error', 'Kuota untuk tanggal ' . $visitDate . ' tidak mencukupi. Sisa kuota: ' . $available . ' peserta.');
        }

        // Simpan order dengan field yang sesuai dengan form dan tabel orders
        $orderModel->save([
            'user_id' => session()->get('user_id'),
            'visit_date' => $visitDate,
            'school_name' => $this->request->getPost('school_name'),
            'booker_name' => $this->request->getPost('booker_name'),
            'phone' => $this->request->getPost('phone'),
            'num_participants' => $numParticipants,
            'num_guardians' => $numGuardians,
            'num_teachers' => $numTeachers,
            'package_id' => $package_id,
            'total_price' => $total,
            'dp_amount' => $dp,
            'payment_status' => 'pending',
            'order_status' => 'pending'
        ]);

        return redirect()->to('/customer/dashboard')->with('success', 'Pesanan berhasil dibuat!');
    }
}