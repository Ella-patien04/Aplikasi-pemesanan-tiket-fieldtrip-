<?php

namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use App\Models\UserModel;

class AdminAuth extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function adminLogin()
    {
        if (session()->has('user_id') && session()->get('user_role') === 'admin') {
            return redirect()->to('/admin/dashboard');
        }

        if (session()->has('user_id')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/admin_login');
    }

    public function doAdminLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $email = is_string($email) ? trim(strtolower($email)) : '';
        $password = is_string($password) ? trim($password) : '';

        if (empty($email) || empty($password)) {
            return redirect()->back()->with('error', 'Email dan password harus diisi');
        }

        $user = $this->userModel->findByEmail($email);

        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Email atau password admin salah');
        }

        if ($user['role'] !== 'admin') {
            return redirect()->back()->with('error', 'Akun ini bukan akun admin');
        }

        if (!$user['is_active']) {
            return redirect()->back()->with('error', 'Akun admin tidak aktif');
        }

        session()->set([
            'user_id' => $user['id'],
            'user_name' => $user['name'],
            'user_email' => $user['email'],
            'user_role' => $user['role'],
            'logged_in' => true,
        ]);

        return redirect()->to('/admin/dashboard')->with('success', 'Login admin berhasil');
    }
}
