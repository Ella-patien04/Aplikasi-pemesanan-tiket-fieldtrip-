<?php

namespace App\Controllers;

use App\Models\PackageModel;
use App\Models\AttractionModel;
// Schedule management deprecated: using visit_date on orders instead
use App\Models\OrderModel;
use App\Models\UserModel;

class Admin extends BaseController
{
    protected $packageModel;
    protected $attractionModel;
    protected $orderModel;
    protected $userModel;

    public function __construct()
    {
        $this->packageModel = new PackageModel();
        $this->attractionModel = new AttractionModel();
        $this->orderModel = new OrderModel();
        $this->userModel = new UserModel();
    }

    /**
     * Dashboard Admin
     */
    public function dashboard()
    {
        $data = [
            'total_packages' => count($this->packageModel->getActivePackages()),
            'total_attractions' => count($this->attractionModel->getActiveAttractions()),
            'pending_orders' => count($this->orderModel->getPendingOrders()),
            'pending_payments' => count($this->orderModel->getOrdersByPaymentStatus('pending')),
        ];

        return view('admin/dashboard', $data);
    }

    // ===== PACKAGES =====

    /**
     * List Packages
     */
    public function packageList()
    {
        $packages = $this->packageModel->findAll();
        $data = ['packages' => $packages];
        return view('admin/packages/list', $data);
    }

    /**
     * Form tambah package
     */
    public function packageAdd()
    {
        return view('admin/packages/form');
    }

    /**
     * Simpan package baru
     */
    public function packageSave()
    {
        $rules = [
            'name' => 'required|string|max_length[100]',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'facilities' => 'required|string',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $facilitiesRaw = (string) ($this->request->getPost('facilities') ?? '');
        $facilitiesArr = array_map('trim', explode(',', $facilitiesRaw));
        $facilitiesArr = array_values(array_filter($facilitiesArr, 'strlen'));

        $data = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price'),
            'facilities' => $facilitiesArr,
            'is_active' => 1,
        ];

        // Handle upload image
        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move('uploads/packages', $newName);
            $data['image'] = 'uploads/packages/' . $newName;
        }

        if (!$this->packageModel->insert($data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal menambah package');
        }

        return redirect()->to('/admin/packages')->with('success', 'Package berhasil ditambahkan');
    }

    /**
     * Form edit package
     */
    public function packageEdit($id)
    {
        $package = $this->packageModel->find($id);
        if (!$package) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = ['package' => $package];
        return view('admin/packages/form', $data);
    }

    /**
     * Update package
     */
    public function packageUpdate($id)
    {
        $package = $this->packageModel->find($id);
        if (!$package) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $rules = [
            'name' => 'required|string|max_length[100]',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'facilities' => 'required|string',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $facilitiesRaw = (string) ($this->request->getPost('facilities') ?? '');
        $facilitiesArr = array_map('trim', explode(',', $facilitiesRaw));
        $facilitiesArr = array_values(array_filter($facilitiesArr, 'strlen'));

        $data = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price'),
            'facilities' => $facilitiesArr,
        ];

        // Handle upload image
        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            // Hapus image lama
            if ($package['image'] && file_exists($package['image'])) {
                unlink($package['image']);
            }
            $newName = $image->getRandomName();
            $image->move('uploads/packages', $newName);
            $data['image'] = 'uploads/packages/' . $newName;
        }

        if (!$this->packageModel->update($id, $data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal mengupdate package');
        }

        return redirect()->to('/admin/packages')->with('success', 'Package berhasil diupdate');
    }

    /**
     * Delete package
     */
    public function packageDelete($id)
    {
        $package = $this->packageModel->find($id);
        if (!$package) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if ($package['image'] && file_exists($package['image'])) {
            unlink($package['image']);
        }

        if (!$this->packageModel->delete($id)) {
            return redirect()->back()->with('error', 'Gagal menghapus package');
        }

        return redirect()->to('/admin/packages')->with('success', 'Package berhasil dihapus');
    }

    // ===== ATTRACTIONS =====

    /**
     * List Attractions
     */
    public function attractionList()
    {
        $attractions = $this->attractionModel->findAll();
        $data = ['attractions' => $attractions];
        return view('admin/attractions/list', $data);
    }

    /**
     * Form tambah attraction
     */
    public function attractionAdd()
    {
        return view('admin/attractions/form');
    }

    /**
     * Simpan attraction baru
     */
    public function attractionSave()
    {
        $rules = [
            'name' => 'required|string|max_length[255]',
            'description' => 'required|string',
            'price' => 'required|numeric',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price'),
            'is_active' => 1,
        ];

        // Handle upload image
        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move('uploads/attractions', $newName);
            $data['image'] = 'uploads/attractions/' . $newName;
        }

        if (!$this->attractionModel->insert($data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal menambah wahana');
        }

        return redirect()->to('/admin/attractions')->with('success', 'Wahana berhasil ditambahkan');
    }

    /**
     * Form edit attraction
     */
    public function attractionEdit($id)
    {
        $attraction = $this->attractionModel->find($id);
        if (!$attraction) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = ['attraction' => $attraction];
        return view('admin/attractions/form', $data);
    }

    /**
     * Update attraction
     */
    public function attractionUpdate($id)
    {
        $attraction = $this->attractionModel->find($id);
        if (!$attraction) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $rules = [
            'name' => 'required|string|max_length[255]',
            'description' => 'required|string',
            'price' => 'required|numeric',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price'),
        ];

        // Handle upload image
        $image = $this->request->getFile('image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            if ($attraction['image'] && file_exists($attraction['image'])) {
                unlink($attraction['image']);
            }
            $newName = $image->getRandomName();
            $image->move('uploads/attractions', $newName);
            $data['image'] = 'uploads/attractions/' . $newName;
        }

        if (!$this->attractionModel->update($id, $data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal mengupdate wahana');
        }

        return redirect()->to('/admin/attractions')->with('success', 'Wahana berhasil diupdate');
    }

    /**
     * Delete attraction
     */
    public function attractionDelete($id)
    {
        $attraction = $this->attractionModel->find($id);
        if (!$attraction) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if ($attraction['image'] && file_exists($attraction['image'])) {
            unlink($attraction['image']);
        }

        if (!$this->attractionModel->delete($id)) {
            return redirect()->back()->with('error', 'Gagal menghapus wahana');
        }

        return redirect()->to('/admin/attractions')->with('success', 'Wahana berhasil dihapus');
    }

    // ===== ORDERS - VERIFIKASI & KONFIRMASI =====

    /**
     * List pending orders (untuk verifikasi)
     */
    public function pendingOrders()
    {
        $orders = $this->orderModel->getPendingOrders();
        $data = ['orders' => $orders];
        return view('admin/orders/pending', $data);
    }

    /**
     * Detail order
     */
    public function orderDetail($id)
    {
        $order = $this->orderModel->getOrderDetail($id);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = ['order' => $order];
        return view('admin/orders/detail', $data);
    }

    /**
     * Verifikasi pembayaran
     */
    public function verifyPayment($id)
    {
        $order = $this->orderModel->find($id);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $adminId = session()->get('user_id');
        if (!$this->orderModel->verifyPayment($id, $adminId)) {
            return redirect()->back()->with('error', 'Gagal verifikasi pembayaran');
        }

        return redirect()->to('/admin/orders/pending')->with('success', 'Pembayaran berhasil diverifikasi');
    }

    /**
     * List all orders (Admin)
     */
    public function allOrders()
    {
        $orders = $this->orderModel
            ->orderBy('created_at', 'DESC')
            ->findAll();

        $data = ['orders' => $orders];
        return view('admin/orders/list', $data);
    }

    /**
     * Form create order (admin)
     * Note: untuk versi awal, admin tidak benar-benar membuat order dari UI.
     */
    public function orderCreate()
    {
        return redirect()->to('/admin/orders');
    }

    /**
     * Save order (admin)
     */
    public function orderSave()
    {
        return redirect()->to('/admin/orders');
    }

    /**
     * Form edit order (admin)
     */
    public function orderEdit($id)
    {
        $order = $this->orderModel->getOrderDetail($id);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('admin/orders/detail', ['order' => $order]);
    }

    /**
     * Update order (admin)
     */
    public function orderUpdate($id)
    {
        $order = $this->orderModel->getOrderDetail($id);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Admin hanya boleh mengubah status pembayaran & status pesanan (untuk konfirmasi/kelola pesanan)
        // Admin TIDAK boleh mengubah `fieldtrip_status`.
        $paymentStatus = (string) ($this->request->getPost('payment_status') ?? '');
        $orderStatus = (string) ($this->request->getPost('order_status') ?? '');


        $allowedPayment = ['pending', 'dp_paid', 'paid', 'cancelled'];
        $allowedOrder = ['pending', 'confirmed', 'completed', 'cancelled', 'in_progress'];

        // Guard: cegah admin menyuplai fieldtrip_status secara ilegal (jika UI/attacker mengirimnya)
        if (($this->request->getPost('fieldtrip_status') ?? null) !== null) {
            return redirect()->back()->with('error', 'Admin tidak diperbolehkan mengubah status pelaksanaan fieldtrip');
        }


        if (!in_array($paymentStatus, $allowedPayment, true)) {
            return redirect()->back()->with('error', 'payment_status tidak valid');
        }
        if (!in_array($orderStatus, $allowedOrder, true)) {
            return redirect()->back()->with('error', 'order_status tidak valid');
        }

        $adminId = session()->get('user_id');
        log_message('debug', 'Admin orderUpdate: sebelum update order ' . $id . ' payment_status=' . ($order['payment_status'] ?? '') . ' order_status=' . ($order['order_status'] ?? ''));

        $proofPath = null;
        $file = $this->request->getFile('proof_payment_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move('uploads/payments', $newName);
            $proofPath = 'uploads/payments/' . $newName;

            // Hapus bukti lama jika ada
            if (!empty($order['proof_payment_image']) && is_string($order['proof_payment_image'])) {
                $old = $order['proof_payment_image'];
                if (file_exists($old)) {
                    @unlink($old);
                }
            }
        }

        $data = [
            'payment_status' => $paymentStatus,
            'order_status' => $orderStatus,
        ];

        if ($orderStatus === 'confirmed') {
            $data['confirmation_date'] = date('Y-m-d H:i:s');
        }

        // When verifying payment via admin action
        if (in_array($paymentStatus, ['dp_paid', 'paid'], true)) {
            $data['verified_by'] = $adminId;
            $data['verified_date'] = date('Y-m-d H:i:s');
        }

        if ($proofPath) {
            $data['proof_payment_image'] = $proofPath;
        }

        // Update using model update for allowedFields
        $updated = $this->orderModel->update($id, $data);
        if ($updated) {
            $freshOrder = $this->orderModel->find($id);
            log_message('debug', 'Admin orderUpdate: berhasil update order ' . $id);
            log_message('debug', 'Admin orderUpdate: order terbaru ' . json_encode($freshOrder));
        } else {
            log_message('error', 'Admin orderUpdate: gagal update order ' . $id . ' errors=' . json_encode($this->orderModel->errors()));
        }

        return redirect()->to('/admin/orders/detail/' . $id)->with('success', 'Pesanan berhasil diupdate');
    }


    /**
     * Delete order (admin)
     */
    public function orderDelete($id)
    {
        $this->orderModel->delete($id);
        return redirect()->to('/admin/orders')->with('success', 'Pesanan berhasil dihapus');
    }

    /**
     * Konfirmasi order
     */
    public function confirmOrder($id)
    {
        $order = $this->orderModel->find($id);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Update order status
        $this->orderModel->updateOrderStatus($id, 'confirmed', 'dp_paid');

        // No schedule reservations needed; quota managed by visit_date in orders

        return redirect()->to('/admin/orders/pending')->with('success', 'Pesanan berhasil dikonfirmasi');
    }

    // ===== REPORTS =====


    /**
     * Laporan pemesanan (Pending vs DP/Lunas)
     */
    public function bookingReport()
    {
        $startDate = (string) ($this->request->getGet('start_date') ?? '');
        $endDate = (string) ($this->request->getGet('end_date') ?? '');

        $startDate = $startDate !== '' ? $startDate : null;
        $endDate = $endDate !== '' ? $endDate : null;

        // Pending: payment_status = 'pending'
        $pendingOrders = $this->orderModel
            ->where('payment_status', 'pending')
            ->when($startDate, function ($q) use ($startDate) {
                return $q->where('created_at >=', $startDate . ' 00:00:00');
            })
            ->when($endDate, function ($q) use ($endDate) {
                return $q->where('created_at <=', $endDate . ' 23:59:59');
            })
            ->orderBy('created_at', 'DESC')
            ->findAll();

        // DP/Lunas: payment_status IN ('dp_paid', 'paid')
        $successOrders = $this->orderModel
            ->whereIn('payment_status', ['dp_paid', 'paid'])
            ->when($startDate, function ($q) use ($startDate) {
                return $q->where('created_at >=', $startDate . ' 00:00:00');
            })
            ->when($endDate, function ($q) use ($endDate) {
                return $q->where('created_at <=', $endDate . ' 23:59:59');
            })
            ->orderBy('created_at', 'DESC')
            ->findAll();

        return view('admin/reports/booking_orders', [
            'pendingOrders' => $pendingOrders,
            'successOrders' => $successOrders,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'activeTab' => 'pending',
        ]);
    }

    /**
     * Print / PDF via browser (open as printable page in new tab)
     */
    public function bookingReportPrint()
    {
        $startDate = (string) ($this->request->getGet('start_date') ?? '');
        $endDate = (string) ($this->request->getGet('end_date') ?? '');

        $startDate = $startDate !== '' ? $startDate : null;
        $endDate = $endDate !== '' ? $endDate : null;

        $pendingOrders = $this->orderModel
            ->where('payment_status', 'pending')
            ->when($startDate, function ($q) use ($startDate) {
                return $q->where('created_at >=', $startDate . ' 00:00:00');
            })
            ->when($endDate, function ($q) use ($endDate) {
                return $q->where('created_at <=', $endDate . ' 23:59:59');
            })
            ->orderBy('created_at', 'DESC')
            ->findAll();

        $successOrders = $this->orderModel
            ->whereIn('payment_status', ['dp_paid', 'paid'])
            ->when($startDate, function ($q) use ($startDate) {
                return $q->where('created_at >=', $startDate . ' 00:00:00');
            })
            ->when($endDate, function ($q) use ($endDate) {
                return $q->where('created_at <=', $endDate . ' 23:59:59');
            })
            ->orderBy('created_at', 'DESC')
            ->findAll();

        // same view; user can print/save as PDF from browser dialog
        return view('admin/reports/booking_orders', [
            'pendingOrders' => $pendingOrders,
            'successOrders' => $successOrders,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'activeTab' => 'pending',
        ]);
    }

    /**
     * Laporan penjualan
     */
    public function salesReport()
    {
        $orders = $this->orderModel->where('payment_status !=', 'cancelled')
            ->where('order_status !=', 'cancelled')
            ->orderBy('created_at', 'DESC')
            ->findAll();

        $data = ['orders' => $orders];
        return view('admin/reports/sales', $data);
    }

    /**
     * User management page
     */
    public function userList()
    {
        $users = $this->userModel->findAll();
        $data = ['users' => $users];

        return view('admin/users/list', $data);
    }

    /**
     * Form edit user
     */
    public function userEdit($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')->with('error', 'Pengguna tidak ditemukan');
        }

        return view('admin/users/edit', ['pengguna' => $user]);
    }

    /**
     * Update user
     */
    public function userUpdate($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')->with('error', 'Pengguna tidak ditemukan');
        }

        // Role & is_active hanya untuk edit
        // NOTE: password tidak diubah di form edit ini sesuai kebutuhan.
        $rules = [
            'name' => 'required|string|max_length[255]',
            'email' => 'required|valid_email|is_unique[users.email,id,' . (int)$id . ']',
            'phone' => 'permit_empty|string|max_length[15]',
            'role' => 'required|in_list[admin,customer,pengelola,owner]',
            'is_active' => 'required|in_list[0,1]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name' => (string) $this->request->getPost('name'),
            'email' => (string) $this->request->getPost('email'),
            'phone' => (string) ($this->request->getPost('phone') ?? ''),
            'role' => (string) $this->request->getPost('role'),
            'is_active' => (int) $this->request->getPost('is_active'),
        ];

        if (!$this->userModel->update($id, $data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal mengupdate pengguna');
        }

        return redirect()->to('/admin/users')->with('success', 'Pengguna berhasil diupdate');
    }

    /**
     * Delete user
     */
    public function userDelete($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')->with('error', 'Pengguna tidak ditemukan');
        }

        if (!$this->userModel->delete($id)) {
            return redirect()->to('/admin/users')->with('error', 'Gagal menghapus pengguna');
        }

        return redirect()->to('/admin/users')->with('success', 'Pengguna berhasil dihapus');
    }
}

