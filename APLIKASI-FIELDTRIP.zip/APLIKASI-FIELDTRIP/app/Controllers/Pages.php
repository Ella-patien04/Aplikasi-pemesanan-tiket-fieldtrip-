<?php

namespace App\Controllers;

use App\Models\PackageModel;
use App\Models\AttractionModel;

class Pages extends BaseController
{
    protected $packageModel;
    protected $attractionModel;

    public function __construct()
    {
        $this->packageModel = new PackageModel();
        $this->attractionModel = new AttractionModel();
    }

    public function home()
    {
        $packages = $this->packageModel->getActivePackages();
        $attractions = $this->attractionModel->getActiveAttractions();

        $data = [
            'packages' => array_slice($packages, 0, 3),
            'attractions' => array_slice($attractions, 0, 3),
        ];

        return view('pages/home', $data);
    }

    public function about()
    {
        return view('pages/about');
    }

    public function attractions()
    {
        $data = [
            'attractions' => $this->attractionModel->getActiveAttractions(),
        ];

        return view('pages/attractions', $data);
    }

    public function packages()
    {
        $data = [
            'packages' => $this->packageModel->getActivePackages(),
        ];

        return view('pages/packages', $data);
    }

    public function packageDetail($id)
    {
        $package = $this->packageModel->getPackageById($id);

        if (!$package || (int) $package['is_active'] !== 1) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('pages/package_detail', ['package' => $package]);
    }

    public function gallery()
    {
        return view('pages/gallery');
    }

    public function contact()
    {
        return view('pages/contact');
    }
}
