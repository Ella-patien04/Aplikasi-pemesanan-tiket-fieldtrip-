<?php

namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\OwnerReportModel;

class Owner extends BaseController
{
    protected $orderModel;
    protected $ownerReportModel;

    public function __construct()
    {
        $this->orderModel = new OrderModel();
        $this->ownerReportModel = new OwnerReportModel();
    }


    /**
     * Dashboard Owner
     */
    public function dashboard()
    {
        $currentMonth = date('n');
        $currentYear = date('Y');

        // Total revenue/orders bulan ini
        // Dashboard Owner harus menghitung pesanan yang sudah membayar DP maupun lunas.
        // Jumlah pesanan di dashboard (bulan ini) harus sesuai definisi Laporan Pemesanan Owner:
        // hitung pesanan sukses DP & Lunas (dp_paid, paid), tanpa order cancelled.
        $stats = $this->orderModel->getSalesStats($currentMonth, $currentYear, ['dp_paid', 'paid']);




        // Chart 1: Penjualan Paket (dp_paid & paid)
        $packageSalesCounts = $this->ownerReportModel->getOwnerPackageSalesCounts();

        // Chart 2: Pendapatan bulanan tahun berjalan (dp_amount)
        $monthlyRevenue = $this->ownerReportModel->getOwnerMonthlyRevenueCurrentYear((int) $currentYear);

        $data = [
            'total_revenue' => $stats['total_revenue'] ?? 0,
            'total_orders' => $stats['total_orders'] ?? 0,
            'current_month' => $currentMonth,
            'current_year' => $currentYear,
            'packageSalesCounts' => $packageSalesCounts,
            'monthlyRevenue' => $monthlyRevenue,
        ];


        return view('owner/dashboard', $data);
    }


    /**
     * Laporan penjualan dengan filter
     */
    public function salesReport()
    {
        $month = $this->request->getGet('month') ?? date('n');
        $year = $this->request->getGet('year') ?? date('Y');

        // Get orders dengan filter (only fully paid/lunas)
        $orders = $this->orderModel->getSalesReport($month, $year, 'paid');

        // Calculate stats (only fully paid)
        $stats = $this->orderModel->getSalesStats($month, $year, 'paid');

        $data = [
            'orders' => $orders,
            'total_revenue' => $stats['total_revenue'] ?? 0,
            'total_orders' => $stats['total_orders'] ?? 0,
            'filter_month' => $month,
            'filter_year' => $year,
            'months' => range(1, 12),
            'years' => range(date('Y') - 5, date('Y')),
        ];

        return view('owner/reports/sales', $data);
    }

    /**
     * Download PDF laporan penjualan
     */
    public function downloadSalesReport()
    {
        $month = $this->request->getGet('month') ?? date('n');
        $year = $this->request->getGet('year') ?? date('Y');

        // Only include fully paid orders for PDF
        $orders = $this->orderModel->getSalesReport($month, $year, 'paid');
        $stats = $this->orderModel->getSalesStats($month, $year, 'paid');

        $data = [
            'orders' => $orders,
            'total_revenue' => $stats['total_revenue'] ?? 0,
            'total_orders' => $stats['total_orders'] ?? 0,
            'filter_month' => $month,
            'filter_year' => $year,
            'month_name' => date('F', mktime(0, 0, 0, $month, 1)),
        ];

        // Generate PDF
        helper('pdf');
        log_message('debug', 'Owner::downloadSalesReport month=' . $month . ' year=' . $year . ' orders=' . count($orders));

        // Stream PDF directly as attachment and exit to avoid debug toolbar injection
        generatePdfSalesReport($data, true);
        // generatePdfSalesReport will stream and exit. If it returns, fallback to sending bytes.
        $pdfContent = generatePdfSalesReport($data, false);

        $filename = 'Laporan_Pendapatan_' . $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '_' . date('Y-m-d') . '.pdf';

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->setBody($pdfContent);
    }

    /**
     * Dev helper: same as downloadSalesReport but without owner filter checks.
     * Use only in local/dev environment for debugging.
     */
    public function downloadSalesReportDev()
    {
        $month = $this->request->getGet('month') ?? date('n');
        $year = $this->request->getGet('year') ?? date('Y');

        // Only include fully paid orders for dev download
        $orders = $this->orderModel->getSalesReport($month, $year, 'paid');
        $stats = $this->orderModel->getSalesStats($month, $year, 'paid');

        $data = [
            'orders' => $orders,
            'total_revenue' => $stats['total_revenue'] ?? 0,
            'total_orders' => $stats['total_orders'] ?? 0,
            'filter_month' => $month,
            'filter_year' => $year,
            'month_name' => date('F', mktime(0, 0, 0, $month, 1)),
        ];

        helper('pdf');

        // Try streaming directly (dev endpoint). If stream exits, execution won't reach here.
        generatePdfSalesReport($data, true);

        // Fallback: return bytes
        $pdfContent = generatePdfSalesReport($data, false);
        $filename = 'Laporan_Pendapatan_' . $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '_' . date('Y-m-d') . '.pdf';

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->setBody($pdfContent);
    }

    /**
     * Laporan pemesanan Owner (DP vs Lunas) - tanpa status pending.
     */
    public function bookingReportOwner()
    {
        $startDate = (string) ($this->request->getGet('start_date') ?? '');
        $endDate = (string) ($this->request->getGet('end_date') ?? '');

        $startDate = $startDate !== '' ? $startDate : null;
        $endDate = $endDate !== '' ? $endDate : null;

        $activeTab = (string) ($this->request->getGet('tab') ?? 'dp');
        if (!in_array($activeTab, ['dp', 'paid'], true)) {
            $activeTab = 'dp';
        }

        $dpOrders = $this->ownerReportModel->getOwnerBookingDPReport($startDate, $endDate);
        $paidOrders = $this->ownerReportModel->getOwnerBookingPaidReport($startDate, $endDate);

        return view('owner/reports/booking_owner', [
            'dpOrders' => $dpOrders,
            'paidOrders' => $paidOrders,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'activeTab' => $activeTab,
        ]);
    }

    /**
     * View cetak / PDF (browser print) untuk laporan pemesanan Owner.
     */
    public function bookingReportOwnerPrint()
    {
        $startDate = (string) ($this->request->getGet('start_date') ?? '');
        $endDate = (string) ($this->request->getGet('end_date') ?? '');

        $startDate = $startDate !== '' ? $startDate : null;
        $endDate = $endDate !== '' ? $endDate : null;

        $activeTab = (string) ($this->request->getGet('tab') ?? 'dp');
        if (!in_array($activeTab, ['dp', 'paid'], true)) {
            $activeTab = 'dp';
        }

        $dpOrders = $this->ownerReportModel->getOwnerBookingDPReport($startDate, $endDate);
        $paidOrders = $this->ownerReportModel->getOwnerBookingPaidReport($startDate, $endDate);

        return view('owner/reports/booking_owner_print', [
            'dpOrders' => $dpOrders,
            'paidOrders' => $paidOrders,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'activeTab' => $activeTab,
        ]);
    }
}

