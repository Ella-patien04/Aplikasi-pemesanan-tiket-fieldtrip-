<?php

namespace App\Controllers;

use App\Models\AttractionModel;
use App\Models\OrderModel;
use App\Models\PackageModel;

class Pengelola extends BaseController
{
    protected $attractionModel;
    protected $orderModel;
    protected $packageModel;

    public function __construct()
    {
        $this->attractionModel = new AttractionModel();
        $this->orderModel = new OrderModel();
        $this->packageModel = new PackageModel();
    }

    /**
     * Dashboard Pengelola
     */
    public function dashboard()
    {
        $attractions = $this->attractionModel->findAll();
        $activeAttractions = count($this->attractionModel->getActiveAttractions());

        $data = [
            'total_attractions' => count($attractions),
            'active_attractions' => $activeAttractions,
            'inactive_attractions' => count($attractions) - $activeAttractions,
        ];

        return view('pengelola/dashboard', $data);
    }

    /**
     * Package management placeholder for pengelola
     */
    public function packageList()
    {
        return view('pengelola/packages');
    }

    // ===== MANAGE ATTRACTIONS STATUS =====

    /**
     * List wahana dengan status management
     */
    public function attractionList()
    {
        $attractions = $this->attractionModel->findAll();
        $data = ['attractions' => $attractions];
        return view('pengelola/attractions/list', $data);
    }

    /**
     * Ubah status wahana (aktif/nonaktif)
     */
    public function updateAttractionStatus($id)
    {
        $attraction = $this->attractionModel->find($id);
        if (!$attraction) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $newStatus = $attraction['is_active'] ? 0 : 1;
        $this->attractionModel->updateStatus($id, $newStatus);

        $statusText = $newStatus ? 'aktif' : 'nonaktif';
        return redirect()->to('/pengelola/attractions')->with('success', 'Status wahana berhasil diubah menjadi ' . $statusText);
    }

    // ===== JADWAL PESANAN REPORT =====

    /**
     * Laporan pesanan berdasarkan tanggal kunjungan
     */
    public function scheduleReport()
    {
        $reports = $this->orderModel
            ->select('visit_date, COUNT(id) as confirmed_orders, SUM(num_participants + num_guardians + num_teachers) as total_people')
            ->where('order_status', 'confirmed')
            ->groupBy('visit_date')
            ->orderBy('visit_date', 'ASC')
            ->findAll();

        foreach ($reports as &$report) {
            $report['available_capacity'] = $this->orderModel->getAvailableCapacityByDate($report['visit_date']);
        }

        $data = ['dateReports' => $reports];
        return view('pengelola/reports/schedule', $data);
    }

    /**
     * Detail pesanan berdasarkan tanggal kunjungan
     */
    public function scheduleDetail($visitDate)
    {
        $orders = $this->orderModel
            ->where('visit_date', $visitDate)
            ->where('order_status', 'confirmed')
            ->orderBy('created_at', 'DESC')
            ->findAll();

        foreach ($orders as &$order) {
            $order['attractions'] = $this->orderModel->getOrderAttractions($order['id']);
        }

        $totalPeople = array_reduce($orders, function ($carry, $order) {
            return $carry + ($order['num_participants'] + $order['num_guardians'] + $order['num_teachers']);
        }, 0);

        $data = [
            'visit_date' => $visitDate,
            'orders' => $orders,
            'total_orders' => count($orders),
            'total_people' => $totalPeople,
            'available_capacity' => $this->orderModel->getAvailableCapacityByDate($visitDate),
        ];

        return view('pengelola/reports/schedule-detail', $data);
    }

    // ===== ORDERS - PENGELOLA (KELola PELAKSANAAN FIELDTRIP) =====

    /**
     * Daftar pesanan yang sudah confirmed untuk ditangani pelaksanaannya
     */
    public function orders()
    {
        // Pengelola menangani pesanan dengan:
        // - DP sudah Paid => payment_status = dp_paid
        // NOTE: After successful DP payment via Midtrans, order_status is set to 'confirmed',
        // not 'pending'. So we only filter by payment_status to show all paid DP orders.
        // The view handles additional conditions (e.g., checking order_status and fieldtrip_status
        // when deciding to show the "Selesaikan Fieldtrip" button).
        $orders = $this->orderModel
            ->where('payment_status', 'dp_paid')
            ->orderBy('visit_date', 'ASC')
            ->orderBy('created_at', 'DESC')
            ->findAll();

        $data = ['orders' => $orders];
        return view('pengelola/orders/index', $data);
    }


    /**
     * Detail pesanan
     *
     * NOTE: route saat ini adalah `pengelola/orders/detail/(:num)` sehingga method menerima 1 parameter.
     */
    public function orderDetail($id = null)
    {
        // Route: pengelola/orders/detail/(:num) => $id harus terisi.
        // Method dibuat opsional hanya untuk mencegah error jika router memanggil tanpa parameter.
        $id = (int) ($id ?? 0);

        if ($id <= 0) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $order = $this->orderModel->getOrderDetail($id);

        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = ['order' => $order];
        return view('pengelola/orders/detail', $data);
    }

    /**
     * Update status pelaksanaan (fieldtrip_status)
     */
    public function updateOrderFieldtripStatus($id)
    {
        $order = $this->orderModel->find($id);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $newStatus = (string) ($this->request->getPost('fieldtrip_status') ?? '');
        $allowed = ['pending', 'sedang_dilaksanakan', 'selesai'];
        if (!in_array($newStatus, $allowed, true)) {
            return redirect()->back()->with('error', 'Status pelaksanaan tidak valid');
        }

        // Hanya transisi Pending -> Selesai yang diproses untuk kebutuhan workflow
        $oldStatus = (string) ($order['fieldtrip_status'] ?? 'pending');

        log_message('debug', 'Pengelola updateOrderFieldtripStatus: sebelum update order ' . $id . ' fieldtrip_status=' . $oldStatus);
        $updated = $this->orderModel->update($id, [
            'fieldtrip_status' => $newStatus,
        ]);
        if ($updated) {
            $freshOrder = $this->orderModel->find($id);
            log_message('debug', 'Pengelola updateOrderFieldtripStatus: berhasil update order ' . $id);
            log_message('debug', 'Pengelola updateOrderFieldtripStatus: order terbaru ' . json_encode($freshOrder));
        } else {
            log_message('error', 'Pengelola updateOrderFieldtripStatus: gagal update order ' . $id . ' errors=' . json_encode($this->orderModel->errors()));
        }

        // Notifikasi ke customer hanya ketika status berubah menjadi Selesai
        if ($newStatus === 'selesai' && $oldStatus !== 'selesai') {
            // Gunakan flashdata/notifikasi ringan berbasis redirect (tanpa mengubah struktur DB)
            // Jika ada mekanisme notifikasi lain di project, bisa diperluas.
            $this->setCustomerNotificationForOrder($order['user_id'] ?? null, $id);
        }

        return redirect()->to('/pengelola/orders')
            ->with('success', 'Status pelaksanaan berhasil diupdate');

    }

    /**
     * Notifikasi sederhana untuk customer (menggunakan flashdata global).
     * Tanpa mengubah database/route yang sudah berjalan.
     */
    private function setCustomerNotificationForOrder($userId, $orderId)
    {
        if (!$userId) {
            return;
        }

        // Gunakan session flash yang akan ditampilkan di dashboard/history customer saat mereka membuka halaman.
        // Karena project ini sudah memakai flashdata di beberapa tempat, pendekatan ini tidak merusak flow yang ada.
        session()->setFlashdata('info', 'Fieldtrip Anda telah selesai dilaksanakan. Silakan melakukan pelunasan sisa pembayaran.');
    }


    /**
     * Kelola informasi placeholder
     */
    public function information()
    {
        return view('pengelola/information');
    }
}

