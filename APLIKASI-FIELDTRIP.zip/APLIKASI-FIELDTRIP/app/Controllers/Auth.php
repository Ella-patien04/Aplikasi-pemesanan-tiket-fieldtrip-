<?php

namespace App\Controllers;

use App\Models\UserModel;
use Config\Email as EmailConfig;
use Config\Services;

class Auth extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    /**
     * Halaman login umum
     */
    public function login()
    {
        // Jika sudah login, redirect ke dashboard sesuai role
        if (session()->has('user_id')) {
            $role = session()->get('user_role');
            if ($role === 'admin') {
                return redirect()->to('/admin/dashboard');
            }
            if ($role === 'pengelola') {
                return redirect()->to('/pengelola/dashboard');
            }
            if ($role === 'owner') {
                return redirect()->to('/owner/dashboard');
            }
            return redirect()->to('/dashboard');
        }

        return view('auth/login');
    }

    /**
     * Proses login umum
     */
    public function doLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // Normalisasi input: trim dan lowercase email untuk menghindari kegagalan karena spasi/kapital
        $email = is_string($email) ? trim(strtolower($email)) : '';
        $password = is_string($password) ? trim($password) : '';

        $user = $this->userModel->verifyLogin($email, $password);

        if (!$user) {
            return redirect()->back()->with('error', 'Email atau password salah');
        }

        $session = session();
        $session->set([
            'user_id' => $user['id'],
            'user_name' => $user['name'],
            'user_email' => $user['email'],
            'user_role' => $user['role'],
            'logged_in' => true,
        ]);

        if ($user['role'] === 'admin') {
            return redirect()->to('/admin/dashboard')->with('success', 'Login admin berhasil');
        }

        if ($user['role'] === 'pengelola') {
            return redirect()->to('/pengelola/dashboard')->with('success', 'Login berhasil');
        }

        if ($user['role'] === 'owner') {
            return redirect()->to('/owner/dashboard')->with('success', 'Login berhasil');
        }

        return redirect()->to('/dashboard')->with('success', 'Login berhasil');
    }

    /**
     * Halaman registrasi
     */
    public function register()
    {
        // Jika sudah login, redirect ke dashboard
        if (session()->has('user_id')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/register');
    }

    /**
     * Halaman lupa password
     */
    public function forgotPassword()
    {
        if (session()->has('user_id')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/forgot_password');
    }

    /**
     * Proses lupa password
     */
    public function sendForgotPassword()
    {
        $email = $this->request->getPost('email');
        $email = is_string($email) ? trim(strtolower($email)) : '';

        if (empty($email)) {
            return redirect()->back()->with('error', 'Email harus diisi');
        }

        $user = $this->userModel->findByEmail($email);

        if (!$user || !$user['is_active']) {
            return redirect()->to('/auth/login')->with('success', 'Jika email Anda terdaftar, instruksi reset sudah dikirim. Silakan cek kotak masuk email.');
        }

        $otpCode = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiresAt = date('Y-m-d H:i:s', time() + 900); // 15 menit

        $this->userModel->setPasswordResetOtp($user['id'], $otpCode, $expiresAt);

        $emailService = Services::email();
        $emailService->setFrom('noreply@fieldtripbooking.com', 'Fieldtrip Booking');
        $emailService->setTo($user['email']);
        $emailService->setSubject('Reset Password Fieldtrip Booking');
        $emailService->setMessage("Halo {$user['name']},\n\nKami menerima permintaan reset password. Gunakan kode OTP berikut untuk mengatur ulang password Anda:\n\nKode OTP: {$otpCode}\n\nKode ini berlaku selama 15 menit. Jika Anda tidak meminta reset password, abaikan email ini.\n\nSalam,\nTim Fieldtrip Booking");

        if (!$emailService->send()) {
            return redirect()->back()->with('error', 'Gagal mengirim email OTP. Silakan hubungi administrator.');
        }

        session()->set('reset_email', $user['email']);

        return redirect()->to('/auth/verify-otp')->with('success', 'Kode OTP telah dikirim ke email Anda. Silakan cek kotak masuk.');
    }

    /**
     * Halaman verifikasi OTP
     */
    public function verifyOtp()
    {
        if (session()->has('user_id')) {
            return redirect()->to('/dashboard');
        }

        if (!session()->has('reset_email')) {
            return redirect()->to('/auth/forgot-password')->with('error', 'Silakan mulai proses reset password terlebih dahulu.');
        }

        return view('auth/verify_otp', [
            'email' => session()->get('reset_email'),
        ]);
    }

    /**
     * Proses verifikasi OTP
     */
    public function processVerifyOtp()
    {
        $email = $this->request->getPost('email');
        $otp = $this->request->getPost('otp');

        $email = is_string($email) ? trim(strtolower($email)) : '';
        $otp = is_string($otp) ? trim($otp) : '';

        if (empty($email) || empty($otp)) {
            return redirect()->back()->with('error', 'Email dan kode OTP harus diisi')->withInput();
        }

        $user = $this->userModel->verifyResetOtp($email, $otp);
        if (!$user) {
            return redirect()->back()->with('error', 'Kode OTP tidak valid atau sudah kedaluwarsa')->withInput();
        }

        session()->set('reset_user_id', $user['id']);
        session()->set('reset_email', $user['email']);

        return redirect()->to('/auth/reset-password')->with('success', 'OTP valid. Silakan atur password baru Anda.');
    }

    /**
     * Halaman reset password
     */
    public function resetPassword()
    {
        if (session()->has('user_id')) {
            return redirect()->to('/dashboard');
        }

        if (!session()->has('reset_user_id')) {
            return redirect()->to('/auth/forgot-password')->with('error', 'Silakan mulai proses reset password terlebih dahulu.');
        }

        return view('auth/reset_password', [
            'email' => session()->get('reset_email'),
        ]);
    }

    /**
     * Proses reset password
     */
    public function processResetPassword()
    {
        if (!session()->has('reset_user_id')) {
            return redirect()->to('/auth/forgot-password')->with('error', 'Silakan mulai proses reset password terlebih dahulu.');
        }

        $rules = [
            'password' => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $userId = session()->get('reset_user_id');
        $password = $this->request->getPost('password');

        $this->userModel->update($userId, [
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'otp_code' => null,
            'otp_expired_at' => null,
            'reset_token' => null,
        ]);

        session()->remove(['reset_user_id', 'reset_email']);

        return redirect()->to('/auth/login')->with('success', 'Password berhasil diubah. Silakan login.');
    }

    /**
     * Proses registrasi
     */
    public function doRegister()
    {
        $rules = [
            'name' => 'required|string|min_length[3]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'phone' => 'required|string|min_length[10]',
            'password' => 'required|min_length[6]',
            'password_confirm' => 'required|min_length[6]|matches[password]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'password' => $this->request->getPost('password'),
        ];

        // Register
        if (!$this->userModel->registerUser($data)) {
            return redirect()->back()->withInput()->with('error', 'Registrasi gagal');
        }

        return redirect()->to('/auth/login')->with('success', 'Registrasi berhasil, silakan login');
    }

    /**
     * Logout
     */
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/')->with('success', 'Logout berhasil');
    }
}
