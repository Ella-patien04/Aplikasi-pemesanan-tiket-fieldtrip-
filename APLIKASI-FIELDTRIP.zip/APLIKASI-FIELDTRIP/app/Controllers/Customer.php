<?php


namespace App\Controllers;

use App\Models\PackageModel;
use App\Models\AttractionModel;
use App\Models\OrderModel;
use App\Models\OrderAttractionItemModel;
use App\Models\PaymentLogModel;
use Dompdf\Dompdf;

class Customer extends BaseController
{
    protected $packageModel;
    protected $attractionModel;
    protected $orderModel;
    protected $orderAttractionModel;
    protected $paymentLogModel;

    public function __construct()
    {
        $this->packageModel = new PackageModel();
        $this->attractionModel = new AttractionModel();
        $this->orderModel = new OrderModel();
        $this->orderAttractionModel = new OrderAttractionItemModel();
        $this->paymentLogModel = new PaymentLogModel();
    }

    /**
     * Dashboard Customer
     */
    public function dashboard()
    {
        $userId = session()->get('user_id');
        $orders = $this->orderModel->getUserOrders($userId);

        $data = [
            'total_orders' => count($orders),
            'orders' => $orders,
        ];

        return view('customer/dashboard', $data);
    }

    /**
     * Form pemesanan
     */
    public function orderForm()
    {
        $packages = $this->packageModel->getActivePackages();
        $attractions = $this->attractionModel->getActiveAttractions();
        $selectedPackageId = $this->request->getGet('package_id');

        // customer will pick visit_date; availability is checked via AJAX
        $data = [
            'packages' => $packages,
            'attractions' => $attractions,
            'selectedPackageId' => $selectedPackageId,
        ];

        return view('customer/order/form', $data);
    }

    /**
     * Customer profile page
     */
    public function profile()
    {
        $data = [
            'user' => [
                'name' => session()->get('user_name') ?? session()->get('username'),
                'email' => session()->get('user_email') ?? '',
                'role' => session()->get('user_role'),
            ],
        ];

        return view('customer/profile', $data);
    }

    /**
     * Get available dates via AJAX
     */
    public function getAvailableDates()
    {
        // Build next 30 days availability based on orders
        $dates = [];
        for ($i = 0; $i < 30; $i++) {
            $d = date('Y-m-d', strtotime("+{$i} days"));
            $avail = $this->orderModel->getAvailableCapacityByDate($d);
            if ($avail > 0) {
                $dates[] = ['date' => $d, 'available' => $avail];
            }
        }

        return $this->response->setJSON([
            'success' => true,
            'dates' => $dates,
        ]);
    }

    /**
     * Get capacity untuk specific date via AJAX
     */
    public function getDateCapacity($date)
    {
        $date = date('Y-m-d', strtotime($date)); // Normalize format

        $available = $this->orderModel->getAvailableCapacityByDate($date);
        $isFull = ($available <= 0);

        return $this->response->setJSON([
            'success' => true,
            'date' => $date,
            'available' => $available,
            'is_full' => $isFull,
            'message' => $isFull ? 'Kuota penuh untuk tanggal ini' : 'Kapasitas tersedia: ' . $available . ' peserta',
        ]);
    }

    /**
     * Check availability untuk jumlah peserta di date tertentu (AJAX)
     */
    public function checkAvailability($date, $numParticipants)
    {
        $date = date('Y-m-d', strtotime($date));
        $can = $this->orderModel->canAccommodateOnDate($date, (int)$numParticipants);

        return $this->response->setJSON([
            'success' => true,
            'available' => $can,
        ]);
    }

    /**
     * Save order
     */
    public function saveOrder()
    {
        $rules = [
            'school_name' => 'required',
            'booker_name' => 'required',
            'phone' => 'required',
            'num_participants' => 'required|integer|greater_than[0]',
            'num_guardians' => 'required|integer|greater_than_equal_to[0]',
            'num_teachers' => 'required|integer|greater_than_equal_to[0]',
            'package_id' => 'required',
            'visit_date' => 'required|valid_date[Y-m-d]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $visitDate = date('Y-m-d', strtotime($this->request->getPost('visit_date')));
        $numParticipants = (int )$this->request->getPost('num_participants');
        $numGuardians = (int)$this->request->getPost('num_guardians');
        $numTeachers = (int)$this->request->getPost('num_teachers');

        // Check quota per date (max 350 peserta per hari)
        if (!$this->orderModel->canAccommodateOnDate($visitDate, $numParticipants)) {
            $available = $this->orderModel->getAvailableCapacityByDate($visitDate);
            return redirect()->back()->withInput()->with('error', 
                'Kuota pada tanggal yang dipilih sudah penuh, silakan pilih tanggal lain.');
        }

        // Ambil paket
        $packageId = $this->request->getPost('package_id');
        $package = $this->packageModel->find($packageId);

        if (!$package) {
            return redirect()->back()->with('error', 'Paket tidak ditemukan');
        }

        // Hitung harga: peserta + wali murid + guru
        $GUARDIAN_COST = 15000;
        $TEACHER_COST = 15000;
        $BONUS_TEACHERS_PER = 75;
        $BONUS_TEACHERS_COUNT = 5;

        // Total peserta
        $totalPriceParticipants = $numParticipants * $package['price'];

        // Biaya wali murid
        $guardiansCost = $numGuardians * $GUARDIAN_COST;

        // Biaya guru (dengan bonus)
        $bonusTeachers = floor($numParticipants / $BONUS_TEACHERS_PER) * $BONUS_TEACHERS_COUNT;
        $teachersCharged = max(0, $numTeachers - $bonusTeachers);
        $teachersCost = $teachersCharged * $TEACHER_COST;

        // Wahana tambahan
        $attractionIds = $this->request->getPost('attractions') ?? [];
        $attractionIds = array_filter(array_map('intval', (array)$attractionIds));

        $attractionTotal = 0;
        $selectedAttractions = [];
        if (!empty($attractionIds)) {
            $selectedAttractions = $this->attractionModel->getAttractionsByIds($attractionIds);
            foreach ($selectedAttractions as $attraction) {
                $attractionTotal += ($attraction['price'] ?? 0) * $numParticipants;
            }
        }

        // Total price
        $totalPrice = $totalPriceParticipants + $guardiansCost + $teachersCost + $attractionTotal;

        // DP 30%
        $dp = round($totalPrice * 0.3);

        $userId = session()->get('user_id');

        $orderData = [
            'user_id' => $userId,
            'visit_date' => $visitDate,
            'school_name' => $this->request->getPost('school_name'),
            'booker_name' => $this->request->getPost('booker_name'),
            'phone' => $this->request->getPost('phone'),
            'num_participants' => $numParticipants,
            'num_guardians' => $numGuardians,
            'num_teachers' => $numTeachers,
            'package_id' => $packageId,
            'total_price' => $totalPrice,
            'dp_amount' => $dp,
            'payment_status' => 'pending',
            'order_status' => 'pending',
        ];

        // SIMPAN KE DATABASE
        if (!$this->orderModel->insert($orderData)) {
            return redirect()->back()->with('error', 'Gagal menyimpan pesanan');
        }

        $orderId = $this->orderModel->insertID();
        if (!$orderId) {
            return redirect()->back()->with('error', 'Gagal menyimpan pesanan');
        }

        if (!empty($selectedAttractions)) {
            foreach ($selectedAttractions as $attraction) {
                $this->orderAttractionModel->insert([
                    'order_id' => $orderId,
                    'attraction_id' => $attraction['id'],
                    'price_at_booking' => $attraction['price'],
                    'quantity' => $numParticipants,
                ]);
            }
        }

        // REDIRECT KE HALAMAN PAYMENT
        return redirect()->to('/customer/order/' . $orderId . '/payment')
            ->with('success', 'Pesanan berhasil dibuat. Silakan lanjutkan pembayaran.');
    }
    /**
     * Halaman pembayaran dengan Midtrans Snap
     */
    public function paymentPage($orderId)
    {
        $order = $this->orderModel->getOrderDetail($orderId);

        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Cek ownership
        if ($order['user_id'] != session()->get('user_id')) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $paymentType = $order['payment_status'] === 'dp_paid' ? 'final' : 'dp';

        $dpAmount = (int)$order['dp_amount'];
        $remainingAmount = max(0, (int)$order['total_price'] - $dpAmount);
        $paymentAmount = $paymentType === 'final' ? $remainingAmount : $dpAmount;
        $snapToken = null;

        // REUSE token jika sudah pernah dibuat untuk order + tipe yang sama (menghindari error order_id duplikat di Midtrans)
        if ($order['payment_status'] !== 'paid') {
            $targetAmount = (int)$paymentAmount;
            $lastLog = $this->paymentLogModel->getLastPaymentLog($orderId);

            if ($lastLog && isset($lastLog['status']) && in_array($lastLog['status'], ['pending', 'paid'], true)) {
                // Karena skema payment_log tidak punya kolom payment_type, gunakan heuristik amount:
                // - dp: jumlah yang dibayar = dp_amount
                // - final: jumlah yang dibayar = remainingAmount
                $lastAmount = isset($lastLog['amount']) ? (int)$lastLog['amount'] : null;
                if ($lastAmount === $targetAmount && !empty($lastLog['midtrans_snap_id'])) {
                    $snapToken = $lastLog['midtrans_snap_id'];
                }
            }

            if (!$snapToken) {
                helper('midtrans');
                try {
                    $BONUS_TEACHERS_PER = 75;
                    $BONUS_TEACHERS_COUNT = 5;
                    $bonusTeachers = floor($order['num_participants'] / $BONUS_TEACHERS_PER) * $BONUS_TEACHERS_COUNT;
                    $teachersPaid = max(0, $order['num_teachers'] - $bonusTeachers);

                    $orderData = [
                        'order_id' => $orderId,
                        'booker_name' => $order['booker_name'],
                        'email' => session()->get('user_email'),
                        'phone' => $order['phone'],
                        'total_price' => $targetAmount,
                        'package_id' => $order['package_id'],
                        'package_price' => (int)$order['package']['price'],
                        'num_participants' => $order['num_participants'],
                        'num_guardians' => $order['num_guardians'],
                        'num_teachers' => $order['num_teachers'],
                        'num_teachers_paid' => $teachersPaid,
                        'payment_type' => $paymentType,
                    ];

                    $snapToken = getMidtransSnapToken($orderId, $orderData, $paymentType);

                    if (!empty($snapToken)) {
                        $this->paymentLogModel->logPayment($orderId, (float)$targetAmount, $snapToken);
                    }
                } catch (\Exception $e) {
                    return redirect()->back()->with('error', 'Gagal generate token pembayaran: ' . $e->getMessage());
                }
            }
        }



        return view('customer/order/payment', [
            'order' => $order,
            'snapToken' => $snapToken,
            'paymentType' => $paymentType,
            'paymentAmount' => $paymentAmount,
            'remainingAmount' => $remainingAmount,
        ]);
    }

    /**
     * Upload bukti pembayaran
     */
    public function uploadPaymentProof($orderId)
    {
        $order = $this->orderModel->find($orderId);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Cek ownership
        if ($order['user_id'] !== session()->get('user_id')) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $file = $this->request->getFile('proof_payment');
        if (!$file || !$file->isValid() || $file->hasMoved()) {
            return redirect()->back()->with('error', 'File tidak valid');
        }

        $newName = $file->getRandomName();
        $file->move('uploads/payments', $newName);

        $data = [
            'proof_payment_image' => 'uploads/payments/' . $newName,
            'payment_status' => 'pending',
        ];
        log_message('debug', 'BEFORE UPDATE ' . json_encode($data));
        $updated = $this->orderModel->update($orderId, $data);
        log_message('debug', 'UPDATE RESULT=' . ($updated ? 'SUCCESS' : 'FAILED'));
        if (!$updated) {
            log_message('error', json_encode($this->orderModel->errors()));
        }
        $new = $this->orderModel->find($orderId);
        log_message('debug', json_encode($new));

        return redirect()->to('/customer/order/' . $orderId)->with('success', 'Bukti pembayaran berhasil diupload. Menunggu verifikasi admin.');

    }

    /**
     * Lihat detail order
     */
    public function orderDetail($orderId)
    {
        $order = $this->orderModel->getOrderDetail($orderId);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Cek ownership
        if ($order['user_id'] !== session()->get('user_id')) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = ['order' => $order];
        return view('customer/order/detail', $data);
    }

    /**
     * Download PDF bukti pemesanan
     */
    public function downloadPDF($orderId)
    {
        $order = $this->orderModel->getOrderDetail($orderId);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Cek ownership
        if ($order['user_id'] !== session()->get('user_id')) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Allow download only if payment is at least DP paid or fully paid
        $allowedPaymentStatuses = ['dp_paid', 'paid'];
        if (!in_array($order['payment_status'], $allowedPaymentStatuses, true)) {
            return redirect()->back()->with('error', 'Unduh Bukti Pemesanan hanya tersedia setelah DP terbayar (dp_paid) atau pelunasan (paid).');
        }


        // Generate PDF (Booking vs Payment)

        try {
            $htmlView = 'customer/order/pdf_booking';
            $filenamePrefix = 'Bukti-Booking';

            if (($order['payment_status'] ?? '') === 'paid') {
                $htmlView = 'customer/order/pdf_payment';
                $filenamePrefix = 'Kuitansi-Pelunasan';
            }

            $html = view($htmlView, ['order' => $order]);

            $dompdf = new \Dompdf\Dompdf();
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();

            $filename = $filenamePrefix . '-' . $order['school_name'] . '-' . $order['id'] . '.pdf';
            $dompdf->stream($filename, array("Attachment" => 1));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal generate PDF: ' . $e->getMessage());
        }

    }

    /**
     * Riwayat pesanan
     */
    public function orderHistory()
    {
        $userId = session()->get('user_id');
        $orders = $this->orderModel->getUserOrders($userId);

        $data = ['orders' => $orders];
        return view('customer/order/history', $data);
    }

    /**
     * Get Snap Token for Midtrans Payment
     */
    public function getSnapToken($orderId)
    {
        helper('midtrans');

        $order = $this->orderModel->getOrderDetail($orderId);
        if (!$order) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Pesanan tidak ditemukan'
            ]);
        }

        // Cek ownership
        if ($order['user_id'] !== session()->get('user_id')) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Akses ditolak'
            ]);
        }

        try {
            // Calculate teachers paid (with bonus)
            $BONUS_TEACHERS_PER = 75;
            $BONUS_TEACHERS_COUNT = 5;
            $bonusTeachers = floor($order['num_participants'] / $BONUS_TEACHERS_PER) * $BONUS_TEACHERS_COUNT;
            $teachersPaid = max(0, $order['num_teachers'] - $bonusTeachers);

            $orderData = [
                'order_id' => $orderId,
                'booker_name' => $order['booker_name'],
                'email' => session()->get('user_email'),
                'phone' => $order['phone'],
                'total_price' => (int)$order['total_price'],
                'package_id' => $order['package_id'],
                'package_price' => (int)$order['package']['price'],
                'num_participants' => $order['num_participants'],
                'num_guardians' => $order['num_guardians'],
                'num_teachers' => $order['num_teachers'],
                'num_teachers_paid' => $teachersPaid,
            ];

            // Tentukan payment type sesuai status order (konsisten dengan paymentPage)
            $paymentType = $order['payment_status'] === 'dp_paid' ? 'final' : 'dp';
            $targetAmount = $paymentType === 'final'
                ? max(0, (int)$order['total_price'] - (int)$order['dp_amount'])
                : (int)$order['dp_amount'];

            // Reuse token jika sudah pernah disimpan untuk amount yang sama
            $lastLog = $this->paymentLogModel->getLastPaymentLog($orderId);
            if ($lastLog && isset($lastLog['status']) && in_array($lastLog['status'], ['pending', 'paid'], true)) {
                $lastAmount = isset($lastLog['amount']) ? (int)$lastLog['amount'] : null;
                if ($lastAmount === (int)$targetAmount && !empty($lastLog['midtrans_snap_id'])) {
                    return $this->response->setJSON([
                        'success' => true,
                        'snap_token' => $lastLog['midtrans_snap_id']
                    ]);
                }
            }

            $orderData['total_price'] = (int)$targetAmount;
            $snapToken = getMidtransSnapToken($orderId, $orderData, $paymentType);

            if (!empty($snapToken)) {
                $this->paymentLogModel->logPayment($orderId, (float)$targetAmount, $snapToken);
            }

            return $this->response->setJSON([
                'success' => true,
                'snap_token' => $snapToken
            ]);

        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal mendapatkan token: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Process Payment (Midtrans Callback)
     */
    public function processPayment($orderId)
    {
        $order = $this->orderModel->find($orderId);
        if (!$order) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Cek ownership
        if ($order['user_id'] !== session()->get('user_id')) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        helper('midtrans');

        try {
            $paymentType = $order['payment_status'] === 'dp_paid' ? 'final' : 'dp';
            $status = verifyMidtransPayment($orderId, $paymentType);

            if ($status->transaction_status == 'capture' || $status->transaction_status == 'settlement') {
                $currentStatus = $order['payment_status'];
                $newStatus = $currentStatus === 'dp_paid' ? 'paid' : 'dp_paid';

                log_message('debug', 'Customer processPayment: sebelum update order ' . $orderId . ' status=' . $currentStatus);
                $updated = $this->orderModel->update($orderId, [
                    'payment_status' => $newStatus,
                    'order_status' => 'confirmed',
                ]);
                if ($updated) {
                    $freshOrder = $this->orderModel->find($orderId);
                    log_message('debug', 'Customer processPayment: berhasil update order ' . $orderId);
                    log_message('debug', 'Customer processPayment: order terbaru ' . json_encode($freshOrder));
                } else {
                    log_message('error', 'Customer processPayment: gagal update order ' . $orderId . ' errors=' . json_encode($this->orderModel->errors()));
                }

                return redirect()->to('/customer/order/' . $orderId)
                    ->with('success', 'Pembayaran berhasil! Pesanan Anda telah dikonfirmasi.');
            } elseif ($status->transaction_status == 'pending') {
                return redirect()->to('/customer/order/' . $orderId)
                    ->with('info', 'Pembayaran sedang diproses...');
            } elseif (in_array($status->transaction_status, ['deny', 'cancel', 'expire'])) {
                return redirect()->to('/customer/order/' . $orderId)
                    ->with('error', 'Pembayaran ditolak atau kadaluarsa.');
            }
        } catch (\Exception $e) {
            return redirect()->to('/customer/order/' . $orderId)
                ->with('error', 'Error verifikasi pembayaran: ' . $e->getMessage());
        }
    }

}
