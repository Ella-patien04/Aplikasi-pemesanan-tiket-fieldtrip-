<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        if (!session()->has('user_id')) {
            return redirect()->to('/auth/login');
        }

        $role = session()->get('user_role');

        // Route ke dashboard sesuai role
        switch ($role) {
            case 'admin':
                return redirect()->to('/admin/dashboard');
            case 'customer':
                return redirect()->to('/customer/dashboard');
            case 'pengelola':
                return redirect()->to('/pengelola/dashboard');
            case 'owner':
                return redirect()->to('/owner/dashboard');
            default:
                return redirect()->to('/auth/logout');
        }
    }
}
