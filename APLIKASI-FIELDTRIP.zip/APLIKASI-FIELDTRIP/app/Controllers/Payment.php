<?php

namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\PaymentLogModel;

class Payment extends BaseController
{
    protected $orderModel;
    protected $paymentLogModel;

    /**
     * Endpoint untuk dashboard realtime (AJAX polling)
     */
    public function status($id)
    {
        $order = $this->orderModel->find((int)$id);
        if (!$order) {
            return $this->response->setStatusCode(404)->setJSON(['order_id' => (int)$id, 'status' => 'not_found']);
        }

        $paymentStatus = (string)($order['payment_status'] ?? 'pending');
        $normalized = in_array($paymentStatus, ['paid', 'dp_paid'], true) ? 'paid' : 'pending';

        return $this->response->setJSON([
            'order_id' => (int)$id,
            'status' => $normalized,
            'payment_status' => $paymentStatus,
        ]);
    }


    public function __construct()
    {
        $this->orderModel = new OrderModel();
        $this->paymentLogModel = new PaymentLogModel();
    }

    /**
     * Handle Midtrans Notification (Webhook)
     */
    public function notification()
    {
        $method = strtoupper($this->request->getMethod());
        $uri = (string) $this->request->getUri()->getPath();

        // Read raw webhook body
        $input = file_get_contents('php://input');

        // Safe decode JSON body (Midtrans typically sends JSON)
        $notificationPayload = null;
        $jsonError = null;
        if (!empty($input)) {
            $notificationPayload = json_decode($input, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $jsonError = json_last_error_msg();
                $notificationPayload = null;
            }
        }

        log_message('debug', 'Midtrans notification hit');
        log_message('debug', 'Method=' . $method . ' URI=' . $uri);
        log_message('debug', 'Midtrans notification body length=' . strlen((string) $input));
        if (is_string($input) && $input !== '') {
            log_message('debug', 'Midtrans notification raw body=' . (strlen($input) > 5000 ? substr($input, 0, 5000) . '...[truncated]' : $input));
        }
        if ($jsonError) {
            log_message('error', 'Midtrans notification JSON decode error: ' . $jsonError);
            // Fallback parsing for malformed POST bodies that are not valid JSON.
            if (is_string($input) && trim($input) !== '') {
                $parsed = [];
                $raw = trim($input);
                $raw = trim($raw, "{} \t\n\r");
                $pairs = preg_split('/\s*,\s*/', $raw);
                foreach ($pairs as $pair) {
                    if (strpos($pair, ':') !== false) {
                        [$key, $value] = explode(':', $pair, 2);
                    } elseif (strpos($pair, '=') !== false) {
                        [$key, $value] = explode('=', $pair, 2);
                    } else {
                        continue;
                    }
                    $key = trim($key, " \t\n\r\"'");
                    $value = trim($value, " \t\n\r\"'");
                    if ($key !== '') {
                        $parsed[$key] = $value;
                    }
                }
                if (!empty($parsed)) {
                    $notificationPayload = $parsed;
                    $jsonError = null;
                    log_message('debug', 'Midtrans fallback payload keys=' . implode(',', array_keys($parsed)));
                }
            }
        }
        if ($jsonError) {
            return $this->response->setStatusCode(200)->setJSON(['status' => 'ok', 'note' => 'invalid_json']);
        }
        if ($method === 'POST' && (empty($input) || $notificationPayload === null)) {
            log_message('error', 'Midtrans notification invalid or empty payload');
            return $this->response->setStatusCode(200)->setJSON(['status' => 'ok', 'note' => 'invalid_payload']);
        }
        if (!empty($notificationPayload) && is_array($notificationPayload)) {
            log_message('debug', 'Midtrans notification payload keys=' . implode(',', array_keys($notificationPayload)));
        }

        // Fallback untuk kasus routing dibypass / test via GET.
        // Webhook sebenarnya harus POST dari Midtrans.
        if ($method === 'GET') {
            // GET hanya untuk debugging/test. Midtrans seharusnya POST.
            return $this->response->setStatusCode(200)->setJSON(['status' => 'ok', 'note' => 'GET fallback']);
        }

        // Selalu balas 200 untuk webhook agar Midtrans berhenti retry ketika endpoint sukses di-routing.
        // (Midtrans tetap akan mengirim data; kita yang memutuskan apakah update DB berhasil.)
        $responseOk = function (string $note = 'ok') {
            return $this->response->setStatusCode(200)->setJSON(['status' => 'ok', 'note' => $note]);
        };

        helper('midtrans');

        try {
            $notificationPayloadArr = is_array($notificationPayload) ? $notificationPayload : [];
            log_message('debug', 'Midtrans parsed payload type=' . gettype($notificationPayload));
            if (is_array($notificationPayloadArr)) {
                log_message('debug', 'Midtrans payload keys=' . implode(',', array_keys($notificationPayloadArr)));
            }

            $notification = handleMidtransNotification($notificationPayloadArr);

            $orderId = $notification['order_id'] ?? null;
            $transactionStatus = $notification['transaction_status'] ?? null;
            $fraudStatus = $notification['fraud_status'] ?? null;
            $paymentType = $notification['payment_type'] ?? null;

            log_message('debug', 'Webhook extracted: order_id=' . (string)$orderId . ', transaction_status=' . (string)$transactionStatus . ', fraud_status=' . (string)$fraudStatus . ', payment_type=' . (string)$paymentType);

            // Logging untuk sinkronisasi masalah pending -> paid
            log_message('debug', 'Webhook parsed: order_id=' . $orderId . ', status=' . $transactionStatus . ', fraud=' . $fraudStatus . ', payment_type=' . $paymentType);

            $order = $this->orderModel->find($orderId);
            if (!$order) {
                log_message('error', 'Order tidak ditemukan: ' . (string)$orderId);
                // Agar Midtrans tidak mengulang webhook untuk kasus orderId tidak valid/ belum tersimpan
                return $responseOk('order_not_found');
            }

            log_message('debug', 'Order ditemukan: ' . (string)$orderId);
            log_message('debug', 'Sebelum update order: ' . json_encode([
                'id' => $orderId,
                'payment_status' => $order['payment_status'] ?? null,
                'order_status' => $order['order_status'] ?? null,
            ]));

            if ($transactionStatus == 'capture' || $transactionStatus == 'settlement') {
                if ($fraudStatus == 'challenge') {
                    // Need manual review
                    $updated = $this->orderModel->update($orderId, [
                        'payment_status' => 'pending',
                    ]);
                    if ($updated) {
                        $freshOrder = $this->orderModel->find($orderId);
                        log_message('debug', 'Database berhasil diupdate');
                        log_message('debug', 'Order terbaru setelah update: ' . json_encode($freshOrder));
                    } else {
                        log_message('error', json_encode($this->orderModel->errors()));
                    }
                } else if ($fraudStatus == 'accept') {
                    // Success
                    $newPaymentStatus = 'paid';
                    if (($notification['payment_type'] ?? null) === 'dp') {
                        $newPaymentStatus = 'dp_paid';
                    }

                    $updated = $this->orderModel->update($orderId, [
                        'payment_status' => $newPaymentStatus,
                        'order_status' => 'confirmed',
                    ]);
                    if ($updated) {
                        $freshOrder = $this->orderModel->find($orderId);
                        log_message('debug', 'Database berhasil diupdate');
                        log_message('debug', 'Order terbaru setelah update: ' . json_encode($freshOrder));
                    } else {
                        log_message('error', json_encode($this->orderModel->errors()));
                    }

                    $this->paymentLogModel->logPaymentSuccess(
                        $orderId,
                        $notification['gross_amount'] ?? null,
                        $notification['midtrans_order_id'] ?? null,
                        $notification['payment_method'] ?? null
                    );

                    // Simpan flag untuk ditampilkan di UI (oleh halaman admin/customer setelah redirect berikutnya)
                    // Set flashdata untuk notifikasi di UI setelah redirect berikutnya.
                    if (function_exists('setPaymentFlashByStatus')) {
                        setPaymentFlashByStatus($newPaymentStatus);
                    }
                }
            } else if ($transactionStatus == 'pending') {
                if (in_array($order['payment_status'], ['paid', 'dp_paid'], true)) {
                    log_message('debug', 'Skipping pending webhook because order already has final payment_status=' . $order['payment_status']);
                } else {
                    $updated = $this->orderModel->update($orderId, [
                        'payment_status' => 'pending',
                    ]);
                    if ($updated) {
                        $freshOrder = $this->orderModel->find($orderId);
                        log_message('debug', 'Database berhasil diupdate');
                        log_message('debug', 'Order terbaru setelah update: ' . json_encode($freshOrder));
                    } else {
                        log_message('error', json_encode($this->orderModel->errors()));
                    }
                }
            } else if ($transactionStatus == 'deny') {
                $updated = $this->orderModel->update($orderId, [
                    'payment_status' => 'failed',
                ]);
                if ($updated) {
                    log_message('debug', 'Database berhasil diupdate');
                } else {
                    log_message('error', json_encode($this->orderModel->errors()));
                }
            } else if ($transactionStatus == 'cancel' || $transactionStatus == 'expire') {
                $updated = $this->orderModel->update($orderId, [
                    'payment_status' => 'cancelled',
                ]);
                if ($updated) {
                    $freshOrder = $this->orderModel->find($orderId);
                    log_message('debug', 'Database berhasil diupdate');
                    log_message('debug', 'Order terbaru setelah update: ' . json_encode($freshOrder));
                } else {
                    log_message('error', json_encode($this->orderModel->errors()));
                }
            } else if ($transactionStatus == 'refund') {
                $updated = $this->orderModel->update($orderId, [
                    'payment_status' => 'refunded',
                ]);
                if ($updated) {
                    $freshOrder = $this->orderModel->find($orderId);
                    log_message('debug', 'Database berhasil diupdate');
                    log_message('debug', 'Order terbaru setelah update: ' . json_encode($freshOrder));
                } else {
                    log_message('error', json_encode($this->orderModel->errors()));
                }
            }

            return $this->response->setJSON(['status' => 'ok']);
        } catch (\Throwable $e) {
            log_message('error', 'Midtrans Notification Error: ' . $e->getMessage());
            // Agar Midtrans tidak retry berulang pada error parsing/DB sementara
            return $this->response->setStatusCode(200)->setJSON(['status' => 'ok', 'note' => 'exception']);
        }
    }

    /**
     * Finish page (optional - redirected from Midtrans)
     */
    public function finish()
    {
        $orderId = $this->request->getGet('order_id');

        if (!$orderId) {
            return redirect()->to('/customer/dashboard');
        }

        $order = $this->orderModel->find($orderId);
        if (!$order || $order['user_id'] != session()->get('user_id')) {
            return redirect()->to('/customer/dashboard');
        }

        $data = ['order' => $order];
        return view('payment/finish', $data);
    }

    /**
     * Unfinish page (optional - user closes payment)
     */
    public function unfinish()
    {
        $orderId = $this->request->getGet('order_id');

        if (!$orderId) {
            return redirect()->to('/customer/dashboard');
        }

        return redirect()->to('/customer/order/' . $orderId)
            ->with('info', 'Pembayaran dibatalkan. Silakan coba lagi.');
    }

    /**
     * Error page (optional - payment error)
     */
    public function error()
    {
        $orderId = $this->request->getGet('order_id');

        if (!$orderId) {
            return redirect()->to('/customer/dashboard');
        }

        return redirect()->to('/customer/order/' . $orderId)
            ->with('error', 'Terjadi kesalahan pada pembayaran.');
    }
}

