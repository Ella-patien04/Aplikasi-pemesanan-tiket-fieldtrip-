<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateOrdersTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'visit_date' => [
                'type' => 'DATE',
                'null' => false,
            ],
            'school_name' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'booker_name' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'phone' => [
                'type' => 'VARCHAR',
                'constraint' => 15,
            ],
            'num_participants' => [
                'type' => 'INT',
                'constraint' => 11,
            ],
            'num_guardians' => [
                'type' => 'INT',
                'constraint' => 11,
            ],
            'package_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'total_price' => [
                'type' => 'DECIMAL',
                'constraint' => [12, 2],
            ],
            'dp_amount' => [
                'type' => 'DECIMAL',
                'constraint' => [12, 2],
            ],
            'payment_status' => [
                'type' => 'ENUM',
                'constraint' => ['pending', 'dp_paid', 'paid', 'cancelled'],
                'default' => 'pending',
            ],
            'order_status' => [
                'type' => 'ENUM',
                'constraint' => ['pending', 'confirmed', 'cancelled'],
                'default' => 'pending',
            ],
            'confirmation_date' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'proof_payment_image' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
            ],
            'verified_by' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
            ],
            'verified_date' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'pdf_token' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', false, true);
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        // orders now track visit_date instead of referring to schedules table
        $this->forge->addForeignKey('package_id', 'packages', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('verified_by', 'users', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('orders');
    }

    public function down()
    {
        $this->forge->dropTable('orders');
    }
}
