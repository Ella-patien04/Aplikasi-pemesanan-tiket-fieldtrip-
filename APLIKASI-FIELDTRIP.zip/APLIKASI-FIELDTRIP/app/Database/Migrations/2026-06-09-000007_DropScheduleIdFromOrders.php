<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class DropScheduleIdFromOrders extends Migration
{
    public function up()
    {
        // Safety check: ensure there are no orders left without visit_date
        $db = \Config\Database::connect();
        $row = $db->query("SELECT COUNT(*) as cnt FROM orders WHERE (visit_date IS NULL OR visit_date = '') AND schedule_id IS NOT NULL")->getRow();
        $remaining = (int) ($row->cnt ?? 0);
        if ($remaining > 0) {
            throw new \Exception("Cannot drop schedule_id: $remaining orders still lack visit_date. Run migration to populate visit_date first.");
        }

        // Safe to drop column
        $forge = $this->forge;
        if ($forge->hasColumn('orders', 'schedule_id')) {
            $forge->dropColumn('orders', 'schedule_id');
        }
    }

    public function down()
    {
        // Recreate schedule_id as nullable INT (no FK restored automatically)
        $fields = [
            'schedule_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
            ],
        ];
        $this->forge->addColumn('orders', $fields);
    }
}
