<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddOtpResetColumns extends Migration
{
    public function up()
    {
        // Add columns if they do not exist
        $fields = [
            'otp_code' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
                'null' => true,
                'default' => null,
            ],
            'otp_expired_at' => [
                'type' => 'DATETIME',
                'null' => true,
                'default' => null,
            ],
            'reset_token' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
                'default' => null,
            ],
            'reset_token_expired_at' => [
                'type' => 'DATETIME',
                'null' => true,
                'default' => null,
            ],
        ];

        $this->forge->addColumn('users', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('users', [
            'otp_code',
            'otp_expired_at',
            'reset_token',
            'reset_token_expired_at',
        ]);
    }
}
