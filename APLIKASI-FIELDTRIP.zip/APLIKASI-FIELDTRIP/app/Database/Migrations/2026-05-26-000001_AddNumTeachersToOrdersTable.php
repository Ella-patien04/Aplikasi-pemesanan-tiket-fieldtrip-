<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddNumTeachersToOrdersTable extends Migration
{
    public function up()
    {
        $fields = [
            'num_teachers' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
        ];

        $this->forge->addColumn('orders', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('orders', 'num_teachers');
    }
}
