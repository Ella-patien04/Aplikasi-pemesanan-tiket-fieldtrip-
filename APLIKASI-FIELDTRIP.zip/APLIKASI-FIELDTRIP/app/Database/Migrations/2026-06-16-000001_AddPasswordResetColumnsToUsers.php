<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddPasswordResetColumnsToUsers extends Migration
{
    public function up()
    {
        $fields = [
            'reset_token' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
            ],
            'otp_code' => [
                'type' => 'VARCHAR',
                'constraint' => 6,
                'null' => true,
            ],
            'otp_expired_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ];

        $this->forge->addColumn('users', $fields);
    }

    public function down()
    {
        $fields = ['reset_token', 'otp_code', 'otp_expired_at'];
        $this->forge->dropColumn('users', $fields);
    }
}
