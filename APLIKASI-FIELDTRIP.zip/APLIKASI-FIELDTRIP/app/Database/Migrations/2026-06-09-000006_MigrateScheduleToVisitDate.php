<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class MigrateScheduleToVisitDate extends Migration
{
    public function up()
    {
        // Add visit_date column (nullable to avoid blocking existing data)
        $fields = [
            'visit_date' => [
                'type' => 'DATE',
                'null' => true,
                'after' => 'schedule_id'
            ],
        ];
        $this->forge->addColumn('orders', $fields);

        // Copy dates from schedules if schedule_id present
        $db = \Config\Database::connect();
        $db->query("UPDATE orders o JOIN schedules s ON o.schedule_id = s.id SET o.visit_date = s.date WHERE o.schedule_id IS NOT NULL");
    }

    public function down()
    {
        // Remove visit_date column
        if ($this->forge->dropColumn('orders', 'visit_date')) {
            // dropped
        }
    }
}
