<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateOrdersTableForPaymentExpireAndFieldTripStatus extends Migration
{
    public function up()
    {
        // Tambah kolom payment_expired_at untuk auto-cancel
        $fields = [
            'payment_expired_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ];
        $this->forge->addColumn('orders', $fields);

        // Update order_status ENUM untuk support in_progress dan completed
        $this->db->query("ALTER TABLE orders MODIFY order_status ENUM('pending', 'confirmed', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending'");
    }

    public function down()
    {
        // Revert order_status ENUM
        $this->db->query("ALTER TABLE orders MODIFY order_status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending'");
        
        // Hapus kolom payment_expired_at
        $this->forge->dropColumn('orders', 'payment_expired_at');
    }
}
