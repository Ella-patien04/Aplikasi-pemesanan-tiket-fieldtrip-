<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateOrderAttractionItemsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'order_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'attraction_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'price_at_booking' => [
                'type' => 'DECIMAL',
                'constraint' => [10, 2],
            ],
            'quantity' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 1,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', false, true);
        $this->forge->addForeignKey('order_id', 'orders', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('attraction_id', 'attractions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('order_attraction_items');
    }

    public function down()
    {
        $this->forge->dropTable('order_attraction_items');
    }
}
