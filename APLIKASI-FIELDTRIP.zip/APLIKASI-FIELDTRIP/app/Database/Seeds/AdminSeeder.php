<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AdminSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'name'       => 'Administrator',
            'email'      => 'admin@gmail.com',
            'password'   => password_hash('123456', PASSWORD_DEFAULT),
            'phone'      => '081234567890',
            'role'       => 'admin',
            'is_active'  => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $builder = $this->db->table('users');

        // Cek apakah admin sudah ada
        $existing = $builder->where('email', $data['email'])->get()->getRowArray();

        if ($existing) {
            // Update jika sudah ada
            $builder->where('email', $data['email'])->update($data);
            echo "Admin account updated: " . $data['email'] . "\n";
        } else {
            // Insert jika belum ada
            $builder->insert($data);
            echo "Admin account created: " . $data['email'] . "\n";
        }

        echo "Credentials:\n";
        echo "  Email: " . $data['email'] . "\n";
        echo "  Password: 123456\n";
    }
}
