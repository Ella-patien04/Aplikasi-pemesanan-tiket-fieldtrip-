<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = [
            [
                'name'       => 'Admin Fieldtrip',
                'email'      => 'admin@example.com',
                'password'   => password_hash('Admin1234', PASSWORD_DEFAULT),
                'phone'      => '081234567890',
                'role'       => 'admin',
                'is_active'  => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name'       => 'Pengelola Fieldtrip',
                'email'      => 'pengelola@example.com',
                'password'   => password_hash('Pengelola123', PASSWORD_DEFAULT),
                'phone'      => '081234567891',
                'role'       => 'pengelola',
                'is_active'  => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name'       => 'Owner Fieldtrip',
                'email'      => 'owner@example.com',
                'password'   => password_hash('Owner1234', PASSWORD_DEFAULT),
                'phone'      => '081234567892',
                'role'       => 'owner',
                'is_active'  => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
        ];

        $builder = $this->db->table('users');

        foreach ($users as $user) {
            $existing = $builder->where('email', $user['email'])->get()->getRowArray();
            if ($existing) {
                $builder->where('email', $user['email'])->update($user);
            } else {
                $builder->insert($user);
            }
        }
    }
}
