<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h1 class="h3">Statistik</h1>
        <p class="text-muted">Statistik ringkas pendapatan dan pemesanan saat ini.</p>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card p-3">
            <div class="text-uppercase text-muted small">Total Pendapatan</div>
            <div class="h4 mt-2">Rp <?= number_format($total_revenue, 0, ',', '.') ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-3">
            <div class="text-uppercase text-muted small">Total Pesanan</div>
            <div class="h4 mt-2"><?= number_format($total_orders) ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-3">
            <div class="text-uppercase text-muted small">Rata-rata Nilai Pesanan</div>
            <div class="h4 mt-2">Rp <?= number_format($average_order_value, 0, ',', '.') ?></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <p>Data statistik ini adalah ringkasan sederhana. Tambahkan grafik atau laporan lanjutan sesuai kebutuhan.</p>
    </div>
</div>
<?= $this->endSection() ?>
