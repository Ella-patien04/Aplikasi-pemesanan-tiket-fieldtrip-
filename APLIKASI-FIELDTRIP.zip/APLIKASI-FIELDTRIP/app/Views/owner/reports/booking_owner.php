<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<?php
  // Expected variables:
  // $dpOrders, $paidOrders, $startDate, $endDate, $activeTab

  $startDate = $startDate ?? null;
  $endDate = $endDate ?? null;
  $activeTab = $activeTab ?? 'dp';

  $printQuery = http_build_query(array_filter([
      'start_date' => $startDate,
      'end_date' => $endDate,
  ]));

  $pageTitle = 'Laporan Pemesanan & Pendapatan Owner';
?>

<div class="container-fluid py-4">
  <div class="row mb-3">
    <div class="col-md-12">
      <h1 class="h3 mb-1"><?= esc($pageTitle) ?></h1>
      <p class="text-muted mb-0">Dipisah menjadi Laporan DP (dp_paid) dan Laporan Lunas (paid). Status pending tidak ditampilkan.</p>
    </div>
  </div>

  <div class="card shadow-sm border-0 mb-4">
    <div class="card-body">
      <form method="get" class="row g-2 align-items-end" action="<?= base_url('owner/reports/booking') ?>">
        <div class="col-md-4">
          <label class="form-label">Start Date</label>
          <input type="date" name="start_date" class="form-control" value="<?= esc($startDate) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">End Date</label>
          <input type="date" name="end_date" class="form-control" value="<?= esc($endDate) ?>">
        </div>
        <div class="col-md-4 d-flex gap-2 justify-content-md-end">
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-filter"></i> Terapkan
          </button>
        </div>
      </form>
    </div>
  </div>

  <ul class="nav nav-tabs" id="bookingOwnerTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <button
        class="nav-link <?= $activeTab === 'dp' ? 'active' : '' ?>"
        id="dp-tab"
        data-bs-toggle="tab"
        data-bs-target="#dp"
        type="button"
        role="tab"
        aria-controls="dp"
        aria-selected="<?= $activeTab === 'dp' ? 'true' : 'false' ?>"
      >
        Laporan DP (Uang Muka)
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button
        class="nav-link <?= $activeTab === 'paid' ? 'active' : '' ?>"
        id="paid-tab"
        data-bs-toggle="tab"
        data-bs-target="#paid"
        type="button"
        role="tab"
        aria-controls="paid"
        aria-selected="<?= $activeTab === 'paid' ? 'true' : 'false' ?>"
      >
        Laporan Lunas
      </button>
    </li>
  </ul>

  <div class="tab-content" id="bookingOwnerTabsContent">
    <!-- DP TAB -->
    <div class="tab-pane fade <?= $activeTab === 'dp' ? 'show active' : '' ?>" id="dp" role="tabpanel" aria-labelledby="dp-tab">
      <div class="table-responsive p-3">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>ID Pesanan</th>
              <th>Tanggal</th>
              <th>Nama Sekolah</th>
              <th>Nama Paket</th>
              <th>Total Biaya</th>
              <th>Nominal Terbayar (dp_amount)</th>
              <th>Sisa Tagihan</th>
              <th>Status Pembayaran</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($dpOrders)): ?>
              <?php foreach ($dpOrders as $o): ?>
                <tr>
                  <td><?= esc($o['id']) ?></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= esc($o['school_name']) ?></td>
                  <td><?= esc($o['package_name'] ?? 'N/A') ?></td>
                  <td>Rp <?= number_format((float)$o['total_price'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['dp_amount'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['sisa_tagihan'], 0, ',', '.') ?></td>
                  <td><span class="badge bg-primary">DP</span></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="8" class="text-center text-muted">Tidak ada data DP untuk periode ini.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- PAID TAB -->
    <div class="tab-pane fade <?= $activeTab === 'paid' ? 'show active' : '' ?>" id="paid" role="tabpanel" aria-labelledby="paid-tab">
      <div class="table-responsive p-3">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>ID Pesanan</th>
              <th>Tanggal</th>
              <th>Nama Sekolah</th>
              <th>Nama Paket</th>
              <th>Total Biaya</th>
              <th>Nominal Terbayar (dp_amount)</th>
              <th>Sisa Tagihan</th>
              <th>Status Pembayaran</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($paidOrders)): ?>
              <?php foreach ($paidOrders as $o): ?>
                <tr>
                  <td><?= esc($o['id']) ?></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= esc($o['school_name']) ?></td>
                  <td><?= esc($o['package_name'] ?? 'N/A') ?></td>
                  <td>Rp <?= number_format((float)$o['total_price'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['dp_amount'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['sisa_tagihan'], 0, ',', '.') ?></td>
                  <td><span class="badge bg-success">Lunas</span></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="8" class="text-center text-muted">Tidak ada data Lunas untuk periode ini.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<style>
  @media print {
    /* Bersihkan komponen UI saat cetak */
    .nav-tabs,
    .card-body > form,
    .btn,
    a,
    #bookingOwnerTabsTabsContent {
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    .nav-tabs { display: none !important; }
    .card { display: none !important; }

    /* Pastikan tabel tampil */
    table { width: 100% !important; }
    a { display: none !important; }
  }
</style>

<?= $this->endSection() ?>


