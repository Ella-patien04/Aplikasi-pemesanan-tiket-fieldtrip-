<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<?php
  // Same as booking_owner but force print-friendly look
  $startDate = $startDate ?? null;
  $endDate = $endDate ?? null;
  $activeTab = $activeTab ?? 'dp';
?>

<div class="container-fluid py-4">
  <div class="row mb-3">
    <div class="col-md-12">
      <h1 class="h3 mb-1">Laporan Pemesanan Owner</h1>
      <p class="text-muted mb-0">
        Rentang tanggal: 
        <strong><?= esc($startDate ?? '-') ?></strong> s/d <strong><?= esc($endDate ?? '-') ?></strong>
      </p>
    </div>
  </div>

  <ul class="nav nav-tabs" id="bookingOwnerTabsPrint" role="tablist">
    <li class="nav-item" role="presentation">
      <button
        class="nav-link <?= $activeTab === 'dp' ? 'active' : '' ?>"
        id="dp-tab-print"
        data-bs-toggle="tab"
        data-bs-target="#dp-print"
        type="button"
        role="tab"
        aria-controls="dp-print"
        aria-selected="<?= $activeTab === 'dp' ? 'true' : 'false' ?>"
      >
        Laporan DP (Uang Muka)
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button
        class="nav-link <?= $activeTab === 'paid' ? 'active' : '' ?>"
        id="paid-tab-print"
        data-bs-toggle="tab"
        data-bs-target="#paid-print"
        type="button"
        role="tab"
        aria-controls="paid-print"
        aria-selected="<?= $activeTab === 'paid' ? 'true' : 'false' ?>"
      >
        Laporan Lunas
      </button>
    </li>
  </ul>

  <div class="tab-content" id="bookingOwnerTabsPrintContent">
    <div class="tab-pane fade <?= $activeTab === 'dp' ? 'show active' : '' ?>" id="dp-print" role="tabpanel" aria-labelledby="dp-tab-print">
      <div class="table-responsive p-3">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>ID Pesanan</th>
              <th>Tanggal</th>
              <th>Nama Sekolah</th>
              <th>Nama Paket</th>
              <th>Total Biaya</th>
              <th>Nominal Terbayar (dp_amount)</th>
              <th>Sisa Tagihan</th>
              <th>Status Pembayaran</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($dpOrders)): ?>
              <?php foreach ($dpOrders as $o): ?>
                <tr>
                  <td><?= esc($o['id']) ?></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= esc($o['school_name']) ?></td>
                  <td><?= esc($o['package_name'] ?? 'N/A') ?></td>
                  <td>Rp <?= number_format((float)$o['total_price'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['dp_amount'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['sisa_tagihan'], 0, ',', '.') ?></td>
                  <td><span class="badge bg-primary">DP</span></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="8" class="text-center text-muted">Tidak ada data DP untuk periode ini.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="tab-pane fade <?= $activeTab === 'paid' ? 'show active' : '' ?>" id="paid-print" role="tabpanel" aria-labelledby="paid-tab-print">
      <div class="table-responsive p-3">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>ID Pesanan</th>
              <th>Tanggal</th>
              <th>Nama Sekolah</th>
              <th>Nama Paket</th>
              <th>Total Biaya</th>
              <th>Nominal Terbayar (dp_amount)</th>
              <th>Sisa Tagihan</th>
              <th>Status Pembayaran</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($paidOrders)): ?>
              <?php foreach ($paidOrders as $o): ?>
                <tr>
                  <td><?= esc($o['id']) ?></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= esc($o['school_name']) ?></td>
                  <td><?= esc($o['package_name'] ?? 'N/A') ?></td>
                  <td>Rp <?= number_format((float)$o['total_price'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['dp_amount'], 0, ',', '.') ?></td>
                  <td>Rp <?= number_format((float)$o['sisa_tagihan'], 0, ',', '.') ?></td>
                  <td><span class="badge bg-success">Lunas</span></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="8" class="text-center text-muted">Tidak ada data Lunas untuk periode ini.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<style>
  @media print {
    /* Hide sidebar/navbar/buttons */
    .nav-tabs,
    .card-body > form,
    .btn,
    a,
    nav.navbar,
    .sidebar,
    .offcanvas,
    footer {
      display: none !important;
    }

    /* Ensure tables render */
    table { width: 100% !important; }
    .container-fluid { padding: 0 !important; }
  }
</style>

<?= $this->endSection() ?>

