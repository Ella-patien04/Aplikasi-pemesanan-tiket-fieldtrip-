<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3">Laporan Penjualan</h1>
            <p class="text-muted">Laporan pendapatan penjualan fieldtrip per bulan/tahun.</p>
        </div>
    </div>

    <!-- Filter -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Bulan</label>
                    <select name="month" class="form-select">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $filter_month == $m ? 'selected' : '' ?>>
                                <?= date('F', mktime(0,0,0,$m,1)) ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tahun</label>
                    <select name="year" class="form-select">
                        <?php foreach ($years as $y): ?>
                            <option value="<?= $y ?>" <?= $filter_year == $y ? 'selected' : '' ?>>
                                <?= $y ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">&nbsp;</label><br>
                    <button class="btn btn-primary">Filter</button>
                    <a id="download-report-pdf" href="<?= base_url('owner/reports/sales/download-pdf?month=' . $filter_month . '&year=' . $filter_year) ?>" class="btn btn-warning">
                        <i class="fas fa-download"></i> Download PDF
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Summary -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <h6 class="text-muted">Total Pendapatan</h6>
                    <h2 class="text-success">Rp <?= number_format($total_revenue, 0, ',', '.') ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <h6 class="text-muted">Total Pesanan</h6>
                    <h2><?= $total_orders ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Sekolah</th>
                        <th>Paket</th>
                        <th>Peserta</th>
                        <th>Total Harga</th>
                        <th>Pembayaran</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($orders)): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= esc($order['school_name']) ?></td>
                                <td><?= esc($order['package']['name'] ?? 'N/A') ?></td>
                                <td><?= $order['num_participants'] ?></td>
                                <td>Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                <td>
                                    <span class="badge bg-<?= in_array($order['payment_status'], ['paid', 'dp_paid']) ? 'success' : 'warning' ?>">
                                        <?= ucfirst(str_replace('_', ' ', $order['payment_status'])) ?>
                                    </span>
                                </td>
                                <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">Tidak ada pesanan untuk periode ini.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?php $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('download-report-pdf');
    if (!btn) return;

    btn.addEventListener('click', async function (e) {
        e.preventDefault();
        const url = this.href;
        try {
            const resp = await fetch(url, { method: 'GET', credentials: 'same-origin' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const blob = await resp.blob();
            // Try to determine filename from Content-Disposition
            const cd = resp.headers.get('Content-Disposition') || '';
            let filename = 'Laporan_Pendapatan.pdf';
            const match = /filename\s*=\s*"?([^";]+)/i.exec(cd);
            if (match && match[1]) filename = match[1].replace(/"/g, '');

            const link = document.createElement('a');
            const urlObj = window.URL.createObjectURL(blob);
            link.href = urlObj;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(urlObj);
        } catch (err) {
            console.error('Download failed', err);
            // Fallback: navigate to URL (may open preview)
            window.location.href = url;
        }
    });
});
</script>
<?php $this->endSection() ?>
