<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<?php
  // Expected variables from controller:
  // $total_revenue, $total_orders, $current_month, $current_year
  // $packageSalesCounts (array)
  // $monthlyRevenue (array[1..12])

  $packageSalesCounts = $packageSalesCounts ?? [];
  $monthlyRevenue = $monthlyRevenue ?? array_fill(1, 12, 0);

  // Chart data (Pie/Doughnut)
  $packageLabels = array_keys($packageSalesCounts);
  $packageValues = array_values($packageSalesCounts);

  // 3 colors kontras
  $colors = [
    '#2563eb', // blue
    '#16a34a', // green
    '#f97316', // orange
    '#db2777', // fallback/purple
  ];

  $bgColors = [];
  foreach ($packageValues as $i => $_v) {
    $bgColors[] = $colors[$i % count($colors)];
  }

  // MonthlyRevenue Line chart (year running)
  $labelsMonth = [];
  for ($m = 1; $m <= 12; $m++) {
    $labelsMonth[] = date('M', mktime(0, 0, 0, $m, 1));
  }

  // Encode to JS
  $jsPackageLabels = json_encode($packageLabels, JSON_UNESCAPED_UNICODE);
  $jsPackageValues = json_encode($packageValues, JSON_NUMERIC_CHECK);
  $jsBgColors = json_encode($bgColors, JSON_UNESCAPED_UNICODE);
  $jsMonthly = json_encode(array_values($monthlyRevenue), JSON_NUMERIC_CHECK); // 0..11
?>

<div class="container-fluid">
  <div class="row mb-4">
    <div class="col-md-12">
      <h1 class="h3 d-inline">Dashboard Owner</h1>
      <div class="float-end">
        <a href="<?= base_url('auth/logout') ?>" class="btn btn-sm btn-danger">Logout</a>
      </div>
    </div>
  </div>

  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h6>Pendapatan Bulan Ini</h6>
          <h2>Rp <?= number_format($total_revenue ?? 0, 0, ',', '.') ?></h2>
          <small class="text-muted"><?= date('F', mktime(0,0,0, $current_month ?? date('n'), 1)) ?> <?= $current_year ?? date('Y') ?></small>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Laporan Owner</h5>
          <p class="card-text">DP (dp_paid) & Lunas (paid).</p>
          <a href="<?= base_url('owner/reports/booking') ?>" class="btn btn-primary btn-sm">Lihat Laporan</a>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-4 mb-4">
    <div class="col-lg-5">
      <div class="card shadow-sm border-0 h-100">
        <div class="card-body">
          <h5 class="mb-3">Penjualan Paket (DP & Lunas)</h5>
          <div style="max-width: 420px; margin: 0 auto;">
            <canvas id="packageSalesChart"></canvas>
          </div>
          <div class="text-muted small mt-3">
            Menghitung total kemunculan nama paket dari transaksi sukses (dp_paid & paid).
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-7">
      <div class="card shadow-sm border-0 h-100">
        <div class="card-body">
          <h5 class="mb-3">Pendapatan Bulanan (Tahun Berjalan)</h5>
          <canvas id="monthlyRevenueChart" height="120"></canvas>
          <div class="text-muted small mt-3">
            Penjumlahan <strong>dp_amount</strong> untuk tiap bulan dari transaksi sukses (dp_paid & paid).
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<script>
  (function () {
    const packageLabels = <?= $jsPackageLabels ?>;
    const packageValues = <?= $jsPackageValues ?>;
    const packageColors = <?= $jsBgColors ?>;

    const monthlyRevenue = <?= $jsMonthly ?>; // 0..11

    const packageCtx = document.getElementById('packageSalesChart');
    if (packageCtx) {
      new Chart(packageCtx, {
        type: 'doughnut',
        data: {
          labels: packageLabels,
          datasets: [{
            data: packageValues,
            backgroundColor: packageColors,
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { position: 'bottom' },
            tooltip: { callbacks: {
              label: function(context) {
                const label = context.label || '';
                const value = context.parsed || 0;
                return label + ': ' + value;
              }
            }}
          }
        }
      });
    }

    const monthlyCtx = document.getElementById('monthlyRevenueChart');
    if (monthlyCtx) {
      new Chart(monthlyCtx, {
        type: 'line',
        data: {
          labels: <?= json_encode($labelsMonth, JSON_UNESCAPED_UNICODE) ?>,
          datasets: [{
            label: 'Pendapatan',
            data: monthlyRevenue,
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37,99,235,0.12)',
            fill: true,
            tension: 0.3,
            pointRadius: 3
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { display: false }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: function(value) {
                  return 'Rp ' + value.toLocaleString('id-ID');
                }
              }
            }
          }
        }
      });
    }
  })();
</script>
<?= $this->endSection() ?>

