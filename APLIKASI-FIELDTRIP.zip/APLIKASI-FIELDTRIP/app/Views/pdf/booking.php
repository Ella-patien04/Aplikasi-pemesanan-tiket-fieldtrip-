<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bukti Pemesanan</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #27ae60;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            color: #2c3e50;
            font-size: 28px;
        }
        .header p {
            margin: 5px 0;
            color: #7f8c8d;
        }
        .order-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        .info-block {
            border-left: 4px solid #27ae60;
            padding-left: 15px;
        }
        .info-block h3 {
            margin-top: 0;
            margin-bottom: 10px;
            color: #2c3e50;
            font-size: 14px;
            text-transform: uppercase;
        }
        .info-item {
            margin-bottom: 8px;
            font-size: 13px;
        }
        .info-item .label {
            color: #7f8c8d;
            font-weight: bold;
        }
        .info-item .value {
            color: #2c3e50;
        }
        .summary {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .summary h3 {
            margin-top: 0;
            color: #2c3e50;
            text-transform: uppercase;
            font-size: 14px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #ecf0f1;
            font-size: 13px;
        }
        .summary-row:last-child {
            border-bottom: none;
        }
        .summary-row.total {
            border-top: 2px solid #27ae60;
            padding-top: 15px;
            padding-bottom: 0;
            font-weight: bold;
            font-size: 16px;
            color: #27ae60;
        }
        .status-box {
            background: #d5f4e6;
            border: 2px solid #27ae60;
            padding: 15px;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .status-box .status-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
        }
        .status-box .status-value {
            font-size: 18px;
            font-weight: bold;
            color: #27ae60;
            margin-top: 5px;
        }
        .footer {
            text-align: center;
            border-top: 1px solid #ecf0f1;
            padding-top: 20px;
            margin-top: 30px;
            font-size: 11px;
            color: #7f8c8d;
        }
        .footer p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Bukti Pemesanan Fieldtrip</h1>
            <p>Pesanan No. #<?= $order['id'] ?></p>
        </div>

        <div class="order-info">
            <div class="info-block">
                <h3>Data Sekolah</h3>
                <div class="info-item">
                    <span class="label">Nama Sekolah:</span><br>
                    <span class="value"><?= esc($order['school_name']) ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Nama Pemesan:</span><br>
                    <span class="value"><?= esc($order['booker_name']) ?></span>
                </div>
                <div class="info-item">
                    <span class="label">No. Telepon:</span><br>
                    <span class="value"><?= esc($order['phone']) ?></span>
                </div>
            </div>

            <div class="info-block">
                <h3>Detail Pesanan</h3>
                <div class="info-item">
                    <span class="label">Paket:</span><br>
                    <span class="value"><?= esc($order['package']['name']) ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Tanggal Fieldtrip:</span><br>
                    <span class="value"><?= date('d F Y', strtotime($order['visit_date'])) ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Peserta / Wali / Guru:</span><br>
                    <span class="value"><?= $order['num_participants'] ?> / <?= $order['num_guardians'] ?> / <?= $order['num_teachers'] ?> orang</span>
                </div>
            </div>
        </div>

        <div class="summary">
            <h3>Ringkasan Biaya</h3>
            <div class="summary-row">
                <span>Peserta (<?= $order['num_participants'] ?> × Rp <?= number_format($order['package']['price'], 0, ',', '.') ?>)</span>
                <span>Rp <?= number_format($order['num_participants'] * $order['package']['price'], 0, ',', '.') ?></span>
            </div>
            <div class="summary-row">
                <span>Wali Murid (<?= $order['num_guardians'] ?> × Rp 15.000)</span>
                <span>Rp <?= number_format($order['num_guardians'] * 15000, 0, ',', '.') ?></span>
            </div>
            <div class="summary-row">
                <span>Guru Tambahan (dibayar)</span>
                <span>Rp <?= number_format(max(0, ($order['num_teachers'] - floor($order['num_participants'] / 75) * 5) * 15000), 0, ',', '.') ?></span>
            </div>
            <div class="summary-row total">
                <span>Total Harga</span>
                <span>Rp <?= number_format($order['total_price'], 0, ',', '.') ?></span>
            </div>
            <div class="summary-row total">
                <span>DP Pembayaran (30%)</span>
                <span>Rp <?= number_format($order['dp_amount'], 0, ',', '.') ?></span>
            </div>
            <div class="summary-row total" style="border-top: none; color: #e67e22; padding-top: 0;">
                <span>Sisa Pelunasan</span>
                <span>Rp <?= number_format($order['total_price'] - $order['dp_amount'], 0, ',', '.') ?></span>
            </div>
        </div>

        <div class="status-box">
            <div class="status-label">Status Pesanan</div>
            <div class="status-value"><?= ucfirst($order['order_status']) ?></div>
        </div>

        <div class="footer">
            <p>Bukti ini dicetak pada <?= date('d F Y H:i', strtotime($generated_at)) ?></p>
            <p>Untuk pertanyaan, hubungi: info@fieldtrip.id | +62 821 1234 5678</p>
            <p style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ecf0f1;">Terima kasih telah mempercayai Agro Edu Wisata</p>
        </div>
    </div>
</body>
</html>
