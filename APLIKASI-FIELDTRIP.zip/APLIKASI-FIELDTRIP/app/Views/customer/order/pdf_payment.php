<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Kuitansi Pelunasan - <?= $order['school_name'] ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 11pt;
            line-height: 1.6;
            color: #333;
        }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; border-bottom: 3px solid #27ae60; padding-bottom: 20px; margin-bottom: 30px; }
        .header h1 { color: #2c3e50; font-size: 26pt; margin-bottom: 5px; font-weight: 700; }
        .header p { color: #27ae60; font-weight: 600; margin-bottom: 5px; }
        .section { margin-bottom: 25px; }
        .section-title {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 12px 15px;
            font-weight: 700;
            font-size: 12pt;
            border-radius: 4px;
            margin-bottom: 15px;
            border-left: 4px solid #27ae60;
        }
        .section-content { background: #f8f9fa; padding: 15px; border-radius: 4px; border: 1px solid #ecf0f1; }
        .info-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #ecf0f1; }
        .info-row:last-child { border-bottom: none; }
        .info-label { font-weight: 600; color: #2c3e50; width: 40%; }
        .info-value { color: #555; width: 60%; text-align: right; }
        .total-row { background: rgba(39, 174, 96, 0.1); padding: 15px !important; border-radius: 4px; font-size: 13pt; font-weight: 700; border: none !important; margin-top: 10px; color: #27ae60; }
        .status-paid { background: #d4edda; color: #155724; padding: 8px 16px; border-radius: 20px; display: inline-block; font-weight: 700; }
        .detail-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .detail-table th { background: #2c3e50; color: white; padding: 10px; text-align: left; font-weight: 600; border: 1px solid #555; }
        .detail-table td { padding: 10px; border: 1px solid #ecf0f1; background: white; }
        .footer { margin-top: 40px; text-align: center; border-top: 1px solid #ecf0f1; padding-top: 20px; color: #7f8c8d; font-size: 9pt; }
        .highlight { background: #fffacd; padding: 15px; border-left: 4px solid #f39c12; border-radius: 4px; margin: 15px 0; color: #333; }
        .highlight strong { color: #d68910; }
        @media print {
            body { background: white; }
            .container { max-width: 100%; padding: 10px; }
        }
    </style>
</head>
<body>
    <?php
        $attractionTotal = 0;
        if (!empty($order['attractions'])) {
            foreach ($order['attractions'] as $item) {
                $attractionTotal += (float)($item['price_at_booking'] ?? 0) * (int)($item['quantity'] ?? 0);
            }
        }

        $verifiedDate = $order['verified_date'] ?? null;
        $verifiedAt = $verifiedDate ? date('d F Y H:i', strtotime($verifiedDate)) : '-';
    ?>

    <div class="container">
        <div class="header">
            <h1>✅ KUITANSI PELUNASAN</h1>
            <p>Fieldtrip Payment Receipt</p>
            <div class="status-paid">LUNAS</div>
        </div>

        <div class="section">
            <div class="section-title">📋 Informasi Pesanan</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Kode Booking</span>
                    <span class="info-value">#<?= $order['id'] ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tanggal Kunjungan</span>
                    <span class="info-value"><?= date('d F Y', strtotime($order['visit_date'])) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tanggal Pelunasan</span>
                    <span class="info-value"><?= $verifiedAt ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Status Pembayaran</span>
                    <span class="info-value"><strong>paid</strong></span>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="section-title">🏫 Informasi Sekolah & Pemesan</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Nama Sekolah</span>
                    <span class="info-value"><?= esc($order['school_name']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Nama Pemesan</span>
                    <span class="info-value"><?= esc($order['booker_name']) ?></span>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="section-title">✈️ Rincian Paket & Peserta</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Paket</span>
                    <span class="info-value"><?= esc($order['package']['name'] ?? '-') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Jumlah Peserta</span>
                    <span class="info-value"><?= (int)$order['num_participants'] + (int)$order['num_guardians'] + (int)$order['num_teachers'] ?> orang</span>
                </div>

                <?php if (!empty($order['attractions'])): ?>
                    <div class="info-row">
                        <span class="info-label">Wahana Tambahan</span>
                        <span class="info-value"><?= count($order['attractions']) ?> item (Rp <?= number_format($attractionTotal, 0, ',', '.') ?>)</span>
                    </div>
                <?php else: ?>
                    <div class="info-row">
                        <span class="info-label">Wahana Tambahan</span>
                        <span class="info-value">-</span>
                    </div>
                <?php endif; ?>

                <div class="info-row total-row">
                    <span class="info-label">Total Pembayaran</span>
                    <span class="info-value">Rp <?= number_format((float)$order['total_price'] ?? 0, 0, ',', '.') ?></span>
                </div>
            </div>
        </div>

        <?php if (!empty($order['attractions'])): ?>
            <div class="section">
                <div class="section-title">🎡 Detail Wahana Tambahan</div>
                <div class="section-content">
                    <table class="detail-table">
                        <thead>
                            <tr>
                                <th>Wahana</th>
                                <th>Harga / Peserta</th>
                                <th>Jumlah Peserta</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order['attractions'] as $item): ?>
                                <tr>
                                    <td><?= esc($item['attraction_name'] ?? '-') ?></td>
                                    <td>Rp <?= number_format($item['price_at_booking'] ?? 0, 0, ',', '.') ?></td>
                                    <td><?= number_format($item['quantity'] ?? 0) ?> peserta</td>
                                    <td>Rp <?= number_format(((float)($item['price_at_booking'] ?? 0)) * (int)($item['quantity'] ?? 0), 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div class="highlight">
            <strong>Catatan:</strong> Dokumen ini adalah bukti pelunasan. Silakan simpan untuk keperluan administrasi sekolah.
        </div>

        <div class="footer">
            <div>Dokumen otomatis - <?= date('d F Y H:i') ?></div>
        </div>
    </div>
</body>
</html>

