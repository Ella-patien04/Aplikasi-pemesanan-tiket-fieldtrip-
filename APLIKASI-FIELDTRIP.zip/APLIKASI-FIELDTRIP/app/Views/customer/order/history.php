<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1>Riwayat Pesanan</h1>
            <p class="text-muted">Lihat status semua pesanan fieldtrip Anda.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sekolah</th>
                                    <th>Jumlah Peserta</th>
                                    <th>Total Harga</th>
                                    <th>Status Pembayaran</th>
                                    <th>Status Pesanan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($orders)): ?>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td>#<?= $order['id'] ?></td>
                                            <td><?= esc($order['school_name']) ?></td>
                                            <td><?= $order['num_participants'] ?> orang</td>
                                            <td>Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                            <td><span class="badge bg-<?= in_array($order['payment_status'], ['paid', 'dp_paid']) ? 'success' : 'warning' ?>"><?= ucfirst(str_replace('_', ' ', $order['payment_status'])) ?></span></td>
                                            <td><span class="badge bg-<?= $order['order_status'] === 'confirmed' ? 'success' : 'secondary' ?>"><?= ucfirst($order['order_status']) ?></span></td>
                                            <td>
                                                <a href="<?= base_url('customer/order/' . $order['id']) ?>" class="btn btn-sm btn-info">Detail</a>
                                                <?php
                                                    $fieldtripStatus = $order['fieldtrip_status'] ?? 'pending';
                                                    $canPayFinal = $fieldtripStatus === 'selesai' && ($order['payment_status'] ?? '') === 'dp_paid';
                                                ?>
                                                <?php if ($canPayFinal): ?>
                                                    <a href="<?= base_url('customer/order/' . $order['id'] . '/payment') ?>" class="btn btn-sm btn-success">Lakukan Pelunasan</a>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">Belum ada pesanan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
