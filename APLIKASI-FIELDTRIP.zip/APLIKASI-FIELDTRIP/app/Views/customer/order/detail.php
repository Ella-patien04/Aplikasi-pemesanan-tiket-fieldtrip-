<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-4">
                        <div>
                            <h2>Detail Pesanan #<?= $order['id'] ?></h2>
                            <p class="text-muted">Informasi lengkap pesanan fieldtrip Anda.</p>
                        </div>
                        <div>
                            <a href="<?= base_url('customer/order/history') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Data Pemesan</h5>
                            <p><strong>Sekolah:</strong> <?= esc($order['school_name']) ?></p>
                            <p><strong>Nama Pemesan:</strong> <?= esc($order['booker_name']) ?></p>
                            <p><strong>Telepon:</strong> <?= esc($order['phone']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <h5>Ringkasan</h5>
                            <p><strong>Paket:</strong> <?= esc($order['package']['name']) ?></p>
                            <p><strong>Tanggal:</strong> <?= date('d F Y', strtotime($order['visit_date'])) ?></p>
                            <p><strong>Peserta:</strong> <?= $order['num_participants'] ?> orang</p>
                            <p><strong>Wali:</strong> <?= $order['num_guardians'] ?> orang</p>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h5>Detail Harga</h5>
                        <p><strong>Total Harga:</strong> Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                        <p><strong>DP 30%:</strong> Rp <?= number_format($order['dp_amount'], 0, ',', '.') ?></p>
                    </div>

                    <div class="mb-4">
                        <h5>Status</h5>
                        <p><strong>Pembayaran:</strong> <?= ucfirst(str_replace('_', ' ', $order['payment_status'])) ?></p>
                        <p><strong>Pesanan:</strong> <?= ucfirst($order['order_status']) ?></p>
                        <?php if (!empty($order['verified_by_user'])): ?>
                            <p><strong>Diverifikasi oleh:</strong> <?= esc($order['verified_by_user']['name']) ?> pada <?= date('d M Y', strtotime($order['verified_date'])) ?></p>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($order['attractions'])): ?>
                        <div class="mb-4">
                            <h5>Wahana Tambahan</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Nama Wahana</th>
                                            <th>Harga / Peserta</th>
                                            <th>Jumlah Peserta</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($order['attractions'] as $item): ?>
                                            <tr>
                                                <td><?= esc($item['attraction_name'] ?? 'Wahana') ?></td>
                                                <td>Rp <?= number_format($item['price_at_booking'], 0, ',', '.') ?></td>
                                                <td><?= number_format($item['quantity'] ?? 0) ?> peserta</td>
                                                <td>Rp <?= number_format(($item['price_at_booking'] ?? 0) * ($item['quantity'] ?? 0), 0, ',', '.') ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <p class="mt-3"><strong>Total Wahana Tambahan:</strong> Rp <?= number_format($order['attraction_total'] ?? 0, 0, ',', '.') ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($order['payment_status'] === 'pending'): ?>
                        <div class="alert alert-warning">
                            Silakan lanjutkan pembayaran DP untuk mengonfirmasi pesanan.
                            <br>
                            <a href="<?= base_url('customer/order/' . $order['id'] . '/payment') ?>" class="btn btn-sm btn-primary mt-2">Lanjutkan Pembayaran DP</a>
                        </div>
                    <?php endif; ?>

                    <?php if ($order['payment_status'] === 'pending'): ?>
                        <a href="<?= base_url('customer/order/' . $order['id'] . '/payment') ?>" class="btn btn-primary">Lanjutkan Pembayaran DP</a>
                    <?php endif; ?>

                    <?php
                        $fieldtripStatus = $order['fieldtrip_status'] ?? 'pending';
                        if (($fieldtripStatus === 'selesai') && ($order['payment_status'] ?? '') === 'dp_paid'):
                    ?>
                        <a href="<?= base_url('customer/order/' . $order['id'] . '/payment') ?>" class="btn btn-primary">Lakukan Pelunasan</a>
                        <div class="alert alert-info mt-3 mb-0">
                            Field trip sudah selesai dilaksanakan. Silakan lakukan pelunasan.
                        </div>
                    <?php endif; ?>

                    <?php if (($order['payment_status'] ?? '') === 'paid'): ?>
                        <div class="alert alert-success mt-3 mb-0">
                            Status lunas. Terima kasih!
                        </div>
                        <a href="<?= base_url('customer/order/' . $order['id'] . '/download-pdf') ?>" class="btn btn-warning mt-2">Download Bukti Pemesanan (PDF)</a>
                    <?php elseif (($order['payment_status'] ?? '') === 'dp_paid'): ?>
                        <div class="alert alert-info mt-3 mb-0">
                            DP sudah terbayar. Silakan unduh bukti pemesanan (PDF).
                        </div>
                        <a href="<?= base_url('customer/order/' . $order['id'] . '/download-pdf') ?>" class="btn btn-warning mt-2">Download Bukti Pemesanan (PDF)</a>
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
