<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bukti Booking - <?= $order['school_name'] ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 11pt;
            line-height: 1.6;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            border-bottom: 3px solid #27ae60;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28pt;
            margin-bottom: 5px;
            font-weight: 700;
        }

        .header p {
            color: #27ae60;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .header .subtitle {
            color: #7f8c8d;
            font-size: 10pt;
        }

        .section {
            margin-bottom: 25px;
        }

        .section-title {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 12px 15px;
            font-weight: 700;
            font-size: 12pt;
            border-radius: 4px;
            margin-bottom: 15px;
            border-left: 4px solid #27ae60;
        }

        .section-content {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            border: 1px solid #ecf0f1;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #ecf0f1;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            font-weight: 600;
            color: #2c3e50;
            width: 40%;
        }

        .info-value {
            color: #555;
            width: 60%;
            text-align: right;
        }

        .total-row {
            background: rgba(39, 174, 96, 0.1);
            padding: 15px !important;
            border-radius: 4px;
            font-size: 13pt;
            font-weight: 700;
            border: none !important;
            margin-top: 10px;
            color: #27ae60;
        }

        .total-row .info-label,
        .total-row .info-value {
            color: #27ae60;
            font-weight: 700;
        }

        .status-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 10pt;
            text-transform: uppercase;
            margin: 10px 0;
        }

        .status-paid {
            background: #d4edda;
            color: #155724;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .detail-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .detail-table th {
            background: #2c3e50;
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: 600;
            border: 1px solid #555;
        }

        .detail-table td {
            padding: 10px;
            border: 1px solid #ecf0f1;
            background: white;
        }

        .detail-table tr:nth-child(even) td {
            background: #f8f9fa;
        }

        .footer {
            margin-top: 40px;
            text-align: center;
            border-top: 1px solid #ecf0f1;
            padding-top: 20px;
            color: #7f8c8d;
            font-size: 9pt;
        }

        .footer-item {
            display: inline-block;
            margin: 0 15px;
        }

        .qr-code {
            text-align: center;
            margin: 20px 0;
        }

        .qr-code img {
            max-width: 150px;
            height: auto;
        }

        .highlight {
            background: #fffacd;
            padding: 15px;
            border-left: 4px solid #f39c12;
            border-radius: 4px;
            margin: 15px 0;
            color: #333;
        }

        .highlight strong {
            color: #d68910;
        }

        .page-break {
            page-break-after: always;
        }

        @media print {
            body {
                background: white;
            }

            .container {
                max-width: 100%;
                padding: 10px;
            }

            .page-break {
                page-break-after: always;
            }
        }
    </style>
</head>
<body>
    <?php
        $bonusTeachers = floor($order['num_participants'] / 75) * 5;
        $teachersPaid = max(0, $order['num_teachers'] - $bonusTeachers);
        $attractionTotal = 0;
        if (!empty($order['attractions'])) {
            foreach ($order['attractions'] as $item) {
                $attractionTotal += $item['attraction_price'] ?? 0;
            }
        }
    ?>
    <div class="container">
        <!-- HEADER -->
        <div class="header">
            <h1>🎫 BUKTI BOOKING</h1>
            <p>Fieldtrip Package Reservation</p>
            <div class="subtitle">Dokumen ini adalah bukti sah pemesanan field trip Anda</div>
            <div class="status-badge status-<?= strtolower($order['payment_status']) ?>">
                <?= ucfirst($order['payment_status']) ?>
            </div>
        </div>

        <!-- ORDER INFORMATION SECTION -->
        <div class="section">
            <div class="section-title">📋 Informasi Pesanan</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Kode Booking</span>
                    <span class="info-value">#<?= $order['id'] ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Tanggal Pemesanan</span>
                    <span class="info-value"><?= date('d M Y H:i', strtotime($order['created_at'])) ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Status Pembayaran</span>
                    <span class="info-value">
                        <strong><?= ucfirst($order['payment_status']) ?></strong>
                    </span>
                </div>

                <div class="info-row">
                    <span class="info-label">Status Pesanan</span>
                    <span class="info-value">
                        <strong><?= ucfirst($order['order_status']) ?></strong>
                    </span>
                </div>
            </div>
        </div>

        <!-- SCHOOL INFORMATION SECTION -->
        <div class="section">
            <div class="section-title">🏫 Informasi Sekolah</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Nama Sekolah</span>
                    <span class="info-value"><?= esc($order['school_name']) ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Nama Pemesan</span>
                    <span class="info-value"><?= esc($order['booker_name']) ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">No. Telepon</span>
                    <span class="info-value"><?= esc($order['phone']) ?></span>
                </div>
            </div>
        </div>

        <!-- TRIP INFORMATION SECTION -->
        <div class="section">
            <div class="section-title">✈️ Informasi Field Trip</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Paket</span>
                    <span class="info-value"><?= esc($order['package']['name']) ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Tanggal Field Trip</span>
                    <span class="info-value"><?= date('d F Y', strtotime($order['visit_date'])) ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Jumlah Peserta</span>
                    <span class="info-value"><?= $order['num_participants'] ?> orang</span>
                </div>

                <?php if ($order['num_guardians'] > 0): ?>
                    <div class="info-row">
                        <span class="info-label">Jumlah Wali Murid</span>
                        <span class="info-value"><?= $order['num_guardians'] ?> orang</span>
                    </div>
                <?php endif; ?>

                <?php if ($order['num_teachers'] > 0): ?>
                    <div class="info-row">
                        <span class="info-label">Jumlah Guru</span>
                        <span class="info-value"><?= $order['num_teachers'] ?> orang</span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($order['attractions'])): ?>
                    <div class="info-row">
                        <span class="info-label">Wahana Tambahan</span>
                        <span class="info-value"><?= count($order['attractions']) ?> item</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($order['attractions'])): ?>
            <div class="section">
                <div class="section-title">🎡 Daftar Wahana Tambahan</div>
                <div class="section-content">
                    <table class="detail-table">
                        <thead>
                            <tr>
                                <th>Wahana</th>
                                <th>Harga / Peserta</th>
                                <th>Jumlah Peserta</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order['attractions'] as $item): ?>
                                <tr>
                                    <td><?= esc($item['attraction_name']) ?></td>
                                    <td>Rp <?= number_format($item['price_at_booking'] ?? 0, 0, ',', '.') ?></td>
                                    <td><?= number_format($item['quantity'] ?? 0) ?> peserta</td>
                                    <td>Rp <?= number_format(($item['price_at_booking'] ?? 0) * ($item['quantity'] ?? 0), 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- PAYMENT SECTION -->
        <div class="section">
            <div class="section-title">💳 Rincian Pembayaran</div>
            <div class="section-content">
                <div class="info-row">
                    <span class="info-label">Harga Paket / Peserta</span>
                    <span class="info-value">Rp <?= number_format($order['package']['price'], 0, ',', '.') ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Subtotal Peserta</span>
                    <span class="info-value">Rp <?= number_format($order['num_participants'] * $order['package']['price'], 0, ',', '.') ?></span>
                </div>

                <?php if ($order['num_guardians'] > 0): ?>
                    <div class="info-row">
                        <span class="info-label">Biaya Wali Murid</span>
                        <span class="info-value">Rp <?= number_format($order['num_guardians'] * 15000, 0, ',', '.') ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($order['num_teachers'] > 0): ?>
                    <div class="info-row">
                        <span class="info-label">Biaya Guru</span>
                        <span class="info-value">Rp <?= number_format($teachersPaid * 15000, 0, ',', '.') ?></span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($order['attractions'])): ?>
                    <div class="info-row">
                        <span class="info-label">Biaya Wahana Tambahan</span>
                        <span class="info-value">Rp <?= number_format($attractionTotal, 0, ',', '.') ?></span>
                    </div>
                <?php endif; ?>

                <div class="info-row total-row">
                    <span class="info-label">TOTAL HARGA</span>
                    <span class="info-value">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">DP Pembayaran (30%)</span>
                    <span class="info-value" style="color: #27ae60; font-weight: 700;">Rp <?= number_format($order['dp_amount'], 0, ',', '.') ?></span>
                </div>

                <div class="info-row">
                    <span class="info-label">Sisa Pembayaran</span>
                    <span class="info-value">Rp <?= number_format($order['total_price'] - $order['dp_amount'], 0, ',', '.') ?></span>
                </div>
            </div>
        </div>

        <!-- IMPORTANT NOTES -->
        <?php if ($order['payment_status'] === 'pending'): ?>
            <div class="highlight">
                <strong>⚠️ PERHATIAN:</strong> Pesanan Anda masih dalam status PENDING. Silakan selesaikan pembayaran untuk mengkonfirmasi pemesanan. Pesanan akan otomatis dikonfirmasi setelah pembayaran diterima.
            </div>
        <?php elseif ($order['payment_status'] === 'paid'): ?>
            <div class="highlight">
                <strong>✓ DIKONFIRMASI:</strong> Pesanan Anda telah dikonfirmasi dan pembayaran sudah diterima. Anda akan menerima informasi lebih lanjut melalui WhatsApp atau Email.
            </div>
        <?php endif; ?>

        <!-- FOOTER -->
        <div class="footer">
            <div class="footer-item">
                <strong>Tanggal Cetak:</strong> <?= date('d F Y H:i') ?>
            </div>
            <div class="footer-item">
                <strong>Booking Code:</strong> #<?= $order['id'] ?>
            </div>
            <div class="footer-item" style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #ccc;">
                <strong>Nomor Referensi (DP):</strong> <?= esc($order['pdf_token'] ?? '-') ?>
            </div>
            <div class="footer-item" style="margin-top: 10px; padding-top: 10px;">
                Dokumen ini dibuat secara otomatis. Untuk pertanyaan, hubungi admin di WhatsApp atau email.
            </div>

        </div>
    </div>
</body>
</html>
