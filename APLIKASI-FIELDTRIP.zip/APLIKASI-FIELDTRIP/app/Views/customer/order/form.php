<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
    .order-form-section {
        background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(39, 174, 96, 0.95) 100%);
        min-height: 100vh;
        padding: 40px 0;
        position: relative;
    }

    .order-form-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3') center/cover;
        opacity: 0.1;
        z-index: 0;
    }

    .order-container {
        position: relative;
        z-index: 1;
    }

    .form-card {
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        padding: 30px;
    }

    .form-card h3 {
        color: #2c3e50;
        font-weight: 700;
        margin-bottom: 25px;
        padding-bottom: 15px;
        border-bottom: 3px solid #27ae60;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-label {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 8px;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .form-control, .form-select {
        border: 2px solid #ecf0f1;
        border-radius: 8px;
        padding: 12px 15px;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
        border-color: #27ae60;
        box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
    }

    .form-control::placeholder {
        color: #bdc3c7;
    }

    .summary-card {
        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
        color: white;
        border-radius: 15px;
        padding: 25px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    }

    .summary-card h3 {
        border-bottom: 2px solid #27ae60;
        padding-bottom: 15px;
        margin-bottom: 20px;
    }

    .summary-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .summary-item:last-child {
        border-bottom: none;
    }

    .summary-item-label {
        font-size: 13px;
        color: #bdc3c7;
        font-weight: 500;
    }

    .summary-item-value {
        font-weight: 600;
        color: #ecf0f1;
    }

    .summary-item.total {
        background: rgba(39, 174, 96, 0.15);
        padding: 12px 10px;
        border-radius: 8px;
        margin-top: 10px;
        font-size: 16px;
    }

    .summary-item.total .summary-item-value {
        color: #27ae60;
        font-size: 20px;
    }

    .btn-submit {
        background: linear-gradient(135deg, #27ae60 0%, #229653 100%);
        border: none;
        color: white;
        font-weight: 700;
        padding: 14px;
        border-radius: 8px;
        width: 100%;
        margin-top: 25px;
        transition: all 0.3s ease;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .btn-submit:hover {
        background: linear-gradient(135deg, #229653 0%, #1a7a45 100%);
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(39, 174, 96, 0.4);
        color: white;
    }

    .btn-submit:active {
        transform: translateY(0);
    }

    .package-card {
        background: #f8f9fa;
        border: 2px solid #ecf0f1;
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 10px;
        transition: all 0.3s ease;
    }

    .package-card:hover {
        border-color: #27ae60;
        background: rgba(39, 174, 96, 0.05);
    }

    .package-card label.package-info {
        display: block;
        cursor: pointer;
        width: 100%;
        min-height: 100%;
    }

    .package-card input[type="radio"] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
    }

    .package-card input[type="radio"]:checked + .package-details {
        color: #27ae60;
        font-weight: 700;
    }
    .package-card.selected {
        border-color: #27ae60;
        box-shadow: 0 6px 18px rgba(39,174,96,0.18);
    }

    .bonus-info {
        background: rgba(39, 174, 96, 0.1);
        border-left: 4px solid #27ae60;
        padding: 12px;
        border-radius: 4px;
        margin-top: 15px;
        font-size: 13px;
    }

    .bonus-info strong {
        color: #27ae60;
    }

    .loading {
        display: none;
        text-align: center;
        padding: 10px;
        color: #27ae60;
    }

    .error-message {
        color: #e74c3c;
        font-size: 12px;
        margin-top: 5px;
    }

    .success-message {
        color: #27ae60;
        font-size: 12px;
        margin-top: 5px;
    }

    @media (max-width: 768px) {
        .form-card, .summary-card {
            margin-bottom: 20px;
        }

        .order-form-section {
            padding: 20px 0;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="order-form-section">
    <div class="container order-container">
        <div class="row g-4">
            <!-- FORM SECTION -->
            <div class="col-lg-6">
                <div class="form-card">
                    <h3><i class="fas fa-ticket-alt"></i> Form Pemesanan Fieldtrip</h3>

                    <form action="<?= base_url('customer/order/save') ?>" method="POST" id="orderForm">
                        <?= csrf_field() ?>

                        <!-- Data Sekolah -->
                        <div class="form-group">
                            <label class="form-label">Nama Sekolah / Instansi</label>
                            <input type="text" name="school_name" class="form-control" placeholder="Masukkan nama sekolah" value="<?= old('school_name') ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Nama Pemesan</label>
                            <input type="text" name="booker_name" class="form-control" placeholder="Nama lengkap pemesan" value="<?= old('booker_name') ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">No. HP / WhatsApp</label>
                            <input type="tel" name="phone" class="form-control" placeholder="Contoh: 0812345678" value="<?= old('phone') ?>" required>
                        </div>

                        <!-- Peserta Details -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Jumlah Peserta</label>
                                    <input type="number" id="num_participants" name="num_participants" class="form-control" min="1" placeholder="0" value="<?= old('num_participants') ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Jumlah Wali Murid</label>
                                    <input type="number" id="num_guardians" name="num_guardians" class="form-control" min="0" placeholder="0" value="<?= old('num_guardians') ?? 0 ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Jumlah Guru</label>
                            <input type="number" id="num_teachers" name="num_teachers" class="form-control" min="0" placeholder="0" value="<?= old('num_teachers') ?? 0 ?>">
                        </div>

                        <!-- Package Selection -->
                        <div class="form-group">
                            <label class="form-label">Pilih Paket Fieldtrip</label>
                            <div class="row g-2">
                                <?php if (empty($packages)): ?>
                                    <div class="col-12">
                                        <div class="alert alert-warning">Belum ada paket aktif. Silakan hubungi admin.</div>
                                    </div>
                                <?php else: ?>
                                    <?php $selectedPackageId = old('package_id') ?: ($selectedPackageId ?? null); ?>
                                    <?php foreach ($packages as $package): ?>
                                        <?php $isChecked = (string) $selectedPackageId === (string) $package['id']; ?>
                                        <div class="col-md-6">
                                            <div class="package-card position-relative<?= $isChecked ? ' selected' : '' ?>">
                                                <label for="package-<?= $package['id'] ?>" class="package-info">
                                                    <input type="radio" name="package_id" id="package-<?= $package['id'] ?>" value="<?= $package['id'] ?>" data-price="<?= $package['price'] ?>" <?= $isChecked ? 'checked' : '' ?> required>
                                                    <div class="package-details">
                                                        <strong><?= esc($package['name']) ?></strong><br>
                                                        <small>Rp <?= number_format($package['price'], 0, ',', '.') ?> / peserta</small>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Additional Attractions -->
                        <div class="form-group">
                            <label class="form-label">Wahana Tambahan</label>
                            <div class="row g-2">
                                <?php if (empty($attractions)): ?>
                                    <div class="col-12">
                                        <div class="alert alert-secondary">Tidak ada wahana tambahan saat ini.</div>
                                    </div>
                                <?php else: ?>
                                    <?php $selectedAttractions = old('attractions') ?? []; ?>
                                    <?php foreach ($attractions as $attraction): ?>
                                        <div class="col-md-6">
                                            <div class="form-check card p-3">
                                                <input class="form-check-input attraction-checkbox" type="checkbox" name="attractions[]" id="attraction-<?= $attraction['id'] ?>" value="<?= $attraction['id'] ?>" data-price="<?= $attraction['price'] ?>" <?= in_array($attraction['id'], (array)$selectedAttractions) ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="attraction-<?= $attraction['id'] ?>">
                                                    <strong><?= esc($attraction['name']) ?></strong><br>
                                                    <small>Rp <?= number_format($attraction['price'], 0, ',', '.') ?></small>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Visit Date Selection -->
                        <div class="form-group">
                            <label class="form-label">Tanggal Kunjungan</label>
                            <input type="text" id="visit_date" name="visit_date" class="form-control mb-2" placeholder="Pilih tanggal" readonly required>
                            <div id="dateStatus"></div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-check-circle"></i> Konfirmasi Pesanan
                        </button>
                    </form>

                    <div class="bonus-info">
                        <strong><i class="fas fa-gift"></i> Bonus Guru Gratis:</strong><br>
                        Setiap 75 peserta mendapatkan 5 guru gratis. Kelebihan guru akan dikenakan biaya Rp15.000/orang.
                    </div>
                </div>
            </div>

            <!-- SUMMARY SECTION -->
            <div class="col-lg-6">
                <div class="summary-card">
                    <h3><i class="fas fa-receipt"></i> Ringkasan Pesanan</h3>

                    <div class="summary-item">
                        <span class="summary-item-label">Jumlah Peserta</span>
                        <span class="summary-item-value"><span id="summaryParticipants">0</span> orang</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Harga Paket / Peserta</span>
                        <span class="summary-item-value">Rp <span id="summaryPacketPrice">0</span></span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Subtotal Peserta</span>
                        <span class="summary-item-value">Rp <span id="summarySubtotalParticipants">0</span></span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Jumlah Wali Murid</span>
                        <span class="summary-item-value"><span id="summaryGuardians">0</span> × Rp15.000</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Biaya Wali</span>
                        <span class="summary-item-value">Rp <span id="summaryGuardiansCost">0</span></span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Jumlah Guru</span>
                        <span class="summary-item-value"><span id="summaryTeachers">0</span> orang</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Bonus Guru Gratis</span>
                        <span class="summary-item-value" style="color: #27ae60;"><span id="summaryBonusTeachers">0</span> orang</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Guru yang Dibayar</span>
                        <span class="summary-item-value"><span id="summaryTeachersPaid">0</span> × Rp15.000</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Biaya Guru</span>
                        <span class="summary-item-value">Rp <span id="summaryTeachersCost">0</span></span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Wahana Tambahan</span>
                        <span class="summary-item-value"><span id="summaryAttractionCount">0</span> item</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Biaya Wahana Tambahan</span>
                        <span class="summary-item-value">Rp <span id="summaryAttractionCost">0</span></span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label" style="border-top: 2px solid rgba(255,255,255,0.2); padding-top: 15px; margin-top: 15px;">TOTAL HARGA</span>
                        <span class="summary-item-value" style="border-top: 2px solid rgba(255,255,255,0.2); padding-top: 15px; margin-top: 15px; font-size: 18px;">Rp <span id="summaryTotal">0</span></span>
                    </div>

                    <div class="summary-item total">
                        <span class="summary-item-label">DP Pembayaran (30%)</span>
                        <span class="summary-item-value">Rp <span id="summaryDP">0</span></span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-item-label">Sisa Pelunasan</span>
                        <span class="summary-item-value">Rp <span id="summarySisa">0</span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
// Initialize flatpickr for visit_date. Availability checked via AJAX on change.
const fp = flatpickr('#visit_date', {
    dateFormat: 'Y-m-d',
    onChange: function(selectedDates, dateStr) {
        // check date capacity and update UI
        if (!dateStr) return;
        fetch(`<?= base_url('customer/api/date-capacity') ?>/${dateStr}`)
            .then(r => r.json())
            .then(data => {
                const statusDiv = document.getElementById('dateStatus');
                if (data.success) {
                    if (data.is_full) {
                        statusDiv.innerHTML = '<div class="error-message">Kuota pada tanggal yang dipilih sudah penuh, silakan pilih tanggal lain.</div>';
                    } else {
                        statusDiv.innerHTML = '<div class="success-message">Kapasitas tersedia: ' + data.available + ' peserta</div>';
                    }
                }
                updateSummary();
            }).catch(() => {});
    }
});

const GUARDIAN_COST = 15000;
const TEACHER_COST = 15000;
const BONUS_TEACHERS_PER = 75;
const BONUS_TEACHERS_COUNT = 5;

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('orderForm');
    const participants = document.getElementById('num_participants');
    const guardians = document.getElementById('num_guardians');
    const teachers = document.getElementById('num_teachers');
    const packageSelect = document.querySelectorAll('input[name="package_id"]');
    const attractionCheckboxes = document.querySelectorAll('.attraction-checkbox');
    const visitDateInput = document.getElementById('visit_date');

    // Add event listeners
    participants.addEventListener('input', function() {
        updateSummary();
    });
    guardians.addEventListener('input', updateSummary);
    teachers.addEventListener('input', updateSummary);
    visitDateInput && visitDateInput.addEventListener('change', function() {
        updateSummary();
    });
    packageSelect.forEach(select => {
        select.addEventListener('change', function() {
            // Highlight selected package card
            document.querySelectorAll('.package-card').forEach(c => c.classList.remove('selected'));
            const card = this.closest('.package-card');
            if (card) card.classList.add('selected');
            updateSummary();
        });
    });

    attractionCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSummary);
    });

    // Initialize selected class for pre-checked radio (if any)
    const preChecked = document.querySelector('input[name="package_id"]:checked');
    if (preChecked) {
        const card = preChecked.closest('.package-card');
        if (card) card.classList.add('selected');
    }

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        (async function(){
            const participantCount = parseInt(participants.value) || 0;
            const visitDate = document.getElementById('visit_date').value;
            if (!visitDate) {
                Swal.fire({ icon: 'error', title: 'Pilih tanggal kunjungan', text: 'Silakan pilih tanggal kunjungan.' });
                return false;
            }

            try {
                const resp = await fetch(`<?= base_url('customer/api/date-capacity') ?>/${visitDate}`);
                const data = await resp.json();
                const available = data.available || 0;
                if (participantCount > available) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Kuota Tidak Mencukupi',
                        text: `Kuota tersedia hanya ${available} orang untuk tanggal ini.`,
                        confirmButtonColor: '#27ae60'
                    });
                    return false;
                }
                // Submit form
                form.submit();
            } catch (e) {
                Swal.fire({ icon: 'error', title: 'Error', text: 'Gagal memeriksa kuota tanggal.' });
            }
        })();
    });

    updateSummary();
});

function updateSummary() {
    const participants = parseInt(document.getElementById('num_participants').value) || 0;
    const guardians = parseInt(document.getElementById('num_guardians').value) || 0;
    const teachers = parseInt(document.getElementById('num_teachers').value) || 0;
    
    const packageRadio = document.querySelector('input[name="package_id"]:checked');
    const packagePrice = packageRadio ? parseInt(packageRadio.dataset.price) : 0;

    // Calculate costs
    const subtotalParticipants = participants * packagePrice;
    const guardiansCost = guardians * GUARDIAN_COST;
    
    // Calculate bonus teachers
    const bonusTeachers = Math.floor(participants / BONUS_TEACHERS_PER) * BONUS_TEACHERS_COUNT;
    const teachersPaid = Math.max(0, teachers - bonusTeachers);
    const teachersCost = teachersPaid * TEACHER_COST;

    let attractionCost = 0;
    let attractionCount = 0;
    document.querySelectorAll('.attraction-checkbox:checked').forEach(checkbox => {
        const price = parseInt(checkbox.dataset.price) || 0;
        attractionCost += price * participants;
        attractionCount += 1;
    });

    const totalPrice = subtotalParticipants + guardiansCost + teachersCost + attractionCost;
    const dpAmount = totalPrice * 0.3;
    const sisaAmount = totalPrice - dpAmount;

    // Update summary
    document.getElementById('summaryParticipants').textContent = formatNumber(participants);
    document.getElementById('summaryPacketPrice').textContent = formatNumber(packagePrice);
    document.getElementById('summarySubtotalParticipants').textContent = formatNumber(subtotalParticipants);
    document.getElementById('summaryGuardians').textContent = formatNumber(guardians);
    document.getElementById('summaryGuardiansCost').textContent = formatNumber(guardiansCost);
    document.getElementById('summaryTeachers').textContent = formatNumber(teachers);
    document.getElementById('summaryBonusTeachers').textContent = formatNumber(bonusTeachers);
    document.getElementById('summaryTeachersPaid').textContent = formatNumber(teachersPaid);
    document.getElementById('summaryTeachersCost').textContent = formatNumber(teachersCost);
    document.getElementById('summaryAttractionCount').textContent = formatNumber(attractionCount);
    document.getElementById('summaryAttractionCost').textContent = formatNumber(attractionCost);
    document.getElementById('summaryTotal').textContent = formatNumber(totalPrice);
    document.getElementById('summaryDP').textContent = formatNumber(dpAmount);
    document.getElementById('summarySisa').textContent = formatNumber(sisaAmount);
}

// Availability checks use server-side endpoint for visit_date

function formatNumber(num) {
    return num.toLocaleString('id-ID');
}
</script>
<?= $this->endSection() ?>
