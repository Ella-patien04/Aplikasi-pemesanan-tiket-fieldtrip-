<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('css') ?>
<style>
    .payment-section {
        background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(39, 174, 96, 0.95) 100%);
        min-height: 100vh;
        padding: 40px 0;
        position: relative;
    }

    .payment-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3') center/cover;
        opacity: 0.1;
        z-index: 0;
    }

    .payment-container {
        position: relative;
        z-index: 1;
    }

    .payment-card {
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        padding: 30px;
        margin-bottom: 25px;
    }

    .payment-card h3 {
        color: #2c3e50;
        font-weight: 700;
        margin-bottom: 25px;
        padding-bottom: 15px;
        border-bottom: 3px solid #27ae60;
    }

    .order-summary {
        background: #f8f9fa;
        border-left: 4px solid #27ae60;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .summary-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #ecf0f1;
    }

    .summary-row:last-child {
        border-bottom: none;
    }

    .summary-label {
        font-weight: 500;
        color: #555;
    }

    .summary-value {
        font-weight: 600;
        color: #2c3e50;
    }

    .total-row {
        padding: 15px 0 !important;
        border-top: 2px solid #27ae60 !important;
        margin-top: 10px;
    }

    .total-row .summary-value {
        color: #27ae60;
        font-size: 18px;
    }

    .button-pay {
        background: linear-gradient(135deg, #27ae60 0%, #229653 100%);
        border: none;
        color: white;
        font-weight: 700;
        padding: 15px 40px;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.3s ease;
        text-transform: uppercase;
        letter-spacing: 1px;
        width: 100%;
        margin-top: 20px;
    }

    .button-pay:hover:not(:disabled) {
        background: linear-gradient(135deg, #229653 0%, #1a7a45 100%);
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(39, 174, 96, 0.4);
    }

    .button-pay:disabled {
        background: #bdc3c7;
        cursor: not-allowed;
        transform: none;
    }

    .status-badge {
        display: inline-block;
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 12px;
        text-transform: uppercase;
        margin-bottom: 15px;
    }

    .status-pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-paid {
        background: #d4edda;
        color: #155724;
    }

    .status-failed {
        background: #f8d7da;
        color: #721c24;
    }

    .info-box {
        background: #d1ecf1;
        border-left: 4px solid #0c5460;
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .info-box strong {
        color: #0c5460;
    }

    .alert-info {
        background: #e7f3ff;
        border-left: 4px solid #2196F3;
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 20px;
        color: #0c3a66;
    }

    .payment-instructions {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin-top: 15px;
    }

    .payment-instructions h4 {
        color: #2c3e50;
        margin-bottom: 15px;
    }

    .payment-instructions ol {
        margin-left: 20px;
    }

    .payment-instructions li {
        margin-bottom: 10px;
        color: #555;
    }

    .spinner {
        border: 3px solid #f3f3f3;
        border-top: 3px solid #27ae60;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        animation: spin 1s linear infinite;
        display: inline-block;
        margin-right: 10px;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
        .payment-card {
            padding: 20px;
        }

        .button-pay {
            padding: 12px 30px;
            font-size: 14px;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="payment-section">
    <div class="container payment-container">
        <div class="row g-4">
            <!-- ORDER SUMMARY -->
            <div class="col-lg-5">
                <div class="payment-card">
                    <h3><i class="fas fa-receipt"></i> Ringkasan Pesanan</h3>

                    <span class="status-badge status-<?= strtolower($order['payment_status']) ?>">
                        <?= ucfirst($order['payment_status']) ?>
                    </span>

                    <div class="order-summary">
                        <div class="summary-row">
                            <span class="summary-label">Kode Pesanan</span>
                            <span class="summary-value">#<?= $order['id'] ?></span>
                        </div>

                        <div class="summary-row">
                            <span class="summary-label">Sekolah</span>
                            <span class="summary-value"><?= esc($order['school_name']) ?></span>
                        </div>

                        <div class="summary-row">
                            <span class="summary-label">Nama Pemesan</span>
                            <span class="summary-value"><?= esc($order['booker_name']) ?></span>
                        </div>

                        <div class="summary-row">
                            <span class="summary-label">Tanggal</span>
                            <span class="summary-value"><?= date('d F Y', strtotime($order['visit_date'])) ?></span>
                        </div>

                        <div class="summary-row">
                            <span class="summary-label">Peserta</span>
                            <span class="summary-value"><?= $order['num_participants'] ?> orang</span>
                        </div>

                        <div class="summary-row total-row">
                            <span class="summary-label">Total Harga</span>
                            <span class="summary-value">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></span>
                        </div>
                    </div>

                    <!-- Payment Status Info -->
                    <?php if ($order['payment_status'] === 'paid'): ?>
                        <div class="info-box">
                            <strong>✓ Pembayaran Berhasil:</strong><br>
                            Pesanan Anda telah dikonfirmasi.
                        </div>
                    <?php elseif ($order['payment_status'] === 'dp_paid'): ?>
                        <div class="info-box">
                            <strong>ℹ️ DP Sudah Dibayar:</strong><br>
                            Silakan lanjutkan pelunasan untuk menyelesaikan pesanan.
                        </div>
                    <?php elseif ($order['payment_status'] === 'failed'): ?>
                        <div class="alert alert-danger">
                            <strong>✗ Pembayaran Gagal:</strong><br>
                            Silakan coba lagi atau hubungi admin.
                        </div>
                    <?php endif; ?>
                </div>

                <div class="payment-card">
                    <h3><i class="fas fa-info-circle"></i> Informasi Pembayaran</h3>

                    <div class="payment-instructions">
                        <h4>Metode Pembayaran:</h4>
                        <ol>
                            <li>Transfer Bank</li>
                            <li>E-Wallet (Dana, GoPay, OVO)</li>
                            <li>QRIS</li>
                            <li>Cicilan (0% hingga 12 bulan)</li>
                        </ol>
                    </div>

                    <div class="payment-instructions">
                        <h4>Petunjuk:</h4>
                        <ol>
                            <li>Klik "Bayar Sekarang"</li>
                            <li>Pilih metode pembayaran</li>
                            <li>Ikuti proses pembayaran</li>
                            <li>Tunggu konfirmasi otomatis</li>
                        </ol>
                    </div>
                </div>
            </div>

            <!-- PAYMENT SECTION -->
            <div class="col-lg-7">
                <div class="payment-card">
                    <h3><i class="fas fa-credit-card"></i> Pembayaran Midtrans</h3>

                    <?php if ($snapToken): ?>
                        <div class="alert-info">
                            <strong>💳 Pilih metode pembayaran dan selesaikan transaksi</strong>
                        </div>

                        <button id="payButton" class="button-pay" onclick="payWithMidtrans()">
                            <i class="fas fa-lock"></i> <?= isset($paymentType) && $paymentType === 'final' ? 'Bayar Pelunasan' : 'Bayar Sekarang' ?>
                        </button>

                        <div class="info-box" style="margin-top: 20px;">
                            <strong>🔒 Aman & Terpercaya:</strong><br>
                            Pembayaran Anda dilindungi dengan enkripsi SSL 256-bit.
                        </div>
                    <?php elseif (!$snapToken && $order['payment_status'] !== 'paid'): ?>
                        <div class="alert alert-danger">
                            <strong>❌ Error:</strong> Gagal membuat token pembayaran.
                        </div>
                    <?php else: ?>
                        <div class="info-box">
                            <strong>ℹ️ Status:</strong><br>
                            Status pembayaran: <strong><?= ucfirst($order['payment_status']) ?></strong>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Order Details -->
                <div class="payment-card">
                    <h3><i class="fas fa-list"></i> Detail Pesanan</h3>

                    <div class="order-summary">
                        <div class="summary-row">
                            <span class="summary-label">Paket</span>
                            <span class="summary-value"><?= esc($order['package']['name']) ?></span>
                        </div>

                        <div class="summary-row">
                            <span class="summary-label">Harga / Peserta</span>
                            <span class="summary-value">Rp <?= number_format($order['package']['price'], 0, ',', '.') ?></span>
                        </div>

                        <div class="summary-row">
                            <span class="summary-label">Jumlah Peserta</span>
                            <span class="summary-value"><?= $order['num_participants'] ?> × Rp <?= number_format($order['package']['price'], 0, ',', '.') ?></span>
                        </div>

                        <?php if ($order['num_guardians'] > 0): ?>
                            <div class="summary-row">
                                <span class="summary-label">Wali Murid</span>
                                <span class="summary-value"><?= $order['num_guardians'] ?> × Rp 15.000</span>
                            </div>
                        <?php endif; ?>

                        <?php if ($order['num_teachers'] > 0): ?>
                            <div class="summary-row">
                                <span class="summary-label">Guru</span>
                                <span class="summary-value"><?= $order['num_teachers'] ?> orang</span>
                            </div>
                        <?php endif; ?>

                        <div class="summary-row total-row">
                            <span class="summary-label">Total</span>
                            <span class="summary-value">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></span>
                        </div>

                        <?php if (isset($paymentType) && $paymentType === 'final'): ?>
                            <div class="summary-row">
                                <span class="summary-label">Pelunasan</span>
                                <span class="summary-value" style="color: #27ae60;">Rp <?= number_format($paymentAmount, 0, ',', '.') ?></span>
                            </div>
                        <?php else: ?>
                            <div class="summary-row">
                                <span class="summary-label">DP 30%</span>
                                <span class="summary-value" style="color: #27ae60;">Rp <?= number_format($order['dp_amount'], 0, ',', '.') ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?php
    $midtransClientKey = function_exists('midtrans_get_env') ? midtrans_get_env('MIDTRANS_CLIENT_KEY') : env('MIDTRANS_CLIENT_KEY');
    $midtransProduction = function_exists('midtrans_get_env') ? midtrans_get_env('MIDTRANS_PRODUCTION', false) : env('MIDTRANS_PRODUCTION', false);
    $midtransScriptHost = filter_var($midtransProduction, FILTER_VALIDATE_BOOLEAN)
        ? 'https://app.midtrans.com/snap/snap.js'
        : 'https://app.sandbox.midtrans.com/snap/snap.js';
?>
<script src="<?= $midtransScriptHost ?>" data-client-key="<?= $midtransClientKey ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const snapToken = '<?= $snapToken ?? '' ?>';
    const orderId = '<?= $order['id'] ?>';

    function payWithMidtrans() {
        if (!snapToken) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Token pembayaran tidak ditemukan.',
                confirmButtonColor: '#27ae60'
            });
            return;
        }

        const payButton = document.getElementById('payButton');
        payButton.disabled = true;
        payButton.innerHTML = '<span class="spinner"></span> Membuka Pembayaran...';

        snap.pay(snapToken, {
            onSuccess: function(result) {
                payButton.disabled = false;
                payButton.innerHTML = '<i class="fas fa-lock"></i> Bayar Sekarang';
                window.location.href = `/customer/order/${orderId}`;
            },
            onPending: function(result) {
                payButton.disabled = false;
                payButton.innerHTML = '<i class="fas fa-lock"></i> Bayar Sekarang';
                window.location.href = `/customer/order/${orderId}`;
            },
            onError: function(result) {
                Swal.fire({
                    icon: 'error',
                    title: 'Pembayaran Gagal',
                    text: 'Terjadi kesalahan saat memproses pembayaran',
                    confirmButtonColor: '#27ae60'
                });
                payButton.disabled = false;
                payButton.innerHTML = '<i class="fas fa-lock"></i> Bayar Sekarang';
            },
            onClose: function() {
                payButton.disabled = false;
                payButton.innerHTML = '<i class="fas fa-lock"></i> Bayar Sekarang';
            }
        });
    }
</script>
<?= $this->endSection() ?>
