<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h1 class="h3">Profil Saya</h1>
        <p class="text-muted">Kelola data akun Anda di sini.</p>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="row gy-3">
            <div class="col-md-6">
                <h6 class="text-uppercase text-muted mb-3">Nama</h6>
                <p class="mb-0"><?= esc($user['name'] ?? '-') ?></p>
            </div>
            <div class="col-md-6">
                <h6 class="text-uppercase text-muted mb-3">Email</h6>
                <p class="mb-0"><?= esc($user['email'] ?? '-') ?></p>
            </div>
            <div class="col-md-6">
                <h6 class="text-uppercase text-muted mb-3">Role</h6>
                <p class="mb-0"><?= esc($user['role'] ?? '-') ?></p>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
