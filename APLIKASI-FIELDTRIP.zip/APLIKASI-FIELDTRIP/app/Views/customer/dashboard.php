<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3 d-inline">Dashboard Customer</h1>
            <div class="float-end">
                <a href="<?= base_url('auth/logout') ?>" class="btn btn-sm btn-danger">Logout</a>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-12">
            <h3>Selamat datang, <?= session()->get('user_name') ?></h3>
            <p class="text-muted">Kelola pemesanan fieldtrip Anda di sini</p>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Total Pesanan</h6>
                    <h2 class="card-text"><?= $total_orders ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body text-center">
                    <a href="<?= base_url('customer/order/form') ?>" class="btn btn-lg btn-success">
                        <i class="fas fa-plus"></i> Pesan Sekarang
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Orders -->
    <div class="row">
        <div class="col-md-12">
            <h4 class="mb-3">Pesanan Terbaru</h4>
            <script>
                // Realtime status polling (tanpa refresh)
                // Endpoint: /payment/status/{order_id}
                (function () {
                    const orderIds = [
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $o): ?>
                                <?= (int)$o['id'] ?>,
                            <?php endforeach; ?>
                        <?php endif; ?>
                    ].filter(Boolean);

                    if (!orderIds.length) return;

                    const intervalMs = 3000;
                    const statuses = {};

                    function renderStatusCell(orderId, normalized) {
                        const td = document.querySelector('[data-payment-status-cell="' + orderId + '"]');
                        if (!td) return;
                        if (normalized === 'paid') {
                            td.innerHTML = '<span class="badge bg-success">Paid</span>';
                        } else {
                            td.innerHTML = '<span class="badge bg-warning">Pending</span>';
                        }
                    }

                    async function checkOne(orderId) {
                        try {
                            const res = await fetch('/payment/status/' + orderId, { headers: { 'Accept': 'application/json' } });
                            if (!res.ok) return;
                            const data = await res.json();
                            if (!data || !data.status) return;

                            const prev = statuses[orderId];
                            statuses[orderId] = data.status;
                            renderStatusCell(orderId, data.status);

                            // stop polling for paid orders
                            return data.status === 'paid' ? 'paid' : prev;
                        } catch (e) {
                            // ignore
                        }
                    }

                    let remaining = new Set(orderIds);

                    setInterval(async function () {
                        const ids = Array.from(remaining);
                        if (!ids.length) return;

                        await Promise.all(ids.map(async (id) => {
                            const r = await checkOne(id);
                            if (r === 'paid') remaining.delete(id);

                            if (remaining.size === 0) {
                                // optional: show toast
                                console.log('All orders paid');
                            }
                        }));
                    }, intervalMs);
                })();
            </script>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No. Pesanan</th>
                            <th>Sekolah</th>
                            <th>Total Peserta</th>
                            <th>Total Harga</th>
                            <th>Status Pembayaran</th>
                            <th>Status Pesanan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td>#<?= $order['id'] ?></td>
                                    <td><?= htmlspecialchars($order['school_name']) ?></td>
                                    <td><?= $order['num_participants'] ?> orang</td>
                                    <td>Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                    <td>
                                        <span class="badge bg-<?= $order['payment_status'] === 'paid' ? 'success' : 'warning' ?>" data-payment-status-cell="<?= (int)$order['id'] ?>">
                                            <?= ucfirst(str_replace('_', ' ', $order['payment_status'])) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="badge bg-<?= $order['order_status'] === 'confirmed' ? 'success' : 'info' ?>">
                                            <?= ucfirst($order['order_status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?= base_url('customer/order/' . $order['id']) ?>" class="btn btn-sm btn-info">Detail</a>
                                        <?php if ($order['order_status'] === 'confirmed'): ?>
                                            <a href="<?= base_url('customer/order/' . $order['id'] . '/download-pdf') ?>" class="btn btn-sm btn-warning">PDF</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Belum ada pesanan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Links -->
    <div class="row mt-4">
        <div class="col-md-12">
            <h4 class="mb-3">Menu Pelanggan</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card">

                <div class="card-body text-center">
                    <h5 class="card-title">Lihat Paket</h5>
                    <p class="card-text">Lihat daftar paket fieldtrip tersedia</p>
                    <a href="<?= base_url('pages/packages') ?>" class="btn btn-primary btn-sm">Lihat</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">Lihat Wahana</h5>
                    <p class="card-text">Lihat daftar wahana tambahan</p>
                    <a href="<?= base_url('pages/attractions') ?>" class="btn btn-primary btn-sm">Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">Riwayat Pesanan</h5>
                    <p class="card-text">Lihat riwayat semua pesanan</p>
                    <a href="<?= base_url('customer/order/history') ?>" class="btn btn-primary btn-sm">Lihat</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
