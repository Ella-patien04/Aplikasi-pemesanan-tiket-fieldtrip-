<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3 d-inline">Dashboard Pengelola</h1>
            <div class="float-end">
                <a href="<?= base_url('auth/logout') ?>" class="btn btn-sm btn-danger">Logout</a>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6>Total Wahana</h6>
                    <h2><?= $total_attractions ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6>Wahana Aktif</h6>
                    <h2><?= $active_attractions ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6>Wahana Tidak Aktif</h6>
                    <h2><?= $inactive_attractions ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title">Kelola Wahana</h5>
                    <p class="card-text">Ubah status aktif / tidak aktif untuk setiap wahana.</p>
                    <a href="<?= base_url('pengelola/attractions') ?>" class="btn btn-primary btn-sm">Lihat Wahana</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><i class="fas fa-clipboard-list me-2"></i>Kelola Pesanan</h5>
                    <p class="card-text">Kelola pesanan fieldtrip yang telah melakukan pembayaran DP.</p>
                    <a href="<?= base_url('pengelola/orders') ?>" class="btn btn-primary btn-sm">Lihat Pesanan</a>
                </div>
            </div>
        </div>
    </div>

</div>
<?= $this->endSection() ?>
