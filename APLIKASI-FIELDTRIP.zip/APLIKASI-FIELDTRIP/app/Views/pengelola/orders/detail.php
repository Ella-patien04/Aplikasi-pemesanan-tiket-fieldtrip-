<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-4">
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> <?= esc(session()->getFlashdata('success')) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> <?= esc(session()->getFlashdata('error')) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Detail Pesanan #<?= esc($order['id']) ?></h2>
        <a class="btn btn-outline-secondary" href="<?= base_url('pengelola/orders') ?>">Kembali</a>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Data Pemesan</h5>
                    <p class="mb-1"><strong>Nama Sekolah:</strong> <?= esc($order['school_name'] ?? '') ?></p>
                    <p class="mb-1"><strong>Nama Pemesan:</strong> <?= esc($order['booker_name'] ?? '') ?></p>
                    <p class="mb-1"><strong>Telepon:</strong> <?= esc($order['phone'] ?? '') ?></p>
                    <p class="mb-1"><strong>Tanggal Kunjungan:</strong> <?= esc($order['visit_date'] ?? '') ?></p>
                    <?php if (!empty($order['package']['name'])): ?>
                        <p class="mb-0"><strong>Paket:</strong> <?= esc($order['package']['name']) ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Status</h5>
                    <p class="mb-1"><strong>Pembayaran:</strong> <?= esc($order['payment_status'] ?? '') ?></p>
                    <?php
                        $pelaksanaan = $order['fieldtrip_status'] ?? 'pending';
                        $badgeClass = match($pelaksanaan) {
                            'pending' => 'bg-secondary',
                            'sedang_dilaksanakan' => 'bg-warning',
                            'selesai' => 'bg-success',
                            default => 'bg-secondary'
                        };
                    ?>
                    <p class="mb-0"><strong>Pelaksanaan:</strong> <span class="badge <?= $badgeClass ?>"><?= esc($pelaksanaan) ?></span></p>
                </div>
            </div>
        </div>


        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Ringkasan Peserta</h5>
                    <p class="mb-1"><strong>Peserta:</strong> <?= esc($order['num_participants'] ?? 0) ?> orang</p>
                    <p class="mb-1"><strong>Wali:</strong> <?= esc($order['num_guardians'] ?? 0) ?> orang</p>
                    <p class="mb-1"><strong>Guru:</strong> <?= esc($order['num_teachers'] ?? 0) ?> orang</p>
                    <p class="mb-0"><strong>Total:</strong> <?= (int)($order['num_participants'] ?? 0) + (int)($order['num_guardians'] ?? 0) + (int)($order['num_teachers'] ?? 0) ?> orang</p>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Semua Data Pesanan</h5>
                    <div class="row g-2">
                        <div class="col-md-4"><div class="p-2 border rounded"><small class="text-muted d-block">Total Harga</small><strong>Rp <?= number_format((float)($order['total_price'] ?? 0), 0, ',', '.') ?></strong></div></div>
                        <div class="col-md-4"><div class="p-2 border rounded"><small class="text-muted d-block">DP</small><strong>Rp <?= number_format((float)($order['dp_amount'] ?? 0), 0, ',', '.') ?></strong></div></div>
                        <div class="col-md-4"><div class="p-2 border rounded"><small class="text-muted d-block">Sisa</small><strong>Rp <?= number_format((float)($order['total_price'] ?? 0) - (float)($order['dp_amount'] ?? 0), 0, ',', '.') ?></strong></div></div>
                    </div>

                    <?php if (!empty($order['attractions'])): ?>
                        <div class="mt-3">
                            <h6 class="mb-2">Wahana Tambahan</h6>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Nama</th>
                                            <th>Harga / Peserta</th>
                                            <th>Jumlah Peserta</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($order['attractions'] as $item): ?>
                                            <tr>
                                                <td><?= esc($item['attraction_name'] ?? '') ?></td>
                                                <td>Rp <?= number_format($item['price_at_booking'] ?? 0, 0, ',', '.') ?></td>
                                                <td><?= number_format($item['quantity'] ?? 0) ?> peserta</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($order['proof_payment_image'])): ?>
                        <div class="mt-3">
                            <h6 class="mb-2">Bukti Pembayaran</h6>
                            <a class="btn btn-sm btn-outline-secondary" href="<?= base_url($order['proof_payment_image']) ?>" target="_blank">Lihat Bukti</a>
                        </div>
                    <?php endif; ?>

                    <?php
                        $canFinish = (($order['payment_status'] ?? '') === 'dp_paid')
                            && (($order['order_status'] ?? '') === 'pending')
                            && (($order['fieldtrip_status'] ?? 'pending') !== 'selesai');
                    ?>
                    <?php if ($canFinish): ?>
                        <div class="mt-4">
                            <form action="<?= base_url('pengelola/orders/update-status/' . $order['id']) ?>" method="POST">
                                <?= csrf_field() ?>
                                <input type="hidden" name="fieldtrip_status" value="selesai" />
                                <button type="submit" class="btn btn-success">
                                    Selesaikan Fieldtrip
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>


    </div>
</div>
<?= $this->endSection() ?>



