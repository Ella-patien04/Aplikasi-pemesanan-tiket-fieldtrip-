<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Kelola Pesanan (Pengelola)</h2>
        <a class="btn btn-outline-secondary" href="<?= base_url('pengelola/dashboard') ?>">Kembali</a>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
            <tr>
                <th>Nama Sekolah</th>
                <th>Tanggal Kunjungan</th>
                <th>Jumlah Peserta</th>
                <th>Status Pembayaran</th>
                <th>Status Pelaksanaan</th>
                <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php if (empty($orders)): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted">Belum ada pesanan</td>
                </tr>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <?php
                        $pelaksanaan = $order['fieldtrip_status'] ?? 'pending';

                        $jumlahPeserta = (int)($order['num_participants'] ?? 0) + (int)($order['num_guardians'] ?? 0) + (int)($order['num_teachers'] ?? 0);
                    ?>
                    <tr>
                        <td><?= esc($order['school_name'] ?? '') ?></td>
                        <td><?= esc($order['visit_date'] ?? '') ?></td>
                        <td><?= esc($jumlahPeserta) ?> orang</td>
                        <td><?= esc($order['payment_status'] ?? '') ?></td>
                        <td>
                            <?php if (($order['payment_status'] ?? '') === 'dp_paid' && $pelaksanaan !== 'selesai'): ?>
                                <form action="<?= base_url('pengelola/orders/update-status/' . $order['id']) ?>" method="POST" class="m-0">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="fieldtrip_status" value="selesai" />
                                    <button type="submit" class="btn btn-sm btn-success">
                                        Selesaikan Fieldtrip
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?= esc($pelaksanaan) ?></span>
                            <?php endif; ?>
                        </td>


                        <td>
                            <a class="btn btn-sm btn-outline-primary" href="<?= base_url('pengelola/orders/detail/' . $order['id']) ?>">Detail</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>

