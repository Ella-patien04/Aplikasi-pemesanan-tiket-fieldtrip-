<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row mb-4">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h3">Detail Tanggal Kunjungan</h1>
                <p class="text-muted"><?= date('d F Y', strtotime($visit_date)) ?></p>
            </div>
            <a href="<?= base_url('pengelola/reports/schedule') ?>" class="btn btn-outline-secondary">Kembali</a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5>Informasi Tanggal</h5>
                    <p><strong>Tanggal:</strong> <?= date('d F Y', strtotime($visit_date)) ?></p>
                    <p><strong>Total Pesanan:</strong> <?= $total_orders ?></p>
                    <p><strong>Total Peserta:</strong> <?= $total_people ?></p>
                    <p><strong>Kuota Tersisa:</strong> <?= $available_capacity ?> orang</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <h4>Daftar Pesanan Terkonfirmasi</h4>
            <div class="card shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Sekolah</th>
                                <th>Pemesan</th>
                                <th>Peserta</th>
                                <th>Wali</th>
                                <th>Guru</th>
                                <th>Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($orders)): ?>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>#<?= $order['id'] ?></td>
                                        <td><?= esc($order['school_name']) ?></td>
                                        <td><?= esc($order['booker_name']) ?></td>
                                        <td><?= $order['num_participants'] ?></td>
                                        <td><?= $order['num_guardians'] ?></td>
                                        <td><?= $order['num_teachers'] ?></td>
                                        <td><?= $order['num_participants'] + $order['num_guardians'] + $order['num_teachers'] ?></td>
                                        <td>
                                            <a href="<?= base_url('admin/orders/detail/' . $order['id']) ?>" class="btn btn-sm btn-info">Detail</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Tidak ada pesanan untuk tanggal ini.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
