<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3">Laporan Pesanan per Tanggal</h1>
            <p class="text-muted">Daftar tanggal kunjungan beserta jumlah pesanan terkonfirmasi.</p>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tanggal</th>
                        <th>Pesanan Dikonfirmasi</th>
                        <th>Total Peserta</th>
                        <th>Kuota Tersisa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($dateReports)): ?>
                        <?php foreach ($dateReports as $index => $report): ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td><?= date('d F Y', strtotime($report['visit_date'])) ?></td>
                                <td>
                                    <span class="badge bg-info"><?= $report['confirmed_orders'] ?></span>
                                </td>
                                <td><?= $report['total_people'] ?></td>
                                <td><?= $report['available_capacity'] ?> orang</td>
                                <td>
                                    <a href="<?= base_url('pengelola/reports/schedule/' . $report['visit_date']) ?>" class="btn btn-sm btn-info">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">Belum ada data tanggal kunjungan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
