<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3">Kelola Status Wahana</h1>
            <p class="text-muted">Ubah status aktif atau nonaktif untuk setiap wahana edukasi.</p>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Wahana</th>
                        <th>Harga</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($attractions)): ?>
                        <?php foreach ($attractions as $attraction): ?>
                            <tr>
                                <td><?= $attraction['id'] ?></td>
                                <td><?= esc($attraction['name']) ?></td>
                                <td>Rp <?= number_format($attraction['price'], 0, ',', '.') ?></td>
                                <td>
                                    <span class="badge bg-<?= $attraction['is_active'] ? 'success' : 'secondary' ?>">
                                        <?= $attraction['is_active'] ? 'Aktif' : 'Nonaktif' ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="<?= base_url('pengelola/attractions/update-status/' . $attraction['id']) ?>" class="btn btn-sm btn-warning">
                                        Ubah Status
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Belum ada wahana.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
