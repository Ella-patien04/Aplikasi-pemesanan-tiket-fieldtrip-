<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h1 class="h3">Kelola Informasi</h1>
        <p class="text-muted">Halaman ini digunakan untuk mengelola konten informasi umum dan pengumuman.</p>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <p>Konten informasi belum tersedia di versi ini. Halaman ini sudah terhubung ke sidebar sebagai bagian dari tata letak dashboard.</p>
    </div>
</div>
<?= $this->endSection() ?>
