<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h1 class="h3">Kelola Paket</h1>
        <p class="text-muted">Kelola paket wisata untuk pengguna pengelola.</p>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <p>Halaman manajemen paket belum tersedia untuk role pengelola. Gunakan halaman ini sebagai titik awal untuk implementasi kelola paket.</p>
    </div>
</div>
<?= $this->endSection() ?>
