<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-2">
    <h2 class="h4 mb-3">Edit Pengguna</h2>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> <?= esc(session()->getFlashdata('success')) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> <?= esc(session()->getFlashdata('error')) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($errors = session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> Terdapat kesalahan:
            <ul class="mb-0 mt-2">
                <?php foreach ($errors as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach; ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="post" action="<?= base_url('admin/users/update/' . $pengguna['id']) ?>">
                <?= csrf_field() ?>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Nama</label>
                        <input
                            type="text"
                            name="name"
                            class="form-control"
                            value="<?= esc(old('name') ?? $pengguna['name'] ?? '') ?>"
                            required
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Email</label>
                        <input
                            type="email"
                            name="email"
                            class="form-control"
                            value="<?= esc(old('email') ?? $pengguna['email'] ?? '') ?>"
                            required
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">No HP</label>
                        <input
                            type="text"
                            name="phone"
                            class="form-control"
                            value="<?= esc(old('phone') ?? $pengguna['phone'] ?? '') ?>"
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Role/Level</label>
                        <select name="role" class="form-select" required>
                            <?php
                            $roles = ['admin', 'customer', 'pengelola', 'owner'];
                            $selectedRole = old('role') ?? ($pengguna['role'] ?? 'customer');
                            foreach ($roles as $r):
                            ?>
                                <option value="<?= esc($r) ?>" <?= ((string)$selectedRole === (string)$r) ? 'selected' : '' ?>>
                                    <?= esc($r) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Status Aktif</label>
                        <select name="is_active" class="form-select" required>
                            <?php
                            $selected = old('is_active') ?? ($pengguna['is_active'] ?? 1);
                            ?>
                            <option value="1" <?= ((string)$selected === '1') ? 'selected' : '' ?>>Aktif</option>
                            <option value="0" <?= ((string)$selected === '0') ? 'selected' : '' ?>>Nonaktif</option>
                        </select>
                    </div>

                    <div class="col-md-6 d-flex align-items-end">
                        <div class="w-100">
                            <a class="btn btn-outline-secondary w-100" href="<?= base_url('admin/users') ?>">Kembali</a>
                        </div>
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Simpan Perubahan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

