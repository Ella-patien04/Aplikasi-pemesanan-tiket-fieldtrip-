<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="row mb-4 align-items-center">
        <div class="col-12 col-md-8">
            <h1 class="h3 section-title d-inline mb-0">
                <i class="fas fa-tachometer-alt gold-accent me-2"></i>
                Dashboard Admin
            </h1>
            <div class="dashboard-subtitle mt-1">Sistem manajemen premium dengan kontrol penuh.</div>
        </div>
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div>
                            
                        <div class="rounded-circle" style="width:42px;height:42px; background: rgba(198, 225, 248, 0.88); display:flex; align-items:center; justify-content:center; color:#F4A300; box-shadow: 0 10px 20px rgba(186, 225, 243, 0.96);">
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Statistics Cards (top) -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="premium-card card border-0 h-100 stat-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="small text-uppercase" style="font-weight:900; color: rgba(10,10,94,0.65); letter-spacing:0.3px;">Total Packages</div>
                            <div class="h2 mb-0" style="color:#0A0A5E; font-weight:900;"><?= $total_packages ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-box-open"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-lg-3">
            <div class="premium-card card border-0 h-100 stat-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="small text-uppercase" style="font-weight:900; color: rgba(10,10,94,0.65); letter-spacing:0.3px;">Total Attractions</div>
                            <div class="h2 mb-0" style="color:#0A0A5E; font-weight:900;"><?= $total_attractions ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-water"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-lg-3">
            <div class="premium-card card border-0 h-100 stat-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="small text-uppercase" style="font-weight:900; color: rgba(10,10,94,0.65); letter-spacing:0.3px;">Pending Orders</div>
                            <div class="h2 mb-0" style="color:#F4A300; font-weight:900;"><?= $pending_orders ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-hourglass-half"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-lg-3">
            <div class="premium-card card border-0 h-100 stat-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="small text-uppercase" style="font-weight:900; color: rgba(10,10,94,0.65); letter-spacing:0.3px;">Pending Payments</div>
                            <div class="h2 mb-0" style="color:#0B3BEE; font-weight:900;">(<?= $pending_payments ?>)</div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-receipt"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Management Cards -->
    <div class="row mb-4">
        <div class="col-12">
            <h3 class="mb-0 dashboard-title">
                <i class="fas fa-layer-group gold-accent me-2"></i>
                Menu Manajemen
            </h3>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-12 col-md-6 col-lg-4">
            <div class="premium-card card border-0 management-card h-100">
                <div class="card-body">
                    <div class="management-card__inner">
                        <div class="management-card__top">
                            <div class="management-card__text">
                                <div class="management-card__label" style="color: rgba(28, 8, 114, 0.9);">Paket Fieldtrip</div>
                                <p class="management-card__title">Kelola paket yang ditawarkan</p>
                            </div>
                            <div class="management-card__icon rounded-3" style="background: rgba(244,163,0,0.18);">
                                <i class="fas fa-box-open"></i>
                            </div>
                        </div>
                        <div class="management-card__action">
                            <a href="<?= base_url('admin/packages') ?>" class="btn" style="background: rgba(10,10,94,0.06); color:#0A0A5E; border:1px solid rgba(10,10,94,0.12); border-radius:10px; font-weight:800;">
                                Lihat
                                <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-4">
            <div class="premium-card card border-0 management-card h-100">
                <div class="card-body">
                    <div class="management-card__inner">
                        <div class="management-card__top">
                            <div class="management-card__text">
                                <div class="management-card__label">Wahana Satuan</div>
                                <p class="management-card__title">Kelola daftar wahana satuan</p>
                            </div>
                            <div class="management-card__icon rounded-3" style="background: rgba(244,163,0,0.18);">
                                <i class="fas fa-water"></i>
                            </div>
                        </div>
                        <div class="management-card__action">
                            <a href="<?= base_url('admin/attractions') ?>" class="btn" style="background: rgba(10,10,94,0.06); color:#0A0A5E; border:1px solid rgba(10,10,94,0.12); border-radius:10px; font-weight:800;">
                                Lihat
                                <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-4">
            <div class="premium-card card border-0 management-card h-100">
                <div class="card-body">
                    <div class="management-card__inner">
                        <div class="management-card__top">
                            <div class="management-card__text">
                                <div class="management-card__label">Kelola Pesanan</div>
                                <p class="management-card__title">Lihat dan kelola pesanan customer</p>
                            </div>
                            <div class="management-card__icon rounded-3" style="background: rgba(244,163,0,0.18);">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                        </div>
                        <div class="management-card__action">
                            <a href="<?= base_url('admin/orders') ?>" class="btn" style="background: rgba(10,10,94,0.06); color:#0A0A5E; border:1px solid rgba(10,10,94,0.12); border-radius:10px; font-weight:800;">
                                Lihat
                                <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-4">
            <div class="premium-card card border-0 management-card h-100">
                <div class="card-body">
                    <div class="management-card__inner">
                        <div class="management-card__top">
                            <div class="management-card__text">
                                <div class="management-card__label">Pesanan Pending</div>
                                <p class="management-card__title">Verifikasi &amp; konfirmasi pesanan</p>
                            </div>
                            <div class="management-card__icon rounded-3" style="background: rgba(244,163,0,0.18);">
                                <i class="fas fa-hourglass-half"></i>
                            </div>
                        </div>
                        <div class="management-card__action">
                            <a href="<?= base_url('admin/orders/pending') ?>" class="btn" style="background: rgba(10,10,94,0.06); color:#0A0A5E; border:1px solid rgba(10,10,94,0.12); border-radius:10px; font-weight:800;">
                                Lihat
                                <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-4">
            <div class="premium-card card border-0 management-card h-100">
                <div class="card-body">
                    <div class="management-card__inner">
                        <div class="management-card__top">
                            <div class="management-card__text">
                                <div class="management-card__label">Laporan</div>
                                <p class="management-card__title">Lihat laporan penjualan</p>
                            </div>
                            <div class="management-card__icon rounded-3" style="background: rgba(244,163,0,0.18);">
                                <i class="fas fa-chart-line"></i>
                            </div>
                        </div>
                        <div class="management-card__action">
                            <a href="<?= base_url('admin/reports/sales') ?>" class="btn" style="background: rgba(10,10,94,0.06); color:#0A0A5E; border:1px solid rgba(10,10,94,0.12); border-radius:10px; font-weight:800;">
                                Lihat
                                <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?= $this->endSection() ?>
