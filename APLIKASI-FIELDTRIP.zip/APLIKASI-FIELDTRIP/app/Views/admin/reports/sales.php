<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3">Laporan Penjualan</h1>
            <p class="text-muted">Laporan lengkap penjualan dan pesanan fieldtrip.</p>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Sekolah</th>
                        <th>Paket</th>
                        <th>Peserta</th>
                        <th>Total Harga</th>
                        <th>Status Pembayaran</th>
                        <th>Tanggal Pesanan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($orders)): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= esc($order['school_name']) ?></td>
                                <td><?= esc($order['package']['name'] ?? 'N/A') ?></td>
                                <td><?= $order['num_participants'] ?> + <?= $order['num_guardians'] ?> + <?= $order['num_teachers'] ?></td>
                                <td>Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                <td>
                                    <span class="badge bg-<?= in_array($order['payment_status'], ['paid', 'dp_paid']) ? 'success' : 'warning' ?>">
                                        <?= ucfirst(str_replace('_', ' ', $order['payment_status'])) ?>
                                    </span>
                                </td>
                                <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                                <td>
                                    <a href="<?= base_url('admin/orders/detail/' . $order['id']) ?>" class="btn btn-sm btn-info">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">Tidak ada data pesanan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
