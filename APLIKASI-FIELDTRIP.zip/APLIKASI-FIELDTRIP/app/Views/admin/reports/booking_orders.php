<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<?php
  // expected variables:
  // $pendingOrders, $successOrders, $startDate, $endDate
  // $activeTab: 'pending'|'success'

  $printQuery = http_build_query(array_filter([
      'start_date' => $startDate,
      'end_date' => $endDate,
  ]));

  $activeTab = $activeTab ?? 'pending';
?>

<div class="container-fluid py-4">
  <div class="row mb-3">
    <div class="col-md-12">
      <h1 class="h3 mb-1">Laporan Pemesanan Tiket Field Trip</h1>
      <p class="text-muted mb-0">Pisahkan pesanan pending dan pesanan sukses (DP/Lunas).</p>
    </div>
  </div>

  <div class="card shadow-sm border-0 mb-4">
    <div class="card-body">
      <form method="get" action="<?= base_url('admin/reports/booking') ?>" class="row g-2 align-items-end">
        <div class="col-md-4">
          <label class="form-label">Start Date</label>
          <input type="date" name="start_date" class="form-control" value="<?= esc($startDate) ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">End Date</label>
          <input type="date" name="end_date" class="form-control" value="<?= esc($endDate) ?>">
        </div>
        <div class="col-md-4 d-flex gap-2 justify-content-md-end">
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-filter"></i> Terapkan
          </button>
          <a class="btn btn-outline-secondary" target="_blank" rel="noopener"
             href="<?= base_url('admin/reports/booking/print') . ($printQuery ? '?' . $printQuery : '') ?>">
            <i class="fas fa-print"></i> Cetak / PDF
          </a>
        </div>
      </form>
    </div>
  </div>

  <ul class="nav nav-tabs" id="bookingReportTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <button
        class="nav-link <?= $activeTab === 'pending' ? 'active' : '' ?>"
        id="pending-tab"
        data-bs-toggle="tab"
        data-bs-target="#pending"
        type="button"
        role="tab"
        aria-controls="pending"
        aria-selected="<?= $activeTab === 'pending' ? 'true' : 'false' ?>"
      >
        Laporan 1: Pesanan Pending
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button
        class="nav-link <?= $activeTab === 'success' ? 'active' : '' ?>"
        id="success-tab"
        data-bs-toggle="tab"
        data-bs-target="#success"
        type="button"
        role="tab"
        aria-controls="success"
        aria-selected="<?= $activeTab === 'success' ? 'true' : 'false' ?>"
      >
        Laporan 2: Pesanan Sukses (DP/Lunas)
      </button>
    </li>
  </ul>

  <div class="tab-content" id="bookingReportTabsContent">
    <!-- PENDING TAB -->
    <div class="tab-pane fade <?= $activeTab === 'pending' ? 'show active' : '' ?>" id="pending" role="tabpanel" aria-labelledby="pending-tab">
      <div class="table-responsive p-3">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>ID/Nota</th>
              <th>Tanggal Pesanan</th>
              <th>Nama Sekolah/Instansi</th>
              <th>Nama Pemesan</th>
              <th>Jumlah Peserta/Tiket</th>
              <th>Total Biaya</th>
              <th>Jumlah yang Sudah Dibayar</th>
              <th>Sisa Tagihan</th>
              <th>Status Pembayaran</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($pendingOrders)): ?>
              <?php foreach ($pendingOrders as $o): ?>
                <?php
                  $jumlahPeserta = (int)$o['num_participants'] + (int)$o['num_guardians'] + (int)($o['num_teachers'] ?? 0);
                  $total = (float)$o['total_price'];
                  $paid = (float)$o['dp_amount']; // for pending, typically 0
                  $sisa = $total - $paid;
                ?>
                <tr>
                  <td><?= esc($o['id']) ?></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= esc($o['school_name']) ?></td>
                  <td><?= esc($o['booker_name']) ?></td>
                  <td><?= $jumlahPeserta ?></td>
                  <td>Rp <?= number_format($total, 0, ',', '.') ?></td>
                  <td>Rp <?= number_format($paid, 0, ',', '.') ?></td>
                  <td>Rp <?= number_format($sisa, 0, ',', '.') ?></td>
                  <td>
                    <span class="badge bg-warning text-dark">Pending</span>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="9" class="text-center text-muted">Tidak ada pesanan pending.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- SUCCESS TAB -->
    <div class="tab-pane fade <?= $activeTab === 'success' ? 'show active' : '' ?>" id="success" role="tabpanel" aria-labelledby="success-tab">
      <div class="table-responsive p-3">
        <table class="table table-hover align-middle">
          <thead>
            <tr>
              <th>ID/Nota</th>
              <th>Tanggal Pesanan</th>
              <th>Nama Sekolah/Instansi</th>
              <th>Nama Pemesan</th>
              <th>Jumlah Peserta/Tiket</th>
              <th>Total Biaya</th>
              <th>Jumlah yang Sudah Dibayar</th>
              <th>Sisa Tagihan</th>
              <th>Status Pembayaran</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($successOrders)): ?>
              <?php foreach ($successOrders as $o): ?>
                <?php
                  $jumlahPeserta = (int)$o['num_participants'] + (int)$o['num_guardians'] + (int)($o['num_teachers'] ?? 0);
                  $total = (float)$o['total_price'];
                  $paid = (float)$o['dp_amount'];

                  // If payment_status == paid, treat as fully paid
                  if (($o['payment_status'] ?? '') === 'paid') {
                    $paid = $total;
                  }

                  $sisa = $total - $paid;

                  $status = (string)($o['payment_status'] ?? '');
                  $badgeHtml = match($status) {
                    'dp_paid' => '<span class="badge bg-primary">DP</span>',
                    'paid' => '<span class="badge bg-success">Lunas</span>',
                    default => '<span class="badge bg-secondary">'.htmlspecialchars($status).'</span>',
                  };
                ?>
                <tr>
                  <td><?= esc($o['id']) ?></td>
                  <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= esc($o['school_name']) ?></td>
                  <td><?= esc($o['booker_name']) ?></td>
                  <td><?= $jumlahPeserta ?></td>
                  <td>Rp <?= number_format($total, 0, ',', '.') ?></td>
                  <td>Rp <?= number_format($paid, 0, ',', '.') ?></td>
                  <td>Rp <?= number_format($sisa, 0, ',', '.') ?></td>
                  <td><?= $badgeHtml ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="9" class="text-center text-muted">Tidak ada pesanan DP/Lunas.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<style>
  @media print {
    .nav-tabs, .card-body > form, .table-responsive { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .nav-tabs { display: none !important; }
    .card { display: none !important; }
    a { display: none !important; }
  }
</style>

<?= $this->endSection() ?>

