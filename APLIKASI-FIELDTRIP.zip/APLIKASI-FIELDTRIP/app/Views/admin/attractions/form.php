<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h1><?= isset($attraction) ? 'Edit Wahana' : 'Tambah Wahana' ?></h1>
                    <form action="<?= isset($attraction) ? base_url('admin/attractions/update/' . $attraction['id']) : base_url('admin/attractions/save') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session()->getFlashdata('error') ?>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($errors) && ! empty($errors)): ?>
                            <div class="alert alert-danger" role="alert">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $field => $message): ?>
                                        <li><?= esc($message) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label">Nama Wahana</label>
                            <input type="text" class="form-control" name="name" value="<?= old('name', $attraction['name'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea class="form-control" name="description" rows="4" required><?= old('description', $attraction['description'] ?? '') ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Harga</label>
                            <input type="number" class="form-control" name="price" value="<?= old('price', $attraction['price'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gambar Wahana</label>
                            <input type="file" class="form-control" name="image">
                        </div>
                        <button class="btn btn-primary"><?= isset($attraction) ? 'Perbarui Wahana' : 'Simpan Wahana' ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
