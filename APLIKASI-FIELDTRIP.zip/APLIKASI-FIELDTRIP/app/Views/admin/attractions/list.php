<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="d-flex justify-content-between mb-4">
        <div>
            <h1 class="h3">Daftar Wahana</h1>
            <p class="text-muted">Kelola wahana edukasi yang tersedia untuk fieldtrip.</p>
        </div>
        <a href="<?= base_url('admin/attractions/add') ?>" class="btn btn-primary">Tambah Wahana</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Wahana</th>
                        <th>Harga</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($attractions)): ?>
                        <?php foreach ($attractions as $attraction): ?>
                            <tr>
                                <td><?= $attraction['id'] ?></td>
                                <td><?= esc($attraction['name']) ?></td>
                                <td>Rp <?= number_format($attraction['price'], 0, ',', '.') ?></td>
                                <td><?= $attraction['is_active'] ? 'Aktif' : 'Nonaktif' ?></td>
                                <td>
                                    <a href="<?= base_url('admin/attractions/edit/' . $attraction['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('admin/attractions/delete/' . $attraction['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus wahana ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Belum ada wahana.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
