<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="d-flex justify-content-between mb-4">
        <div>
            <h1 class="h3">Daftar Paket</h1>
            <p class="text-muted">Kelola paket fieldtrip yang ditawarkan kepada pelanggan.</p>
        </div>
        <a href="<?= base_url('admin/packages/add') ?>" class="btn btn-primary">Tambah Paket</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Paket</th>
                        <th>Harga</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($packages)): ?>
                        <?php foreach ($packages as $package): ?>
                            <tr>
                                <td><?= $package['id'] ?></td>
                                <td><?= esc($package['name']) ?></td>
                                <td>Rp <?= number_format($package['price'], 0, ',', '.') ?></td>
                                <td><?= $package['is_active'] ? 'Aktif' : 'Nonaktif' ?></td>
                                <td>
                                    <a href="<?= base_url('admin/packages/edit/' . $package['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('admin/packages/delete/' . $package['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus paket ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Belum ada paket.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
