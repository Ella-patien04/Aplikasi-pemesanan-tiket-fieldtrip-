<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h1><?= isset($package) ? 'Edit Paket' : 'Tambah Paket' ?></h1>
                    <?php
                        $facilitiesValue = old('facilities');
                        if ($facilitiesValue === null && isset($package['facilities'])) {
                            if (is_array($package['facilities'])) {
                                $facilitiesValue = implode(',', $package['facilities']);
                            } elseif (is_object($package['facilities'])) {
                                $facilitiesValue = implode(',', (array) $package['facilities']);
                            } else {
                                $facilitiesValue = (string) $package['facilities'];
                            }
                        }
                    ?>
                    <form action="<?= isset($package) ? base_url('admin/packages/update/' . $package['id']) : base_url('admin/packages/save') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session()->getFlashdata('error') ?>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($errors) && ! empty($errors)): ?>
                            <div class="alert alert-danger" role="alert">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $field => $message): ?>
                                        <li><?= esc($message) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label">Nama Paket</label>
                            <input type="text" class="form-control" name="name" value="<?= old('name', $package['name'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea class="form-control" name="description" rows="4" required><?= old('description', $package['description'] ?? '') ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Harga</label>
                            <input type="number" class="form-control" name="price" value="<?= old('price', $package['price'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Fasilitas (pisahkan dengan koma)</label>
                            <input type="text" class="form-control" name="facilities" value="<?= esc($facilitiesValue ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gambar Paket</label>
                            <input type="file" class="form-control" name="image">
                        </div>
                        <button class="btn btn-primary"><?= isset($package) ? 'Perbarui Paket' : 'Simpan Paket' ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
