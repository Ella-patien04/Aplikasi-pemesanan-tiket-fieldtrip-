<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-4">
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> <?= esc(session()->getFlashdata('success')) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> <?= esc(session()->getFlashdata('error')) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Kelola Pesanan (Admin)</h2>
        <a class="btn btn-success" href="<?= base_url('admin/orders/create') ?>">Tambah Pesanan</a>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Nama Sekolah</th>
                    <th>Pemesan</th>
                    <th>Tanggal</th>
                    <th>Peserta</th>
                    <th>Status Fieldtrip</th>
                    <th>Status Pembayaran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr><td colspan="8" class="text-center text-muted">Belum ada pesanan</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= esc($order['id']) ?></td>
                            <td><?= esc($order['school_name']) ?></td>
                            <td><?= esc($order['booker_name']) ?></td>
                            <td><?= esc($order['visit_date']) ?></td>
                            <td><?= (int)$order['num_participants'] + (int)$order['num_guardians'] + (int)($order['num_teachers'] ?? 0) ?></td>
                            <td>
                                <?php
                                $st = $order['order_status'] ?? 'pending';
                                $badgeClass = match($st) {
                                    'pending' => 'bg-secondary',
                                    'confirmed' => 'bg-primary',
                                    'in_progress' => 'bg-warning',
                                    'completed' => 'bg-success',
                                    'cancelled' => 'bg-danger',
                                    default => 'bg-secondary'
                                };
                                ?>
                                <span class="badge <?= $badgeClass ?>"><?= esc($st) ?></span>
                            </td>
                            <td><?= esc($order['payment_status']) ?></td>
                            <td>
                                <div class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= base_url('admin/orders/detail/'.$order['id']) ?>">Detail</a>
                                    <a class="btn btn-sm btn-outline-secondary" href="<?= base_url('admin/orders/edit/'.$order['id']) ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="<?= base_url('admin/orders/delete/'.$order['id']) ?>" onclick="return confirm('Hapus pesanan ini?')">Hapus</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>

