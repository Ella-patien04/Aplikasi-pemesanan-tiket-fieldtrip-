<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="h3">Pesanan Pending</h1>
            <p class="text-muted">Verifikasi pembayaran dan konfirmasi pesanan pelajar.</p>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Sekolah</th>
                        <th>Total Harga</th>
                        <th>Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($orders)): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= esc($order['school_name']) ?></td>
                                <td>Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                <td><?= ucfirst(str_replace('_', ' ', $order['payment_status'])) ?></td>
                                <td>
                                    <a href="<?= base_url('admin/orders/detail/' . $order['id']) ?>" class="btn btn-sm btn-info">Detail</a>
                                    <a href="<?= base_url('admin/orders/verify-payment/' . $order['id']) ?>" class="btn btn-sm btn-success">Verifikasi</a>
                                    <form action="<?= base_url('admin/orders/confirm/' . $order['id']) ?>" method="post" class="d-inline-block">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-primary" onclick="return confirm('Konfirmasi pesanan ini?')">Konfirmasi</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Tidak ada pesanan pending.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
