<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('content') ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Detail Pesanan #<?= esc($order['id']) ?></h2>
        <a class="btn btn-outline-secondary" href="<?= base_url('admin/orders') ?>">Kembali</a>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Data Pemesan</h5>
                    <p class="mb-1"><strong>Nama Sekolah:</strong> <?= esc($order['school_name']) ?></p>
                    <p class="mb-1"><strong>Nama Pemesan:</strong> <?= esc($order['booker_name']) ?></p>
                    <p class="mb-1"><strong>Telepon:</strong> <?= esc($order['phone']) ?></p>
                    <p class="mb-1"><strong>Tanggal Kunjungan:</strong> <?= esc($order['visit_date']) ?></p>
                    <p class="mb-0"><strong>Paket:</strong> <?= esc($order['package']['name'] ?? '') ?></p>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Status</h5>
<?php

    $st = $order['order_status'] ?? 'pending';
    $badgeClass = match($st) {
        'pending' => 'bg-secondary',
        'confirmed' => 'bg-primary',
        'in_progress' => 'bg-warning',
        'completed' => 'bg-success',
        'cancelled' => 'bg-danger',
        default => 'bg-secondary'
    };
    ?>
    <p class="mb-2"><strong>Fieldtrip:</strong> <span class="badge <?= $badgeClass ?>"><?= esc($st) ?></span></p>
    <p class="mb-0"><strong>Pembayaran:</strong> <?= esc($order['payment_status']) ?></p>
</div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Detail Harga</h5>
                    <p class="mb-1"><strong>Total Harga:</strong> Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                    <p class="mb-1"><strong>DP:</strong> Rp <?= number_format($order['dp_amount'], 0, ',', '.') ?></p>
                    <p class="mb-0"><strong>Pelunasan:</strong> Rp <?= number_format(((float)$order['total_price'] - (float)$order['dp_amount']), 0, ',', '.') ?></p>
                </div>
            </div>
        </div>

        <!-- Update status pelaksanaan (fieldtrip_status) DIHAPUS dari sisi Admin -->
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Aksi Admin</h5>

                    <div class="d-flex gap-2 flex-wrap">
                        <a class="btn btn-outline-success" href="<?= base_url('admin/orders/verify-payment/' . $order['id']) ?>" onclick="return confirm('Verifikasi pembayaran untuk pesanan ini?')">Verifikasi Pembayaran</a>

                        <form action="<?= base_url('admin/orders/confirm/' . $order['id']) ?>" method="post" class="d-inline-block" onsubmit="return confirm('Konfirmasi pesanan ini?')">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-outline-warning">Konfirmasi Pesanan</button>
                        </form>

                        <a class="btn btn-outline-danger" href="<?= base_url('admin/orders/delete/' . $order['id']) ?>" onclick="return confirm('Hapus pesanan ini?')">Hapus Pesanan</a>
                    </div>
                    <p class="mt-3 mb-0 text-muted small">Admin tidak diperbolehkan mengubah status pelaksanaan fieldtrip.</p>
                </div>
            </div>
        </div>


        <?php if (!empty($order['attractions'])): ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Wahana Tambahan</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Nama</th>
                                        <th>Harga / Peserta</th>
                                        <th>Jumlah Peserta</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($order['attractions'] as $item): ?>
                                    <tr>
                                        <td><?= esc($item['attraction_name'] ?? '') ?></td>
                                        <td>Rp <?= number_format($item['price_at_booking'] ?? 0, 0, ',', '.') ?></td>
                                        <td><?= number_format($item['quantity'] ?? 0) ?> peserta</td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>



