<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h1 class="mb-3">Tentang Fieldtrip Booking</h1>
                    <p>Fieldtrip Booking adalah sistem pemesanan fieldtrip untuk sekolah yang dirancang untuk memudahkan manajemen paket, tanggal kunjungan, wahana, dan pembayaran.</p>
                    <p>Pengelola dapat membuat paket, mengatur tanggal kunjungan, serta memantau status pesanan. Customer dapat memesan paket, mengunggah bukti pembayaran, dan melihat status pesanan secara real time.</p>
                    <p>Sistem ini mendukung role-based access control dengan peran: ADMIN, CUSTOMER, PENGELOLA, dan OWNER.</p>
                    <hr>
                    <h5>Visi</h5>
                    <p>Memberikan pengalaman fieldtrip yang lebih mudah, aman, dan transparan bagi sekolah dan operator wisata edukasi.</p>
                    <h5>Misi</h5>
                    <ul>
                        <li>Menyediakan informasi paket dan wahana secara cepat.</li>
                        <li>Mengotomatisasi alur pemesanan dan verifikasi pembayaran.</li>
                        <li>Menyajikan laporan penjualan dan persiapan tanggal kunjungan secara sistematis.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
