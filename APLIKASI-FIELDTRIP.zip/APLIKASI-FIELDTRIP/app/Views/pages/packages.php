<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1>Paket Fieldtrip</h1>
            <p class="text-muted">Temukan paket fieldtrip terbaik untuk rombongan sekolah Anda.</p>
        </div>
    </div>

    <div class="row g-4">
        <?php if (!empty($packages)): ?>
            <?php foreach ($packages as $package): ?>
                <?php $imageUrl = (!empty($package['image']) && file_exists(FCPATH . $package['image'])) ? base_url($package['image']) : 'https://via.placeholder.com/600x400?text=No+Image'; ?>
                <div class="col-sm-6 col-lg-4">
                    <div class="card h-100 shadow-sm border-0">
                        <img src="<?= esc($imageUrl) ?>" class="card-img-top object-fit-cover" alt="<?= esc($package['name']) ?>" style="height: 220px;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title mb-2"><?= esc($package['name']) ?></h5>
                            <p class="text-primary fw-semibold mb-3">Rp <?= number_format($package['price'], 0, ',', '.') ?></p>
                            <div class="mt-auto">
                                <a href="<?= base_url('pages/packages/' . $package['id']) ?>" class="btn btn-outline-primary w-100">Lihat Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-secondary">Belum ada paket fieldtrip tersedia.</div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>
