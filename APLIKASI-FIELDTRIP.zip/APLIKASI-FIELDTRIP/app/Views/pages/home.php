<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-5">
    <div class="row align-items-center mb-5">
        <div class="col-md-7">
            <h1 class="display-5">Selamat datang di Fieldtrip Booking</h1>
            <p class="lead text-muted">Sistem pemesanan fieldtrip sekolah dengan paket lengkap, wahana edukasi, dan tanggal kunjungan terkelola.</p>
            <a href="<?= base_url('pages/packages') ?>" class="btn btn-primary btn-lg me-2">Lihat Paket</a>
            <a href="<?= base_url('pages/attractions') ?>" class="btn btn-outline-light btn-lg">Lihat Wahana</a>
        </div>
        <div class="col-md-5">
            <div class="card shadow-sm border-0 bg-white p-4">
                <h5 class="mb-3">Tanggal Kunjungan</h5>
                <p class="text-muted">Pilih tanggal kunjungan bebas saat memesan. Sistem akan memeriksa kuota harian maksimum 350 peserta per tanggal.</p>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6 mb-4">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-body">
                    <h3 class="card-title">Paket Populer</h3>
                    <p class="text-muted">Pilih paket fieldtrip terbaik untuk rombongan sekolah Anda.</p>
                    <?php if (!empty($packages)): ?>
                        <?php foreach ($packages as $package): ?>
                            <div class="mb-3">
                                <h5><?= esc($package['name']) ?></h5>
                                <p class="mb-1 text-muted">Rp <?= number_format($package['price'], 0, ',', '.') ?></p>
                                <p><?= esc($package['description']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted">Tidak ada paket aktif tersedia.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-body">
                    <h3 class="card-title">Wahana Unggulan</h3>
                    <p class="text-muted">Wahana edukasi dan wisata yang siap dilengkapi dalam program fieldtrip Anda.</p>
                    <?php if (!empty($attractions)): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($attractions as $attraction): ?>
                                <li class="list-group-item border-0 px-0 py-2">
                                    <strong><?= esc($attraction['name']) ?></strong><br>
                                    <small class="text-muted">Rp <?= number_format($attraction['price'], 0, ',', '.') ?></small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">Tidak ada wahana aktif saat ini.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
