<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1>Galeri</h1>
            <p class="text-muted">Kilasan suasana fieldtrip dan kegiatan edukasi.</p>
        </div>
    </div>

    <div class="row g-4">
        <?php for ($i = 1; $i <= 6; $i++): ?>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0">
                    <img src="https://source.unsplash.com/collection/190727/800x600?sig=<?= $i ?>" class="card-img-top" alt="Galeri Fieldtrip">
                    <div class="card-body">
                        <h5 class="card-title">Momen Fieldtrip <?= $i ?></h5>
                        <p class="card-text text-muted">Foto kegiatan edukasi dan pengalaman siswa selama fieldtrip.</p>
                    </div>
                </div>
            </div>
        <?php endfor; ?>
    </div>
</div>
<?= $this->endSection() ?>
