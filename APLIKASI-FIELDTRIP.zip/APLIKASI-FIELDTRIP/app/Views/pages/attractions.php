<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1>Daftar Wahana</h1>
            <p class="text-muted">Wahana tambahan yang dapat dipilih untuk melengkapi fieldtrip sekolah.</p>
        </div>
    </div>

    <div class="row">
        <?php if (!empty($attractions)): ?>
            <?php foreach ($attractions as $attraction): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body">
                            <h5 class="card-title"><?= esc($attraction['name']) ?></h5>
                            <p class="text-muted mb-2">Rp <?= number_format($attraction['price'], 0, ',', '.') ?></p>
                            <p><?= esc($attraction['description']) ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-secondary">Belum ada wahana aktif saat ini.</div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>
