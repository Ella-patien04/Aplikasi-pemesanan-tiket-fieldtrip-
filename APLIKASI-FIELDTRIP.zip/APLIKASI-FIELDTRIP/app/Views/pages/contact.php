<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h1>Kontak Kami</h1>
                    <p class="text-muted">Silakan hubungi tim Fieldtrip Booking untuk pertanyaan atau bantuan pemesanan.</p>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="p-4 bg-light rounded-3">
                                <h5>Alamat</h5>
                                <p>Jl. Pendidikan No. 10, Bandung</p>
                                <h5>Telepon</h5>
                                <p>+62 821 1234 5678</p>
                                <h5>Email</h5>
                                <p><a href="mailto:info@fieldtripbooking.id">info@fieldtripbooking.id</a></p>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="p-4 bg-light rounded-3">
                                <h5>Form Kontak</h5>
                                <p class="text-muted">Isi data di bawah, kami akan segera membalas via email.</p>
                                <form>
                                    <div class="mb-3">
                                        <label class="form-label">Nama</label>
                                        <input type="text" class="form-control" placeholder="Nama Anda">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" placeholder="name@example.com">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Pesan</label>
                                        <textarea class="form-control" rows="4" placeholder="Tulis pesan Anda..."></textarea>
                                    </div>
                                    <button class="btn btn-primary">Kirim Pesan</button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
