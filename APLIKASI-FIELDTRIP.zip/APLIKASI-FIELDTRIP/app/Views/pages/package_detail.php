<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1><?= esc($package['name']) ?></h1>
            <p class="text-muted">Detail lengkap paket fieldtrip.</p>
        </div>
    </div>

    <?php $imageUrl = (!empty($package['image']) && file_exists(FCPATH . $package['image'])) ? base_url($package['image']) : 'https://via.placeholder.com/900x500?text=No+Image'; ?>

    <div class="row gy-4">
        <div class="col-lg-6">
            <div class="card shadow-sm border-0">
                <img src="<?= esc($imageUrl) ?>" class="card-img-top" alt="<?= esc($package['name']) ?>" style="object-fit: cover; min-height: 320px;">
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card shadow-sm border-0 p-4 h-100">
                <div class="mb-4">
                    <h2 class="h4">Rp <?= number_format($package['price'], 0, ',', '.') ?></h2>
                    <p class="text-muted mb-0">Harga per peserta</p>
                </div>

                <div class="mb-4">
                    <h5>Deskripsi Paket</h5>
                    <p><?= nl2br(esc($package['description'])) ?></p>
                </div>

                <?php
                    // Ensure facilities is an array (support both array and JSON string from database)
                    $facilitiesList = $package['facilities'] ?? [];
                    if (is_string($facilitiesList)) {
                        $decoded = json_decode($facilitiesList, true);
                        $facilitiesList = is_array($decoded) ? $decoded : [];
                    }
                ?>
                <?php if (!empty($facilitiesList)): ?>
                    <div class="mb-4">
                        <h5>Fasilitas yang Didapatkan</h5>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($facilitiesList as $facility): ?>
                                <li class="list-group-item px-0 border-0 ps-1"><i class="fas fa-check-circle text-success me-2"></i> <?= esc($facility) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="d-flex flex-column flex-sm-row gap-2">
                    <a href="<?= base_url('customer/order/form?package_id=' . $package['id']) ?>" class="btn btn-primary btn-lg w-100">Pesan Sekarang</a>
                    <a href="<?= base_url('pages/packages') ?>" class="btn btn-outline-secondary btn-lg w-100">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
