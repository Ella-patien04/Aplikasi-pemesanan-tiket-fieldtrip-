<?= $this->extend('layouts/app_auth') ?>

<?= $this->section('content') ?>
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Lupa Password</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?= session()->getFlashdata('error') ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?= session()->getFlashdata('success') ?>
                        </div>
                    <?php endif; ?>

                    <p>Masukkan email yang terdaftar. Jika akun ditemukan, kode OTP akan dikirim ke email Anda untuk mengatur ulang password.</p>

                    <form action="<?= base_url('auth/forgot-password') ?>" method="POST">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required value="<?= old('email') ?>">
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Kirim Kode OTP</button>
                    </form>

                    <div class="mt-3 text-center">
                        <a href="<?= base_url('auth/login') ?>">Kembali ke halaman login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
