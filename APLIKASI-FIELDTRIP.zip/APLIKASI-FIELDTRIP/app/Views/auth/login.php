<?= $this->extend('layouts/app_auth') ?>

<?= $this->section('content') ?>
<style>
    /* 
     * TEMBAK LANGSUNG KE HTML & BODY
     * Cara ini memaksa gambar muncul di lapisan paling dasar halaman web
     */
    html, body {
        background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('http://localhost:8080/images/login-bg.jpeg') !important;
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        background-attachment: fixed !important;
        min-height: 100vh !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    /* Hilangkan background dari semua elemen pembungkus bawaan template */
    .login-page, .wrapper, .main-layout, #app, main {
        background: transparent !important;
        background-color: transparent !important;
        min-height: 100vh;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px 12px;
    }

    .login-card {
        position: relative;
        width: 100%;
        max-width: 460px;
        border-radius: 14px;
        border: 0;
        background: rgba(6, 82, 150, 0.7) !important; /* warna biru medium transparan */
        box-shadow: 0 10px 35px rgba(0,0,0,0.35);
        padding: 26px;
        color: #ffffff;
        z-index: 2;
    }

    .login-welcome {
        margin-bottom: 18px;
        text-align: center;
    }

    .login-subtitle {
        font-size: 18px;
        font-weight: 700;
        margin-bottom: 8px;
        color: #ffffff;
    }

    .login-welcome-text {
        margin: 0;
        font-size: 14px;
        color: rgba(255,255,255,0.92);
    }

    .login-title {
        font-weight: 800;
        font-size: 24px;
        margin-bottom: 20px;
        text-align: center;
        letter-spacing: 0.2px;
    }

    .login-card .flash-error {
        margin-bottom: 16px;
        background: rgba(255, 99, 132, 0.2);
        border: 1px solid rgba(255, 99, 132, 0.35);
        color: #fff;
        border-radius: 10px;
        padding: 10px 12px;
    }

    .login-field {
        background: rgba(225, 235, 245, 0.9) !important;
        border: 0 !important;
        border-radius: 12px !important;
        padding: 12px 14px !important;
        color: #112233 !important;
        outline: none;
        width: 100%;
    }

    .login-field::placeholder {
        color: rgba(20, 40, 70, 0.55);
    }

    .login-label {
        display: block;
        font-size: 13px;
        margin-bottom: 6px;
        color: rgba(255,255,255,0.95);
        font-weight: 600;
    }

    .login-password-wrap {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .login-password-wrap input {
        flex: 1;
        background: rgba(225, 235, 245, 0.9) !important;
        border: 0 !important;
        border-radius: 12px !important;
        padding: 12px 14px !important;
        color: #112233 !important;
    }

    .login-password-wrap input::placeholder {
        color: rgba(20, 40, 70, 0.55);
    }

    .login-eye-btn {
        flex: 0 0 auto;
        border: 0;
        border-radius: 12px;
        padding: 0 14px;
        background: rgba(225, 235, 245, 0.9);
        cursor: pointer;
        height: 46px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .login-eye-btn i {
        color: rgba(20, 40, 70, 0.7);
        font-size: 18px;
    }

    .login-forgot {
        display: inline-block;
        margin-top: 10px;
        margin-bottom: 18px;
        color: #ffffff;
        font-weight: 700;
        text-decoration: none;
        font-size: 14px;
    }

    .login-forgot:hover {
        text-decoration: underline;
    }

    .login-btn {
        width: 100%;
        border: 0;
        border-radius: 12px;
        padding: 12px 14px;
        font-weight: 900;
        background: #ffffff !important;
        color: #16324a !important;
        box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        cursor: pointer;
    }

    .login-foot {
        margin-top: 18px;
        text-align: center;
        color: rgba(255,255,255,0.95);
        font-size: 13px;
    }

    .login-foot a {
        color: #ffffff;
        font-weight: 900;
        text-decoration: underline;
    }
</style>

<div class="login-page">
    <div class="login-card">
        <div class="login-welcome">
            <div class="login-subtitle">Selamat datang di Agro Edu Wisata Markaz Komobid</div>
            <p class="login-welcome-text">Silakan masuk untuk melanjutkan ke akun Anda.</p>
        </div>
        <div class="login-title">Login</div>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-error" role="alert">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('auth/do-login') ?>" method="POST">
            <?= csrf_field() ?>

            <div style="margin-bottom: 15px;">
                <label for="email" class="login-label">Email address</label>
                <input
                    type="email"
                    class="login-field"
                    id="email"
                    name="email"
                    required
                    placeholder="Masukkan email"
                    value="<?= old('email') ?>"
                >
            </div>

            <div style="margin-bottom: 15px;">
                <label for="password" class="login-label">Your Password</label>
                <div class="login-password-wrap">
                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        placeholder="Masukkan password"
                    >
                    <button type="button" class="login-eye-btn" id="togglePassword" aria-label="Tampilkan password">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <a class="login-forgot" href="<?= base_url('auth/forgot-password') ?>">Lupa Password?</a>

            <button type="submit" class="login-btn">Login</button>
        </form>

        <div class="login-foot">
            <div style="margin-top:14px;">
                <a href="<?= base_url('auth/register') ?>">Belum punya akun? Yuk Daftar sekarang!</a>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('togglePassword')?.addEventListener('click', function () {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
</script>
<?= $this->endSection() ?>