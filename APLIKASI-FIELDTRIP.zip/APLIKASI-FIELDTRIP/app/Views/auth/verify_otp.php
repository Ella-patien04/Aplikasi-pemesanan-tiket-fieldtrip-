<?= $this->extend('layouts/app_auth') ?>

<?= $this->section('content') ?>
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Verifikasi OTP</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?= session()->getFlashdata('error') ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?= session()->getFlashdata('success') ?>
                        </div>
                    <?php endif; ?>

                    <p>Masukkan kode OTP yang telah dikirim ke email <strong><?= esc($email) ?></strong>.</p>

                    <form action="<?= base_url('auth/verify-otp') ?>" method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden" name="email" value="<?= esc($email) ?>">
                        <div class="mb-3">
                            <label for="otp" class="form-label">Kode OTP</label>
                            <input type="text" class="form-control" id="otp" name="otp" maxlength="6" required value="<?= old('otp') ?>">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Verifikasi OTP</button>
                    </form>

                    <div class="mt-3 text-center">
                        <a href="<?= base_url('auth/forgot-password') ?>">Kirim ulang email OTP</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
