<?= $this->extend('layouts/app_auth') ?>

<?= $this->section('content') ?>
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow border-primary">
                <div class="card-header bg-danger text-white">
                    <h4 class="mb-0">
                        <i class="fas fa-lock"></i> Login Admin
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Error!</strong> <?= session()->getFlashdata('error') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Berhasil!</strong> <?= session()->getFlashdata('success') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('auth/do-admin-login') ?>" method="POST" novalidate>
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Administrator</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input 
                                    type="email" 
                                    class="form-control" 
                                    id="email" 
                                    name="email" 
                                    placeholder="Masukkan email admin"
                                    required 
                                    value="<?= old('email') ?>"
                                    autocomplete="email"
                                >
                            </div>
                            <small class="text-muted">Contoh: admin@gmail.com</small>
                        </div>

                        <div class="mb-4">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                                <input 
                                    type="password" 
                                    class="form-control" 
                                    id="password" 
                                    name="password" 
                                    placeholder="Masukkan password"
                                    required
                                    autocomplete="current-password"
                                >
                                <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <div class="mb-3 text-end">
                            <a href="<?= base_url('auth/forgot-password') ?>">Lupa Password?</a>
                        </div>

                        <button type="submit" class="btn btn-danger w-100 mb-3">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </button>
                    </form>

                    <hr>

                    <div class="text-center">
                        <p class="text-muted mb-2">Bukan admin?</p>
                        <a href="<?= base_url('auth/login') ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-arrow-left"></i> Login Biasa
                        </a>
                    </div>

                    <script>
                        document.getElementById('togglePassword')?.addEventListener('click', function () {
                            const passwordInput = document.getElementById('password');
                            const icon = this.querySelector('i');
                            if (passwordInput.type === 'password') {
                                passwordInput.type = 'text';
                                icon.classList.remove('fa-eye');
                                icon.classList.add('fa-eye-slash');
                            } else {
                                passwordInput.type = 'password';
                                icon.classList.remove('fa-eye-slash');
                                icon.classList.add('fa-eye');
                            }
                        });
                    </script>

                    <hr>

                    <div class="alert alert-info" role="alert">
                        <strong><i class="fas fa-info-circle"></i> Akses Admin</strong>
                        <p class="mb-0 small mt-2">
                            Halaman ini hanya untuk administrator sistem. Jika Anda tidak memiliki akses admin, silakan hubungi pemilik sistem.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
