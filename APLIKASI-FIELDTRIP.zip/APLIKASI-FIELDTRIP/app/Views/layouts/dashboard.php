<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? $title . ' - Fieldtrip Booking' : 'Fieldtrip Booking System' ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>

        :root {
            --sidebar-bg: #0A0A5E; /* dark navy */
            --sidebar-color: rgba(255,255,255,0.86);
            --sidebar-hover: #F4A300; /* gold */
            --content-bg: #f9fcfa; /* soft gray-blue */
            --navbar-bg: #ecaf05da;
            --card-radius: 14px;
            --accent: #F4A300;
            --text: #02081f;
            --muted: rgba(15, 23, 42, 0.68);
            --shadow-sm: 0 10px 25px rgba(15, 23, 42, 0.07);
            --shadow-md: 0 18px 45px rgba(15, 23, 42, 0.10);
        }

        body {
            background: radial-gradient(1000px 600px at 18% -10%, rgba(244, 163, 0, 0.10), transparent 60%),
                        radial-gradient(900px 540px at 88% 0%, rgba(10, 10, 94, 0.12), transparent 55%),
                        linear-gradient(180deg, rgba(219, 232, 253, 0.96), rgba(238,243,251,1));
            color: var(--text);
            min-height: 100vh;
            font-family: 'poppins', sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji", "Segoe UI Emoji";
        }

        h1, h2, h3, h4, h5, h6 {
            font-weight: 800;
            letter-spacing: 0.1px;
        }


        .navbar-dashboard {
            background-color: var(--navbar-bg);
            box-shadow: 0 8px 22px rgba(7, 7, 63, 0.18);
            border-bottom: 1px solid rgba(244, 163, 0, 0.08);
        }

        .navbar-brand {
            font-weight: 800;
            letter-spacing: 0.2px;
        }

        .sidebar {
            background-color: var(--sidebar-bg);
            color: var(--sidebar-color);
            /* Jangan buat sidebar terlalu panjang secara visual */
            min-height: 0;
            height: 100%;

            padding: 1.5rem 1rem;
            width: 260px;
            border-right: 1px solid rgba(244, 163, 0, 0.10);
            overflow: hidden;

            /* beri sedikit ruang bawah supaya background navy terlihat lebih halus */
            padding-bottom: calc(1.5rem + 6px);
        }



        .sidebar .sidebar-brand h5,
        .sidebar .sidebar-brand small,
        .sidebar .sidebar-user,
        .sidebar .sidebar-nav {
            color: var(--sidebar-color);
        }

        .sidebar-brand-icon {
            color: var(--accent);
        }

        .sidebar-user {
            border-left: 3px solid rgba(244, 163, 0, 0.55);
            padding-left: 0.75rem;
        }

        .sidebar .sidebar-nav a {
            color: var(--sidebar-color);
            text-decoration: none;
            border-radius: 12px;
            margin-bottom: 0.35rem;
            padding: 0.75rem 1rem;
            transition: background-color 0.15s ease, color 0.15s ease, transform 0.08s ease;
        }

        .sidebar .sidebar-nav a i {
            color: rgba(244, 163, 0, 0.95);
        }

        .sidebar .sidebar-nav a:hover {
            background-color: rgba(244, 163, 0, 0.14);
            color: #ffffff;
            transform: translateY(-1px);
        }

        .sidebar .sidebar-nav a.active {
            background-color: rgba(244, 163, 0, 0.18);
            color: #ffffff;
            box-shadow: inset 0 0 0 1px rgba(244, 163, 0, 0.22);
        }

        .sidebar .sidebar-nav a.active {
            border-left: 4px solid var(--sidebar-hover);
            padding-left: 0.9rem;
        }

        .main-panel {
            padding: 2rem;
            /* Jangan paksa tinggi layar supaya footer & sidebar tidak jadi terlalu panjang */
            min-height: auto;
        }

.content-wrapper {
            /* Pastikan konten tidak membuat ruang kosong berlebihan */
            min-height: auto;
        }

        /* Main background khusus role customer (soft blue), sementara sidebar tetap navy */
        body.customer-role {
            background-color: rgba(219, 232, 253, 0.96);
            background-image: none;
        }

        /* Card theme khusus customer tidak diperlukan lagi; card tetap mengikuti tema putih bawaan */
        .customer-soft-card { }

        .customer-soft-card .card-body { }

        .content-wrapper {
            background-color: rgba(255, 255, 255, 0.92);

            border-radius: var(--card-radius);
            box-shadow: 0 14px 35px rgba(15, 23, 42, 0.08);
            border: 1px solid rgba(10, 10, 94, 0.06);
            padding: 1.75rem;
        }

        .offcanvas-body {
            padding: 0;
        }

        .sidebar-offcanvas {
            width: 260px;
        }

        .footer-dashboard {
            background-color: #07073F;
            color: rgba(255,255,255,0.7);
            padding: 1rem 2rem;
            text-align: center;
            border-top: 1px solid rgba(244, 163, 0, 0.10);
        }

        .dashboard-title {
            font-weight: 900;
            letter-spacing: 0.2px;
            color: #faa609;
        }

        .dashboard-subtitle {
            color: rgba(19, 63, 83, 0.68);
            font-weight: 600;
        }

        .gold-accent {
            color: var(--accent);
        }

        .premium-card {
            border-radius: var(--card-radius);
            border: 1px solid rgba(34, 11, 99, 0.9);
            box-shadow: var(--shadow-sm);
            background: rgba(255, 255, 255, 0.96);
            height: 130px;
        }

        /* Management Cards (khusus Menu Manajemen) */
        .management-card{
            /* Dipaksa setinggi card statistik agar seragam */
            height: 120px !important;
            min-height: 120px !important;
            max-height: 120px !important;
            display: flex;
        }

        .management-card .card-body{
            padding: 15px !important;
            height: 100%;
        }

        .management-card__inner{
            height: 100%;
            min-height: 0;
            display: flex;
            flex-direction: column;
            gap: 8px;
            overflow: hidden;
        }


        .management-card__top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            min-height: 54px;
        }

        .management-card__text {
            flex: 1 1 auto;
            min-width: 0;
        }

        .management-card__label {
            font-weight: 900;
            letter-spacing: 0.25px;
            text-transform: uppercase;
            font-size: 12px;
            line-height: 1.05;
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .management-card__title{
            font-weight: 900;
            font-size: 12px !important;
            line-height: 1.2;
            margin: 0;
            color: #0A0A5E;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
        }


        .management-card__icon {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            color: #F4A300;
        }

        .management-card__action {
            margin-top: auto; /* tombol selalu di dalam card */
            width: 100%;
            display: flex;
            justify-content: flex-start;
        }

        .management-card__action .btn {
            padding: 7px 12px;
            border-radius: 10px;
            font-weight: 800;
            line-height: 1;
            white-space: nowrap;
            font-size: 13px;
        }

        @media (max-width: 575.98px) {
            .management-card { min-height: 124px; }
            .management-card__inner { min-height: 108px; }
            .management-card .card-body { padding: 12px !important; }
            .management-card__icon { width: 36px; height: 36px; }
        }


        .section-title {
            font-weight: 900;
            letter-spacing: 0.2px;
            color: #f8ac07e1;
        }

        .stat-card {
            border-radius: 16px;
        }

        .stat-icon {
            width: 46px;
            height: 46px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(146, 99, 4, 0.86);
            color: #F4A300;
        }

        .content-wrapper {
            background-color: rgba(190, 224, 243, 0.92);
            border-radius: var(--card-radius);
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(10, 10, 94, 0.06);
            padding: 0.50rem;
        }

        /* Rapikan footer supaya tidak terlalu jauh dari konten */
        .footer-dashboard {
            margin-top: 6px !important;
            padding-top: 0.5rem;
            padding-bottom: 0.75rem;
        }



        @media (max-width: 950.98px) {

            .sidebar {
                display: none;
            }

            .main-panel {
                padding: 1.25rem;
            }
        }
    </style>

    <?= $this->renderSection('css') ?>
</head>
<body class="<?= (session()->get('user_role') ?? 'customer') === 'customer' ? 'customer-role' : '' ?>">

    <nav class="navbar navbar-expand-lg navbar-dark navbar-dashboard sticky-top">
        <div class="container-fluid px-3">
            <button class="btn btn-outline-light d-lg-none me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarOffcanvas" aria-controls="sidebarOffcanvas">
                <i class="fas fa-bars"></i>
            </button>
            <a class="navbar-brand" href="<?= base_url() ?>">
                <i class="fas fa-ticket-alt"></i> Fieldtrip Booking
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDashboard" aria-controls="navbarDashboard" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarDashboard">
                <ul class="navbar-nav ms-auto align-items-center">
                    <?php if (session()->has('user_id')): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle"></i> <?= esc(session()->get('user_name') ?? session()->get('username') ?? 'Pengguna') ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="<?= base_url('auth/logout') ?>">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link text-white" href="<?= base_url('auth/login') ?>">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="offcanvas offcanvas-start sidebar-offcanvas bg-dark" tabindex="-1" id="sidebarOffcanvas" aria-labelledby="sidebarOffcanvasLabel">
        <div class="offcanvas-header border-bottom border-secondary">
            <h5 class="offcanvas-title text-white" id="sidebarOffcanvasLabel">Menu</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body p-0">
            <?= $this->include('layouts/_sidebar') ?>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row g-0">
            <div class="col-lg-3 d-none d-lg-block">
                <div class="sidebar">
                    <?= $this->include('layouts/_sidebar') ?>
                </div>
            </div>
            <div class="col-lg-9">
                <main class="main-panel">
                    <div class="content-wrapper">
                        <?php if (session()->getFlashdata('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fas fa-check-circle"></i> <?= session()->getFlashdata('success') ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle"></i> <?= session()->getFlashdata('error') ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if ($errors = session()->getFlashdata('errors')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle"></i> Terdapat kesalahan:
                                <ul class="mb-0 mt-2">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?= esc($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <?= $this->renderSection('content') ?>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <footer class="footer-dashboard mt-4">
        <small>&copy; 2024 Agro Edu Wisata - Sistem Pemesanan Fieldtrip.</small>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <?= $this->renderSection('js') ?>
</body>
</html>
