<?php
helper('url');
$role = session()->get('user_role') ?? 'customer';
$currentUri = uri_string();

$menuItems = [
    'customer' => [
        ['title' => 'Dashboard', 'url' => base_url('customer/dashboard'), 'icon' => 'fa-home', 'pattern' => 'customer/dashboard'],
        ['title' => 'Buat Pemesanan', 'url' => base_url('customer/order/form'), 'icon' => 'fa-cart-plus', 'pattern' => 'customer/order/form'],
        ['title' => 'Riwayat Pesanan', 'url' => base_url('customer/order/history'), 'icon' => 'fa-history', 'pattern' => 'customer/order/history'],
        ['title' => 'Profil', 'url' => base_url('customer/profile'), 'icon' => 'fa-user', 'pattern' => 'customer/profile'],
        ['title' => 'Logout', 'url' => base_url('auth/logout'), 'icon' => 'fa-sign-out-alt', 'pattern' => 'auth/logout'],
    ],
    'admin' => [
        ['title' => 'Dashboard', 'url' => base_url('admin/dashboard'), 'icon' => 'fa-home', 'pattern' => 'admin/dashboard'],
        ['title' => 'Kelola Paket', 'url' => base_url('admin/packages'), 'icon' => 'fa-box-open', 'pattern' => 'admin/packages'],
        ['title' => 'Kelola Wahana', 'url' => base_url('admin/attractions'), 'icon' => 'fa-water', 'pattern' => 'admin/attractions'],
        ['title' => 'Kelola Pesanan', 'url' => base_url('admin/orders'), 'icon' => 'fa-clipboard-list', 'pattern' => 'admin/orders'],
        ['title' => 'Kelola Pengguna', 'url' => base_url('admin/users'), 'icon' => 'fa-users', 'pattern' => 'admin/users'],
        ['title' => 'Laporan', 'url' => base_url('admin/reports/sales'), 'icon' => 'fa-chart-line', 'pattern' => 'admin/reports'],
        ['title' => 'Logout', 'url' => base_url('auth/logout'), 'icon' => 'fa-sign-out-alt', 'pattern' => 'auth/logout'],
    ],
    'pengelola' => [
        ['title' => 'Dashboard', 'url' => base_url('pengelola/dashboard'), 'icon' => 'fa-home', 'pattern' => 'pengelola/dashboard'],
        ['title' => 'Kelola Pesanan', 'url' => base_url('pengelola/orders'), 'icon' => 'fa-clipboard-list', 'pattern' => 'pengelola/orders'],
        ['title' => 'Kelola Wahana', 'url' => base_url('pengelola/attractions'), 'icon' => 'fa-water', 'pattern' => 'pengelola/attractions'],
        ['title' => 'Logout', 'url' => base_url('auth/logout'), 'icon' => 'fa-sign-out-alt', 'pattern' => 'auth/logout'],
    ],
    'owner' => [
        ['title' => 'Dashboard', 'url' => base_url('owner/dashboard'), 'icon' => 'fa-home', 'pattern' => 'owner/dashboard'],
        ['title' => 'Laporan Pemesanan', 'url' => base_url('owner/reports/booking'), 'icon' => 'fa-file-alt', 'pattern' => 'owner/reports/booking'],
        ['title' => 'Laporan Pendapatan', 'url' => base_url('owner/reports/sales'), 'icon' => 'fa-dollar-sign', 'pattern' => 'owner/reports/sales'],
        ['title' => 'Logout', 'url' => base_url('auth/logout'), 'icon' => 'fa-sign-out-alt', 'pattern' => 'auth/logout'],
    ],
];

$menu = $menuItems[$role] ?? $menuItems['customer'];
$isActive = fn(string $pattern): string => str_starts_with($currentUri, trim($pattern, '/')) ? 'active' : '';
?>
<div class="sidebar-brand mb-4">
    <div class="d-flex align-items-center gap-2">
       
        <div>
           
           
        </div>
    </div>
</div>
<div class="sidebar-user mb-4">
    <div class="small text-uppercase text-white-50">Selamat datang</div>
    <div class="fw-bold"><?= esc(session()->get('user_name') ?? session()->get('username') ?? 'Pengguna') ?></div>
</div>
<nav class="nav flex-column sidebar-nav">
    <?php foreach ($menu as $item): ?>
        <a href="<?= $item['url'] ?>" class="nav-link <?= $isActive($item['pattern']) ?>">
            <i class="fas <?= $item['icon'] ?> me-2"></i>
            <?= esc($item['title']) ?>
        </a>
    <?php endforeach; ?>
</nav>
